"""
config.py
=========

Zentrale Konfiguration für Ultimate Soundboard .

Enthält:
* Pfad-Konstanten des Projekts
* Farbschema (Neon / Fluent)
* Enums für Theme und Wiedergabestatus
* Dataclasses für die komplette, JSON-serialisierbare App-Konfiguration
"""
from __future__ import annotations

import dataclasses
import sys
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any

# --------------------------------------------------------------------------- #
# Anwendungs-Metadaten
# --------------------------------------------------------------------------- #
APP_NAME = "Ultimate Soundboard "
APP_VERSION = "1.0.0"
ORG_NAME = "UltimateSoft"

# --------------------------------------------------------------------------- #
# Pfade
# --------------------------------------------------------------------------- #
# PyInstaller-kompatible Pfad-Erkennung:
# - Onefile-Modus: Assets werden in sys._MEIPASS entpackt (temp),
#   schreibbare Dateien (config, logs) liegen neben der .exe.
# - Python-Modus: __file__ funktioniert normal.
if getattr(sys, 'frozen', False):
    # .exe → schreibbarer Pfad neben der .exe
    _EXE_DIR: Path = Path(sys.executable).parent
    # Gebündelte Assets: in _MEIPASS (onefile temp-Dir)
    _BUNDLE_DIR: Path = Path(getattr(sys, '_MEIPASS', str(_EXE_DIR)))
    BASE_DIR: Path = _EXE_DIR          # für config, logs, audio
    ASSETS_DIR: Path = _BUNDLE_DIR / "assets"  # read-only, aus Bundle
else:
    BASE_DIR: Path = Path(__file__).resolve().parent.parent
    ASSETS_DIR: Path = BASE_DIR / "assets"

ICONS_DIR: Path = ASSETS_DIR / "icons"
THEMES_DIR: Path = ASSETS_DIR / "themes"
CONFIG_DIR: Path = BASE_DIR / "config"
AUDIO_DIR: Path = BASE_DIR / "audio"
UTILS_DIR: Path = BASE_DIR / "src" / "utils"
CONFIG_FILE: Path = CONFIG_DIR / "config.json"
BACKUP_DIR: Path = CONFIG_DIR / "backups"

#: Unterstützte Audio-Dateiformate.
SUPPORTED_AUDIO_FORMATS: tuple[str, ...] = (".mp3", ".wav", ".flac", ".ogg")

#: Standard-/Grenzwerte für die (dynamische) Anzahl der Soundbuttons.
DEFAULT_BUTTON_COUNT = 12
MIN_BUTTON_COUNT = 1
MAX_BUTTON_COUNT = 60
#: Startwert / Rückwärtskompatibilität (die tatsächliche Anzahl ist variabel).
BUTTON_COUNT = DEFAULT_BUTTON_COUNT
#: Standard-Spaltenzahl des Rasters (frei konfigurierbar).
DEFAULT_GRID_COLS = 3


# --------------------------------------------------------------------------- #
# Farbschema
# --------------------------------------------------------------------------- #
class Colors:
    """Modernes Neon-Farbschema der Anwendung."""

    PRIMARY = "#5865F2"
    SECONDARY = "#00C2FF"
    ACCENT = "#8A5CFF"
    WARNING = "#FFB020"
    ERROR = "#FF4D4F"
    SUCCESS = "#00D26A"

    # Dark-Theme-Flächen
    BG_DARK = "#0D0F16"
    SURFACE_DARK = "#151823"
    SURFACE_DARK_2 = "#1C2030"
    BORDER_DARK = "#2A2F45"
    TEXT_DARK = "#EAECF5"
    TEXT_MUTED_DARK = "#8B90A8"

    # Light-Theme-Flächen
    BG_LIGHT = "#F2F4FA"
    SURFACE_LIGHT = "#FFFFFF"
    SURFACE_LIGHT_2 = "#E8EBF5"
    BORDER_LIGHT = "#D3D8E8"
    TEXT_LIGHT = "#1B1E2B"
    TEXT_MUTED_LIGHT = "#5C6178"


# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #
class Theme(str, Enum):
    """Verfügbare UI-Themes."""

    DARK = "dark"
    LIGHT = "light"


class PlaybackState(Enum):
    """Wiedergabestatus eines Sound-Kanals."""

    IDLE = "Bereit"
    LOADING = "Lädt…"
    PLAYING = "Spielt"
    PAUSED = "Pause"
    ERROR = "Fehler"


class Language(str, Enum):
    """Unterstützte Sprachen (UI-Texte sind Deutsch, Setting wird persistiert)."""

    GERMAN = "de"
    ENGLISH = "en"


# --------------------------------------------------------------------------- #
# Standardwerte für die 9 Buttons
# --------------------------------------------------------------------------- #
DEFAULT_BUTTON_ICONS: tuple[str, ...] = (
    "music", "drum", "bell", "star", "bolt", "heart",
    "wave", "mic", "rocket", "guitar", "folder", "star",
)

DEFAULT_BUTTON_COLORS: tuple[tuple[str, str], ...] = (
    ("#5865F2", "#8A5CFF"), ("#00C2FF", "#5865F2"), ("#8A5CFF", "#FF4D9E"),
    ("#00D26A", "#00C2FF"), ("#FFB020", "#FF6A3D"), ("#FF4D4F", "#8A5CFF"),
    ("#2BD9C6", "#00C2FF"), ("#FF6A3D", "#FFB020"), ("#5865F2", "#00D26A"),
    ("#FF4D9E", "#8A5CFF"), ("#00C2FF", "#2BD9C6"), ("#FFB020", "#FF4D4F"),
)


def _filter_fields(cls: type, data: dict[str, Any]) -> dict[str, Any]:
    """Filtert ein Dict auf die Felder einer Dataclass (robust gegen Altdaten)."""
    names = {f.name for f in dataclasses.fields(cls)}
    return {k: v for k, v in data.items() if k in names}


# --------------------------------------------------------------------------- #
# Dataclasses
# --------------------------------------------------------------------------- #
@dataclass
class SoundButtonConfig:
    """Konfiguration eines einzelnen Soundbuttons."""

    name: str = "Sound"
    sound_path: str = ""
    icon: str = "music"
    color: str = Colors.PRIMARY
    gradient_color: str = Colors.ACCENT
    text_color: str = "#FFFFFF"
    volume: float = 0.8            # 0.0 – 1.0
    speed: float = 1.0             # Wiedergabegeschwindigkeit 0.25 – 3.0
    loop: bool = False
    loop_count: int = 0            # 0 = unendlich (wenn loop aktiv)
    autoplay: bool = False
    favorite: bool = False
    hotkey: str = ""               # z. B. "Ctrl+Alt+1" – global!
    fade_in_ms: int = 0
    fade_out_ms: int = 300
    play_count: int = 0            # Statistik: Anzahl Wiedergaben
    total_play_seconds: float = 0.0  # Statistik: Gesamtdauer

    def to_dict(self) -> dict[str, Any]:
        """Serialisiert die Konfiguration als Dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SoundButtonConfig":
        """Erzeugt eine Instanz aus einem (ggf. unvollständigen) Dictionary."""
        return cls(**_filter_fields(cls, data))


@dataclass
class UIConfig:
    """Einstellungen für Aussehen und Animationen."""

    theme: str = Theme.DARK.value
    accent_color: str = Colors.PRIMARY
    animations_enabled: bool = True
    animation_speed: float = 1.0       # Multiplikator, 0.25 – 2.0
    glow_intensity: float = 0.8        # 0.0 – 1.0
    blur_intensity: float = 0.7        # 0.0 – 1.0
    shadows_enabled: bool = True
    button_size: int = 170             # Kantenlänge in px
    button_spacing: int = 28           # Rasterabstand in px
    grid_columns: int = DEFAULT_GRID_COLS  # Spalten im Button-Raster (1–10)
    font_family: str = "Segoe UI"
    font_size: int = 10
    window_opacity: float = 1.0        # 0.6 – 1.0
    language: str = Language.GERMAN.value

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UIConfig":
        return cls(**_filter_fields(cls, data))


@dataclass
class AudioConfig:
    """Globale Audioeinstellungen."""

    output_device: str = ""            # Gerätename, "" = Systemstandard
    input_device: str = ""             # Mikrofon, "" = Systemstandard
    cable_device: str = ""             # Zweitausgabe (virtuelles Kabel/Mikrofon-Routing)
    master_volume: float = 0.9         # 0.0 – 1.0
    balance: float = 0.0               # -1.0 (links) – 1.0 (rechts)
    crossfade_ms: int = 0              # 0 = deaktiviert

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AudioConfig":
        return cls(**_filter_fields(cls, data))


@dataclass
class WindowConfig:
    """Fenstergeometrie und -zustand."""

    x: int = 100
    y: int = 50
    width: int = 980
    height: int = 720
    maximized: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "WindowConfig":
        return cls(**_filter_fields(cls, data))


def _default_buttons() -> list[SoundButtonConfig]:
    """Erzeugt die Standard-Buttonkonfigurationen (Anzahl = Default)."""
    return [make_default_button(i) for i in range(DEFAULT_BUTTON_COUNT)]


def make_default_button(index: int) -> SoundButtonConfig:
    """
    Erzeugt eine frische Standard-Buttonkonfiguration.

    Icon und Farben werden zyklisch aus den Vorgaben gewählt, sodass
    auch neu hinzugefügte Buttons (über die Default-Anzahl hinaus)
    sinnvoll aussehen.
    """
    icon = DEFAULT_BUTTON_ICONS[index % len(DEFAULT_BUTTON_ICONS)]
    color, gradient = DEFAULT_BUTTON_COLORS[index % len(DEFAULT_BUTTON_COLORS)]
    return SoundButtonConfig(
        name=f"Sound {index + 1}",
        icon=icon,
        color=color,
        gradient_color=gradient,
    )


@dataclass
class AppConfig:
    """Gesamte, persistierte Anwendungskonfiguration."""

    window: WindowConfig = field(default_factory=WindowConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    audio: AudioConfig = field(default_factory=AudioConfig)
    buttons: list[SoundButtonConfig] = field(default_factory=_default_buttons)
    autostart: bool = False
    save_window_geometry: bool = True
    save_last_state: bool = True
    recent_sounds: list[str] = field(default_factory=list)   # max. 10 Pfade
    total_playtime_seconds: float = 0.0                      # globale Statistik

    def to_dict(self) -> dict[str, Any]:
        """Serialisiert die komplette Konfiguration als verschachteltes Dict."""
        return {
            "window": self.window.to_dict(),
            "ui": self.ui.to_dict(),
            "audio": self.audio.to_dict(),
            "buttons": [b.to_dict() for b in self.buttons],
            "autostart": self.autostart,
            "save_window_geometry": self.save_window_geometry,
            "save_last_state": self.save_last_state,
            "recent_sounds": self.recent_sounds,
            "total_playtime_seconds": self.total_playtime_seconds,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AppConfig":
        """Deserialisiert robust – fehlende Schlüssel erhalten Standardwerte."""
        cfg = cls()
        cfg.window = WindowConfig.from_dict(data.get("window", {}))
        cfg.ui = UIConfig.from_dict(data.get("ui", {}))
        cfg.audio = AudioConfig.from_dict(data.get("audio", {}))

        raw_buttons = data.get("buttons", [])
        buttons = [SoundButtonConfig.from_dict(b) for b in raw_buttons]
        # Anzahl ist dynamisch – nur Mindest- und Höchstzahl erzwingen.
        if len(buttons) < MIN_BUTTON_COUNT:
            buttons = _default_buttons()
        cfg.buttons = buttons[:MAX_BUTTON_COUNT]

        cfg.autostart = bool(data.get("autostart", False))
        cfg.save_window_geometry = bool(data.get("save_window_geometry", True))
        cfg.save_last_state = bool(data.get("save_last_state", True))
        cfg.recent_sounds = list(data.get("recent_sounds", []))[:10]
        cfg.total_playtime_seconds = float(data.get("total_playtime_seconds", 0.0))
        return cfg
