"""
utils/system_monitor.py
=======================

Hintergrund-Thread zur Überwachung von CPU- und RAM-Auslastung.

Bevorzugt :mod:`psutil`; fällt ohne diese Abhängigkeit auf native
Win32-API-Aufrufe (``GetSystemTimes`` / ``GlobalMemoryStatusEx``) zurück,
sodass die Anwendung immer lauffähig bleibt. Der Hauptthread wird
niemals blockiert.
"""
from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes

from PySide6.QtCore import QThread, Signal

from logger import get_logger

log = get_logger(__name__)

try:
    import psutil

    _HAS_PSUTIL = True
except ImportError:  # pragma: no cover - optionale Abhängigkeit
    _HAS_PSUTIL = False
    log.info("psutil nicht installiert – native Win32-Fallbacks aktiv.")


class _MEMORYSTATUSEX(ctypes.Structure):
    """Win32-Struktur für GlobalMemoryStatusEx."""

    _fields_ = [
        ("dwLength", wintypes.DWORD),
        ("dwMemoryLoad", wintypes.DWORD),
        ("ullTotalPhys", ctypes.c_ulonglong),
        ("ullAvailPhys", ctypes.c_ulonglong),
        ("ullTotalPageFile", ctypes.c_ulonglong),
        ("ullAvailPageFile", ctypes.c_ulonglong),
        ("ullTotalVirtual", ctypes.c_ulonglong),
        ("ullAvailVirtual", ctypes.c_ulonglong),
        ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
    ]


def _filetime_to_int(ft: wintypes.FILETIME) -> int:
    """Konvertiert eine FILETIME in einen 64-Bit-Integer."""
    return (ft.dwHighDateTime << 32) | ft.dwLowDateTime


class SystemMonitor(QThread):
    """
    Liefert sekündlich CPU- und RAM-Auslastung per Signal.

    Signals
    -------
    statsUpdated(float, float)
        ``(cpu_percent, ram_percent)``.
    """

    statsUpdated = Signal(float, float)

    def __init__(self, interval_ms: int = 1000, parent=None) -> None:
        super().__init__(parent)
        self._interval_ms = interval_ms
        self._running = True
        self._prev_idle = 0
        self._prev_total = 0

    def stop(self) -> None:
        """Beendet den Thread sauber."""
        self._running = False
        self.wait(2000)

    # ------------------------------------------------------------------ #
    def run(self) -> None:  # noqa: D102
        while self._running:
            try:
                cpu = self._cpu_percent()
                ram = self._ram_percent()
                self.statsUpdated.emit(cpu, ram)
            except Exception as exc:  # noqa: BLE001 - Monitor darf nie crashen
                log.debug("Systemmonitor-Fehler: %s", exc)
            self.msleep(self._interval_ms)

    # ------------------------------------------------------------------ #
    def _cpu_percent(self) -> float:
        """CPU-Auslastung in Prozent (psutil oder GetSystemTimes-Delta)."""
        if _HAS_PSUTIL:
            return float(psutil.cpu_percent(interval=None))
        if sys.platform != "win32":
            return 0.0

        idle, kernel, user = wintypes.FILETIME(), wintypes.FILETIME(), wintypes.FILETIME()
        ctypes.windll.kernel32.GetSystemTimes(
            ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
        )
        idle_t = _filetime_to_int(idle)
        total_t = _filetime_to_int(kernel) + _filetime_to_int(user)

        d_idle = idle_t - self._prev_idle
        d_total = total_t - self._prev_total
        self._prev_idle, self._prev_total = idle_t, total_t
        if d_total <= 0:
            return 0.0
        return max(0.0, min(100.0, (1.0 - d_idle / d_total) * 100.0))

    def _ram_percent(self) -> float:
        """RAM-Auslastung in Prozent (psutil oder GlobalMemoryStatusEx)."""
        if _HAS_PSUTIL:
            return float(psutil.virtual_memory().percent)
        if sys.platform != "win32":
            return 0.0
        status = _MEMORYSTATUSEX()
        status.dwLength = ctypes.sizeof(_MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
        return float(status.dwMemoryLoad)
