"""
utils/win_effects.py
====================

Native Windows-Fenstereffekte über die Win32-/DWM-API (ctypes):

* Acrylic-Blur hinter dem Fenster (SetWindowCompositionAttribute)
* Abgerundete Fensterecken (Windows 11, DwmSetWindowAttribute)
* Dark-Mode-Titelleistenattribut

Alle Aufrufe sind fehlertolerant – auf nicht unterstützten Systemen
passiert schlicht nichts. **Kein C++-Treiber erforderlich.**
"""
from __future__ import annotations

import ctypes
import sys

from logger import get_logger

log = get_logger(__name__)

# DWM-Konstanten (Windows 11)
DWMWA_WINDOW_CORNER_PREFERENCE = 33
DWMWCP_ROUND = 2
DWMWA_USE_IMMERSIVE_DARK_MODE = 20

# SetWindowCompositionAttribute-Konstanten
WCA_ACCENT_POLICY = 19
ACCENT_ENABLE_ACRYLICBLURBEHIND = 4
ACCENT_ENABLE_BLURBEHIND = 3
ACCENT_DISABLED = 0


class _ACCENT_POLICY(ctypes.Structure):
    _fields_ = [
        ("AccentState", ctypes.c_int),
        ("AccentFlags", ctypes.c_int),
        ("GradientColor", ctypes.c_uint),
        ("AnimationId", ctypes.c_int),
    ]


class _WINCOMPATTRDATA(ctypes.Structure):
    _fields_ = [
        ("Attribute", ctypes.c_int),
        ("Data", ctypes.c_void_p),
        ("SizeOfData", ctypes.c_size_t),
    ]


def _is_windows() -> bool:
    return sys.platform == "win32"


def enable_acrylic_blur(hwnd: int, tint: int = 0x99101018, intensity: float = 1.0) -> None:
    """
    Aktiviert Blur hinter dem Fenster.

    Verwendet ``ACCENT_ENABLE_BLURBEHIND`` statt des Acrylic-Modus:
    Acrylic (``ACCENT_ENABLE_ACRYLICBLURBEHIND``) verursacht unter
    Windows massive Render-/Drag-Latenzen bei Frameless-Fenstern –
    der klassische Blur sieht nahezu identisch aus, läuft aber
    GPU-beschleunigt und flüssig.

    :param hwnd: Native Fenster-Handle (``int(widget.winId())``).
    :param tint: ABGR-Tint-Farbe inkl. Alpha (nur für Acrylic relevant).
    :param intensity: 0.0 deaktiviert den Blur, > 0 aktiviert ihn.
    """
    if not _is_windows():
        return
    try:
        accent = _ACCENT_POLICY()
        if intensity <= 0.05:
            accent.AccentState = ACCENT_DISABLED
        else:
            accent.AccentState = ACCENT_ENABLE_BLURBEHIND
            accent.GradientColor = 0
        accent.AccentFlags = 2

        data = _WINCOMPATTRDATA()
        data.Attribute = WCA_ACCENT_POLICY
        data.Data = ctypes.cast(ctypes.pointer(accent), ctypes.c_void_p)
        data.SizeOfData = ctypes.sizeof(accent)

        ctypes.windll.user32.SetWindowCompositionAttribute(
            wintypes_handle(hwnd), ctypes.byref(data)
        )
    except Exception as exc:  # noqa: BLE001 - rein kosmetisch, nie kritisch
        log.debug("Acrylic-Blur nicht verfügbar: %s", exc)


def enable_rounded_corners(hwnd: int) -> None:
    """Aktiviert abgerundete Fensterecken (nur Windows 11)."""
    if not _is_windows():
        return
    try:
        pref = ctypes.c_int(DWMWCP_ROUND)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes_handle(hwnd),
            DWMWA_WINDOW_CORNER_PREFERENCE,
            ctypes.byref(pref),
            ctypes.sizeof(pref),
        )
    except Exception as exc:  # noqa: BLE001
        log.debug("Runde Ecken nicht verfügbar: %s", exc)


def enable_dark_titlebar(hwnd: int, dark: bool = True) -> None:
    """Setzt das Immersive-Dark-Mode-Attribut des Fensters."""
    if not _is_windows():
        return
    try:
        value = ctypes.c_int(1 if dark else 0)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes_handle(hwnd),
            DWMWA_USE_IMMERSIVE_DARK_MODE,
            ctypes.byref(value),
            ctypes.sizeof(value),
        )
    except Exception as exc:  # noqa: BLE001
        log.debug("Dark-Titlebar nicht verfügbar: %s", exc)


def wintypes_handle(hwnd: int) -> ctypes.c_void_p:
    """Konvertiert ein Fenster-Handle sicher in ``c_void_p``."""
    return ctypes.c_void_p(int(hwnd))
