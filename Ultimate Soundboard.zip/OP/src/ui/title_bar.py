"""
ui/title_bar.py
===============

Eigene Titel-/Kopfleiste des Frameless-Fensters.

Enthält: Logo, Projektname, Suchfeld, globale Lautstärke, Settings-,
Info- und Theme-Buttons, CPU-/RAM-/FPS-Anzeige, Uhr sowie eigene
Fensterknöpfe (Minimieren, Maximieren/Wiederherstellen, Schließen).
Die Leiste ist Dragging-Bereich für das Fenster (Snap-kompatibel über
``startSystemMove``).
"""
from __future__ import annotations

from PySide6.QtCore import QDateTime, Qt, QTimer, Signal
from PySide6.QtGui import QMouseEvent
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QWidget,
)

from config import APP_NAME, ASSETS_DIR, Colors
from widget_factory import make_icon_button, make_slider, render_svg_pixmap, svg_icon
from logger import get_logger

log = get_logger(__name__)


class TitleBar(QWidget):
    """
    Kopfleiste mit allen globalen Bedienelementen.

    Signals
    -------
    searchChanged(str)      : Suchtext geändert.
    volumeChanged(float)    : Globale Lautstärke (0–1).
    settingsRequested       : Settings-Button gedrückt.
    infoRequested           : Info-Button gedrückt.
    themeToggled            : Theme-Switch gedrückt.
    minimizeRequested       : Fenster minimieren.
    maximizeRequested       : Maximieren/Wiederherstellen umschalten.
    closeRequested          : Fenster schließen.
    """

    searchRequested = Signal()
    settingsRequested = Signal()
    infoRequested = Signal()
    themeToggled = Signal()
    minimizeRequested = Signal()
    maximizeRequested = Signal()
    closeRequested = Signal()

    HEIGHT = 58

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(self.HEIGHT)
        self._build_ui()

        # Uhr im Sekundentakt aktualisieren.
        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)
        self._update_clock()

    # ------------------------------------------------------------------ #
    def _build_ui(self) -> None:
        """Baut alle Elemente der Kopfleiste auf."""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 8, 10, 8)
        layout.setSpacing(10)

        # Logo + Titel (neues .ico-Icon statt logo.svg)
        logo = QLabel()
        _ico = ASSETS_DIR / "icon.ico"
        if _ico.exists():
            from PySide6.QtGui import QIcon
            logo.setPixmap(QIcon(str(_ico)).pixmap(24, 24))
        else:
            logo.setPixmap(render_svg_pixmap("logo", Colors.PRIMARY, 28))
        title = QLabel(APP_NAME)
        title.setStyleSheet("font-size: 14px; font-weight: 700;")
        layout.addWidget(logo)
        layout.addWidget(title)
        layout.addSpacing(12)

        # Such-Button (Lupe)
        self.search_btn = make_icon_button("search", "Suche öffnen (Strg+F)")
        self.search_btn.clicked.connect(self.searchRequested)
        layout.addWidget(self.search_btn)

        layout.addStretch(1)

        # Systemanzeigen (CPU / RAM / FPS / Uhr)
        self.cpu_label = self._make_stat("CPU --%", "CPU-Auslastung")
        self.ram_label = self._make_stat("RAM --%", "RAM-Auslastung")
        self.fps_label = self._make_stat("-- FPS", "UI-Bildrate")
        self.clock_label = self._make_stat("--:--:--", "Uhrzeit")
        for lbl in (self.cpu_label, self.ram_label, self.fps_label, self.clock_label):
            layout.addWidget(lbl)

        layout.addSpacing(6)

        # Aktions-Buttons
        self.theme_btn = make_icon_button("theme", "Theme wechseln")
        self.theme_btn.clicked.connect(self.themeToggled)
        self.info_btn = make_icon_button("info", "Info und Statistiken")
        self.info_btn.clicked.connect(self.infoRequested)
        self.settings_btn = make_icon_button("settings", "Einstellungen (Strg+S)")
        self.settings_btn.clicked.connect(self.settingsRequested)
        layout.addWidget(self.theme_btn)
        layout.addWidget(self.info_btn)
        layout.addWidget(self.settings_btn)

        layout.addSpacing(8)

        # Fensterknöpfe
        self._min_btn = self._window_button("minimize", "Minimieren")
        self._min_btn.clicked.connect(self.minimizeRequested)
        self._max_btn = self._window_button("maximize", "Maximieren")
        self._max_btn.clicked.connect(self.maximizeRequested)
        self._close_btn = self._window_button("close", "Schließen", danger=True)
        self._close_btn.clicked.connect(self.closeRequested)
        layout.addWidget(self._min_btn)
        layout.addWidget(self._max_btn)
        layout.addWidget(self._close_btn)

    def _make_stat(self, text: str, tooltip: str) -> QLabel:
        """Erzeugt ein kleines Statistik-Label (CPU/RAM/FPS/Uhr)."""
        label = QLabel(text)
        label.setToolTip(tooltip)
        label.setStyleSheet(
            f"color:{Colors.TEXT_MUTED_DARK}; font-size:11px;"
            "background:rgba(255,255,255,0.05); border-radius:8px; padding:4px 8px;"
        )
        label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        return label

    def _window_button(
        self, icon: str, tooltip: str, danger: bool = False
    ) -> QPushButton:
        """Erzeugt einen Fenster-Steuerknopf im Fluent-Stil."""
        btn = make_icon_button(icon, tooltip, icon_size=13)
        if danger:
            btn.setStyleSheet(
                "QPushButton{border:none;border-radius:10px;background:transparent;}"
                f"QPushButton:hover{{background:{Colors.ERROR};}}"
                "QPushButton:pressed{background:#C73A3C;}"
            )
        return btn

    # ------------------------------------------------------------------ #
    # Öffentliche Update-API
    # ------------------------------------------------------------------ #
    def update_stats(self, cpu: float, ram: float) -> None:
        """Aktualisiert CPU-/RAM-Anzeige."""
        self.cpu_label.setText(f"CPU {cpu:.0f}%")
        self.ram_label.setText(f"RAM {ram:.0f}%")

    def update_fps(self, fps: float) -> None:
        """Aktualisiert die FPS-Anzeige."""
        self.fps_label.setText(f"{fps:.0f} FPS")

    def set_maximized(self, maximized: bool) -> None:
        """Wechselt das Maximieren-/Wiederherstellen-Icon."""
        icon = "restore" if maximized else "maximize"
        tooltip = "Wiederherstellen" if maximized else "Maximieren"
        self._max_btn.setIcon(svg_icon(icon, Colors.TEXT_DARK, 26))
        self._max_btn.setToolTip(tooltip)

    def _update_clock(self) -> None:
        """Aktualisiert die Uhranzeige."""
        self.clock_label.setText(QDateTime.currentDateTime().toString("HH:mm:ss"))

    # ------------------------------------------------------------------ #
    # Fenster-Drag (Snap-Layout-kompatibel über das Betriebssystem)
    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Startet den nativen System-Move für flüssiges Verschieben."""
        if event.button() == Qt.MouseButton.LeftButton:
            window = self.window().windowHandle()
            if window is not None:
                window.startSystemMove()
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Doppelklick maximiert/stellt das Fenster wieder her."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.maximizeRequested.emit()
        super().mouseDoubleClickEvent(event)
