"""UI-Paket: Hauptfenster, Titelleiste, Splash-Screen."""
