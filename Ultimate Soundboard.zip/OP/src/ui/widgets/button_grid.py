"""
ui/widgets/button_grid.py
=========================

Selektierbarer Rasterbereich für die Soundbuttons.

Bietet ein :class:`QGridLayout` sowie eine Rubber-Band-Mehrfachauswahl
(Aufziehen eines Auswahlrechtecks wie auf dem Windows-Desktop). Alle
Buttons, deren Fläche das Rechteck berührt, werden markiert. Mit
gedrückter Strg-Taste wird die bestehende Auswahl ergänzt.
"""
from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, QSize, Qt, Signal
from PySide6.QtGui import QKeyEvent, QMouseEvent
from PySide6.QtWidgets import QGridLayout, QRubberBand, QWidget

from ui.widgets.sound_button import SoundButton


class SelectableGrid(QWidget):
    """
    Container mit Button-Raster und Rubber-Band-Auswahl.

    Signals
    -------
    selectionChanged
        Wird bei jeder Änderung der Auswahl ausgelöst.
    deleteRequested
        Wird ausgelöst, wenn bei aktiver Auswahl ``Entf`` gedrückt wird.
    """

    selectionChanged = Signal()
    deleteRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.grid = QGridLayout(self)
        # Buttons kompakt zentriert oben – wächst nach unten (scrollbar).
        self.grid.setAlignment(
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop
        )
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self._band = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self._origin = QPoint()
        self._selecting = False
        self._base_selection: set[int] = set()   # Auswahl vor dem Aufziehen

    # ------------------------------------------------------------------ #
    def sound_buttons(self) -> list[SoundButton]:
        """Liefert alle enthaltenen Soundbuttons."""
        return self.findChildren(SoundButton)

    def selected_indices(self) -> list[int]:
        """Indizes aller aktuell markierten Buttons (aufsteigend)."""
        return sorted(b.index for b in self.sound_buttons() if b.selected)

    def clear_selection(self) -> None:
        """Hebt die komplette Auswahl auf."""
        for b in self.sound_buttons():
            b.set_selected(False)
        self.selectionChanged.emit()

    # ------------------------------------------------------------------ #
    # Rubber-Band
    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Startet die Rubber-Band-Auswahl auf freier Fläche."""
        if event.button() == Qt.MouseButton.LeftButton:
            self.setFocus()
            self._origin = event.position().toPoint()
            self._selecting = True
            ctrl = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)
            if ctrl:
                self._base_selection = set(self.selected_indices())
            else:
                self._base_selection = set()
                self.clear_selection()
            self._band.setGeometry(QRect(self._origin, QSize()))
            self._band.show()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Vergrößert das Auswahlrechteck und markiert berührte Buttons."""
        if self._selecting:
            rect = QRect(self._origin, event.position().toPoint()).normalized()
            self._band.setGeometry(rect)
            for b in self.sound_buttons():
                hit = rect.intersects(b.geometry())
                b.set_selected(hit or b.index in self._base_selection)
            self.selectionChanged.emit()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Beendet die Rubber-Band-Auswahl."""
        if self._selecting and event.button() == Qt.MouseButton.LeftButton:
            self._selecting = False
            self._band.hide()
            self.selectionChanged.emit()
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        """Löst bei ``Entf`` das Löschen der Auswahl aus."""
        if event.key() == Qt.Key.Key_Delete and self.selected_indices():
            self.deleteRequested.emit()
        elif event.key() == Qt.Key.Key_Escape:
            self.clear_selection()
        else:
            super().keyPressEvent(event)
