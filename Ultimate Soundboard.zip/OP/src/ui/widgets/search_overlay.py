"""
ui/widgets/search_overlay.py
============================

Animiertes Such-Overlay, das sich in der Mitte des Fensters öffnet.

Erscheint beim Klick auf das Lupen-Icon, zeigt ein Texteingabefeld mit
Live-Suche (filtert bei jedem Tastendruck) und schließt sich mit Escape
oder wenn außerhalb geklickt wird.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve, Signal
from PySide6.QtGui import QMouseEvent, QKeyEvent
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QLineEdit,
    QGraphicsOpacityEffect,
)

from config import Colors
from widget_factory import svg_icon
from logger import get_logger

log = get_logger(__name__)


class SearchOverlay(QWidget):
    """
    Halbtransparentes Overlay mit zentriertem Suchfeld.

    Signals
    -------
    searchChanged(str) : Suchtext geändert.
    closed             : Overlay wurde geschlossen.
    """

    searchChanged = Signal(str)
    closed = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        # WICHTIG: KEINE Window-Flags (kein Tool/Frameless) – sonst wird
        # das Overlay ein eigenständiges, schwebendes Fenster AUSSERHALB
        # der App. Als reines Child-Widget liegt es INNERHALB des Fensters.
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(
            "SearchOverlay { background: rgba(0, 0, 0, 0.85); }"
        )

        self._build_ui()
        self._setup_animation()
        self.hide()

    def _build_ui(self) -> None:
        """Erstellt das zentrierte Suchfeld."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Suchfeld-Container
        self.search = QLineEdit()
        self.search.setPlaceholderText("Sounds durchsuchen… (Escape zum Schließen)")
        self.search.setClearButtonEnabled(True)
        self.search.setFixedWidth(500)
        self.search.setFixedHeight(60)
        self.search.setStyleSheet(f"""
            QLineEdit {{
                background: rgba(30, 30, 35, 0.95);
                border: 2px solid {Colors.PRIMARY};
                border-radius: 12px;
                color: {Colors.TEXT_DARK};
                font-size: 18px;
                padding: 12px 20px 12px 60px;
            }}
            QLineEdit:focus {{
                border-color: {Colors.ACCENT};
                background: rgba(35, 35, 40, 0.98);
            }}
        """)
        self.search.addAction(
            svg_icon("search", Colors.PRIMARY, 48),
            QLineEdit.ActionPosition.LeadingPosition,
        )
        self.search.textChanged.connect(self.searchChanged)
        layout.addWidget(self.search, 0, Qt.AlignmentFlag.AlignCenter)

    def _setup_animation(self) -> None:
        """Erstellt Fade-In/Out-Animation."""
        self._opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._opacity_effect)
        self._opacity_effect.setOpacity(0.0)

        self._fade_anim = QPropertyAnimation(self._opacity_effect, b"opacity")
        self._fade_anim.setDuration(250)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.finished.connect(self._on_fade_finished)

    def show_animated(self) -> None:
        """Zeigt das Overlay mit Fade-In-Animation."""
        self.show()
        self.raise_()
        self._fade_anim.stop()
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.start()
        self.search.clear()
        self.search.setFocus()

    def hide_animated(self) -> None:
        """Versteckt das Overlay mit Fade-Out-Animation."""
        self._fade_anim.stop()
        self._fade_anim.setStartValue(self._opacity_effect.opacity())
        self._fade_anim.setEndValue(0.0)
        self._fade_anim.start()
        self.closed.emit()

    def _on_fade_finished(self) -> None:
        """Blendet das Widget nach dem Fade-Out endgültig aus."""
        if self._opacity_effect.opacity() <= 0.01:
            self.hide()

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Schließt das Overlay beim Klick außerhalb des Suchfelds."""
        if not self.search.geometry().contains(event.pos()):
            self.hide_animated()
        super().mousePressEvent(event)

    def keyPressEvent(self, event: QKeyEvent) -> None:  # noqa: N802
        """Escape schließt das Overlay."""
        if event.key() == Qt.Key.Key_Escape:
            self.hide_animated()
        else:
            super().keyPressEvent(event)
