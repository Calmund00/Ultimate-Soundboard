"""
ui/widgets/sound_button.py
==========================

Der zentrale Soundbutton des Dashboards.

Vollständig custom-gepainted mit:
Gradient-Hintergrund, Neon-Rand, Hover-Glow, Scale-/Pressed-Animation,
Ripple-Effekt, Loading-Spinner, Fortschritts-/Lautstärkeanzeige,
Statuslabel, Drag&Drop für Audio-/SVG-Dateien, Kontextmenü und Tooltip.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import (
    QEasingCurve,
    QMimeData,
    QPoint,
    QPointF,
    QPropertyAnimation,
    Qt,
    QTimer,
    QVariantAnimation,
    Property,
    Signal,
)
from PySide6.QtGui import (
    QColor,
    QDrag,
    QDragEnterEvent,
    QDropEvent,
    QLinearGradient,
    QMouseEvent,
    QPainter,
    QPainterPath,
    QPen,
)
from PySide6.QtWidgets import QApplication, QGraphicsDropShadowEffect, QWidget

from config import SUPPORTED_AUDIO_FORMATS, Colors, PlaybackState, SoundButtonConfig
from widget_factory import render_svg_pixmap
from logger import get_logger

log = get_logger(__name__)

#: Eckenradius des Buttons in Pixel.
RADIUS = 20

#: MIME-Typ für das Umsortieren von Buttons per Drag & Drop.
MIME_BUTTON_INDEX = "application/x-soundbutton-index"


class _Ripple:
    """Ein einzelner Ripple-Kreis (Position, Radius, Deckkraft)."""

    def __init__(self, center: QPointF) -> None:
        self.center = center
        self.radius = 0.0
        self.opacity = 0.45


class SoundButton(QWidget):
    """
    Großer, animierter Soundbutton.

    Signals
    -------
    triggered(int)              : Linksklick → Play/Pause-Toggle.
    stopRequested(int)          : Stop des Kanals angefordert.
    soundDropped(int, str)      : Audiodatei per Drag&Drop zugewiesen.
    iconDropped(int, str)       : SVG-Icon per Drag&Drop zugewiesen.
    moveRequested(int, int)     : Button umsortieren (von_Index, nach_Index).
    contextAction(int, str)     : Aktion aus dem Rechtsklickmenü.
    """

    triggered = Signal(int)
    stopRequested = Signal(int)
    soundDropped = Signal(int, str)
    iconDropped = Signal(int, str)
    moveRequested = Signal(int, int)
    contextAction = Signal(int, str)

    def __init__(self, index: int, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.index = index
        self.cfg = SoundButtonConfig()
        self.state = PlaybackState.IDLE
        self.progress = 0.0            # Wiedergabefortschritt 0–1
        self.glow_intensity = 0.8      # aus UI-Settings
        self.dimmed = False            # Suchfilter: nicht passende Buttons
        self.selected = False          # Rubber-Band-Mehrfachauswahl

        self._hover = 0.0              # animierter Hover-Fortschritt 0–1
        self._appear = 1.0             # Einblend-Fortschritt 0–1 (Fade-In)
        self._pressed = False
        self._press_pos: QPoint | None = None   # Startpunkt für Drag-Erkennung
        self._dragging = False                  # läuft ein Reorder-Drag?
        self._ripples: list[_Ripple] = []
        self._spin_angle = 0

        # Paint-Cache: QPainterPath wird nur bei Größenänderung neu berechnet.
        self._cached_path: QPainterPath | None = None
        self._cached_path_size: tuple[int, int] = (-1, -1)

        self.setMinimumSize(120, 120)
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)

        # Animierter Drop-Shadow (Glow bei Hover).
        self._init_shadow()

        # Spinner-Timer für den Loading-Zustand.
        self._spin_timer = QTimer(self)
        self._spin_timer.setInterval(16)
        self._spin_timer.timeout.connect(self._on_spin)

        self._hover_anim: QPropertyAnimation | None = None

    def _init_shadow(self) -> None:
        """(Neu-)Erstellt den Drop-Shadow-Effekt des Buttons.

        Wird auch nach einer Fade-In-Animation aufgerufen, da Qt beim
        Setzen eines anderen GraphicsEffect (z. B. Opacity) den alten
        Shadow löscht.
        Der Blur-Radius wird einmalig auf den Maximalwert gesetzt und
        danach nicht mehr verändert, damit Qt den Blur-Kernel cachen kann.
        """
        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setOffset(0, 6)
        self._shadow.setBlurRadius(50)  # Fixiert – kein Kernel-Rebuild bei Hover
        self._shadow.setColor(QColor(0, 0, 0, 140))
        self.setGraphicsEffect(self._shadow)

    # ------------------------------------------------------------------ #
    # Hover-Property (animierbar)
    # ------------------------------------------------------------------ #
    def _get_hover(self) -> float:
        return self._hover

    def _set_hover(self, value: float) -> None:
        self._hover = value
        # Glow-Schatten: nur Farbe und Offset ändern – Blur-Radius bleibt
        # fix (50px), damit Qt den Gauss-Kernel nicht bei jedem Frame neu
        # berechnen muss (massiver Performance-Gewinn bei vielen Buttons).
        accent = QColor(self.cfg.gradient_color)
        base = QColor(0, 0, 0, 140)
        glow_alpha = int(200 * value * self.glow_intensity)
        color = QColor(accent) if value > 0.05 else base
        color.setAlpha(max(120, glow_alpha) if value > 0.05 else 140)
        self._shadow.setColor(color)
        self._shadow.setOffset(0, 6 - 4 * value)
        self.update()

    hoverProgress = Property(float, _get_hover, _set_hover)

    # ------------------------------------------------------------------ #
    # Appear-Property (Fade-In beim Hinzufügen)
    # ------------------------------------------------------------------ #
    def _get_appear(self) -> float:
        return self._appear

    def _set_appear(self, value: float) -> None:
        self._appear = value
        self.update()

    appearProgress = Property(float, _get_appear, _set_appear)

    # ------------------------------------------------------------------ #
    # Öffentliche API
    # ------------------------------------------------------------------ #
    def set_index(self, index: int) -> None:
        """Aktualisiert den Button-Index (nach Umsortieren/Löschen)."""
        self.index = index

    def apply_config(self, cfg: SoundButtonConfig, glow: float = 0.8) -> None:
        """Übernimmt eine neue Buttonkonfiguration und aktualisiert Optik."""
        self.cfg = cfg
        self.glow_intensity = glow
        parts = [f"<b>{cfg.name}</b>"]
        if cfg.sound_path:
            parts.append(Path(cfg.sound_path).name)
        else:
            parts.append("Kein Sound – Datei hierher ziehen")
        if cfg.hotkey:
            parts.append(f"Globaler Hotkey: {cfg.hotkey}")
        parts.append(f"Taste: {(self.index + 1) % 10}")
        self.setToolTip("<br>".join(parts))
        self.update()

    def set_state(self, state: PlaybackState) -> None:
        """Aktualisiert den Wiedergabestatus inkl. Loading-Spinner."""
        self.state = state
        if state == PlaybackState.LOADING:
            self._spin_timer.start()
        else:
            self._spin_timer.stop()
        if state == PlaybackState.IDLE:
            self.progress = 0.0
        self.update()

    def set_progress(self, value: float) -> None:
        """Setzt den Wiedergabefortschritt (0–1), Repaints gedrosselt.

        Der Player meldet Positionen sehr häufig; neu gezeichnet wird
        nur bei sichtbarer Änderung (≥ 1 %), um Voll-Repaints des
        transparenten Fensters zu vermeiden.
        """
        value = max(0.0, min(1.0, value))
        if abs(value - self.progress) >= 0.01 or value in (0.0, 1.0):
            self.progress = value
            self.update()

    def set_dimmed(self, dimmed: bool) -> None:
        """Blendet den Button für Suchfilter halbtransparent aus."""
        if self.dimmed != dimmed:
            self.dimmed = dimmed
            self.update()

    def set_selected(self, selected: bool) -> None:
        """Markiert den Button (Mehrfachauswahl) und aktualisiert die Optik."""
        if self.selected != selected:
            self.selected = selected
            self.update()

    # ------------------------------------------------------------------ #
    # Painting
    # ------------------------------------------------------------------ #
    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        opacity = 1.0
        if self.dimmed or not self.isEnabled():
            opacity = 0.28
        # Einblend-Animation beim Hinzufügen (Fade-In ohne Graphics-Effekt).
        painter.setOpacity(opacity * self._appear)

        rect = self.rect().adjusted(6, 6, -6, -6)

        # Scale-Animation: leichtes Wachsen bei Hover, Schrumpfen bei Press.
        scale = 1.0 + 0.035 * self._hover - (0.05 if self._pressed else 0.0)
        painter.translate(rect.center())
        painter.scale(scale, scale)
        painter.translate(-rect.center())

        # QPainterPath cachen – addRoundedRect ist nicht trivial und wird
        # sonst bei jedem Frame für jeden Button neu berechnet.
        sz = (rect.width(), rect.height())
        if sz != self._cached_path_size:
            p = QPainterPath()
            p.addRoundedRect(rect, RADIUS, RADIUS)
            self._cached_path = p
            self._cached_path_size = sz
        path = self._cached_path  # type: ignore[assignment]

        # Gradient-Hintergrund.
        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        c1, c2 = QColor(self.cfg.color), QColor(self.cfg.gradient_color)
        c1.setAlpha(230)
        c2.setAlpha(230)
        grad.setColorAt(0.0, c1)
        grad.setColorAt(1.0, c2)
        painter.fillPath(path, grad)

        # Glas-Overlay oben.
        overlay = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        overlay.setColorAt(0.0, QColor(255, 255, 255, 36))
        overlay.setColorAt(0.45, QColor(255, 255, 255, 6))
        overlay.setColorAt(1.0, QColor(0, 0, 0, 40))
        painter.fillPath(path, overlay)

        # Ripple-Effekte (im Button-Clip).
        painter.save()
        painter.setClipPath(path)
        for ripple in self._ripples:
            color = QColor(255, 255, 255)
            color.setAlphaF(max(0.0, ripple.opacity))
            painter.setBrush(color)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawEllipse(ripple.center, ripple.radius, ripple.radius)
        painter.restore()

        # Neon-Rand: Stärke abhängig von Hover/Status.
        border_alpha = int(90 + 165 * self._hover * self.glow_intensity)
        border_color = QColor(self.cfg.gradient_color).lighter(130)
        if self.state == PlaybackState.PLAYING:
            border_color = QColor(Colors.SUCCESS)
            border_alpha = 235
        elif self.state == PlaybackState.ERROR:
            border_color = QColor(Colors.ERROR)
            border_alpha = 235
        border_color.setAlpha(border_alpha)
        painter.setPen(QPen(border_color, 2.0 + 0.8 * self._hover))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        # Auswahl-Markierung (Rubber-Band): heller Ring + Overlay.
        if self.selected:
            sel_color = QColor(Colors.SECONDARY)
            painter.setBrush(QColor(sel_color.red(), sel_color.green(),
                                    sel_color.blue(), 55))
            painter.setPen(QPen(sel_color, 3.5))
            painter.drawPath(path)
            painter.setBrush(Qt.BrushStyle.NoBrush)

        # SVG-Icon.
        icon_size = max(28, int(rect.height() * 0.30))
        pixmap = render_svg_pixmap(self.cfg.icon, self.cfg.text_color, icon_size * 2)
        icon_x = rect.center().x() - icon_size // 2
        icon_y = rect.top() + int(rect.height() * 0.16)
        painter.drawPixmap(icon_x, icon_y, icon_size, icon_size, pixmap)

        # Name.
        painter.setPen(QColor(self.cfg.text_color))
        font = painter.font()
        font.setPointSize(max(9, rect.height() // 15))
        font.setBold(True)
        painter.setFont(font)
        name_rect = rect.adjusted(8, int(rect.height() * 0.50), -8, 0)
        painter.drawText(
            name_rect,
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
            self.cfg.name,
        )

        # Status + Favoriten-Stern.
        status_text = self.state.value
        if self.cfg.favorite:
            status_text = "★ " + status_text
        font.setPointSize(max(7, rect.height() // 20))
        font.setBold(False)
        painter.setFont(font)
        status_color = QColor(self.cfg.text_color)
        status_color.setAlpha(190)
        painter.setPen(status_color)
        status_rect = rect.adjusted(8, int(rect.height() * 0.66), -8, 0)
        painter.drawText(
            status_rect,
            Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
            status_text,
        )

        # Lautstärke-/Fortschrittsbalken unten.
        bar_rect = rect.adjusted(
            int(rect.width() * 0.14),
            rect.height() - 16,
            -int(rect.width() * 0.14),
            -9,
        )
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(0, 0, 0, 90))
        painter.drawRoundedRect(bar_rect, 3, 3)

        fill = self.progress if self.state == PlaybackState.PLAYING else self.cfg.volume
        fill_rect = bar_rect.adjusted(0, 0, -int(bar_rect.width() * (1.0 - fill)), 0)
        painter.setBrush(QColor(255, 255, 255, 210))
        painter.drawRoundedRect(fill_rect, 3, 3)

        # Loading-Spinner.
        if self.state == PlaybackState.LOADING:
            pen = QPen(QColor(255, 255, 255, 220), 3)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            spin_rect = rect.adjusted(
                rect.width() // 2 - 14, rect.height() // 2 - 14,
                -(rect.width() // 2 - 14), -(rect.height() // 2 - 14),
            )
            painter.drawArc(spin_rect, self._spin_angle * 16, 110 * 16)

    # ------------------------------------------------------------------ #
    # Animations-Slots
    # ------------------------------------------------------------------ #
    def _animate_hover(self, target: float) -> None:
        """Startet die weiche Hover-Animation."""
        if self._hover_anim is not None:
            self._hover_anim.stop()
        anim = QPropertyAnimation(self, b"hoverProgress", self)
        anim.setDuration(180)
        anim.setStartValue(self._hover)
        anim.setEndValue(target)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.start()
        self._hover_anim = anim

    def _spawn_ripple(self, pos: QPointF) -> None:
        """Erzeugt einen animierten Ripple am Klickpunkt."""
        ripple = _Ripple(pos)
        self._ripples.append(ripple)
        max_radius = float(max(self.width(), self.height())) * 1.1

        anim = QVariantAnimation(self)
        anim.setDuration(520)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutQuad)

        def _step(v: float) -> None:
            ripple.radius = max_radius * v
            ripple.opacity = 0.45 * (1.0 - v)
            self.update()

        def _done() -> None:
            if ripple in self._ripples:
                self._ripples.remove(ripple)
            self.update()

        anim.valueChanged.connect(lambda v: _step(float(v)))
        anim.finished.connect(_done)
        anim.start(QVariantAnimation.DeletionPolicy.DeleteWhenStopped)

    def _on_spin(self) -> None:
        """Dreht den Loading-Spinner weiter."""
        self._spin_angle = (self._spin_angle - 8) % 360
        self.update()

    # ------------------------------------------------------------------ #
    # Maus-Events
    # ------------------------------------------------------------------ #
    def enterEvent(self, event) -> None:  # noqa: N802
        self._animate_hover(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._animate_hover(0.0)
        super().leaveEvent(event)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed = True
            self._press_pos = event.position().toPoint()
            self._dragging = False
            self._spawn_ripple(event.position())
            self.update()
        elif event.button() == Qt.MouseButton.MiddleButton:
            self.stopRequested.emit(self.index)
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Startet ab einer Mindestdistanz einen Reorder-Drag."""
        if (
            self._pressed
            and self._press_pos is not None
            and not self._dragging
            and event.buttons() & Qt.MouseButton.LeftButton
        ):
            distance = (event.position().toPoint() - self._press_pos).manhattanLength()
            if distance >= QApplication.startDragDistance():
                self._start_reorder_drag()
        super().mouseMoveEvent(event)

    def _start_reorder_drag(self) -> None:
        """Initiiert das Umsortieren dieses Buttons per Drag & Drop."""
        self._dragging = True
        self._pressed = False
        self.update()

        drag = QDrag(self)
        mime = QMimeData()
        mime.setData(MIME_BUTTON_INDEX, str(self.index).encode("ascii"))
        drag.setMimeData(mime)
        # Halbtransparentes Abbild des Buttons als Drag-Vorschau.
        pixmap = self.grab()
        drag.setPixmap(pixmap.scaled(
            pixmap.width() // 2, pixmap.height() // 2,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        ))
        drag.exec(Qt.DropAction.MoveAction)

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and self._pressed:
            self._pressed = False
            self.update()
            if not self._dragging and self.rect().contains(
                event.position().toPoint()
            ):
                self.triggered.emit(self.index)
        super().mouseReleaseEvent(event)

    # ------------------------------------------------------------------ #
    # Drag & Drop
    # ------------------------------------------------------------------ #
    def dragEnterEvent(self, event: QDragEnterEvent) -> None:  # noqa: N802
        """Akzeptiert Audio-/SVG-Dateien sowie andere Buttons (Reorder)."""
        mime = event.mimeData()
        if mime.hasFormat(MIME_BUTTON_INDEX):
            event.acceptProposedAction()
            self._animate_hover(1.0)
            return
        if mime.hasUrls():
            for url in mime.urls():
                suffix = Path(url.toLocalFile()).suffix.lower()
                if suffix in SUPPORTED_AUDIO_FORMATS or suffix == ".svg":
                    event.acceptProposedAction()
                    self._animate_hover(1.0)
                    return
        event.ignore()

    def dragLeaveEvent(self, event) -> None:  # noqa: N802
        self._animate_hover(0.0)
        super().dragLeaveEvent(event)

    def dropEvent(self, event: QDropEvent) -> None:  # noqa: N802
        """Umsortieren (Button) oder Zuweisen (Datei) per Drop."""
        self._animate_hover(0.0)
        mime = event.mimeData()
        if mime.hasFormat(MIME_BUTTON_INDEX):
            try:
                source = int(bytes(mime.data(MIME_BUTTON_INDEX)).decode("ascii"))
            except (ValueError, UnicodeDecodeError):
                event.ignore()
                return
            if source != self.index:
                self.moveRequested.emit(source, self.index)
            event.acceptProposedAction()
            return
        for url in mime.urls():
            local = url.toLocalFile()
            suffix = Path(local).suffix.lower()
            if suffix in SUPPORTED_AUDIO_FORMATS:
                self.soundDropped.emit(self.index, local)
                event.acceptProposedAction()
                return
            if suffix == ".svg":
                self.iconDropped.emit(self.index, local)
                event.acceptProposedAction()
                return
        event.ignore()

    # ------------------------------------------------------------------ #
    # Kontextmenü
    # ------------------------------------------------------------------ #
    def _show_context_menu(self, pos: QPoint) -> None:
        """Zeigt das Rechtsklickmenü mit allen Buttonaktionen."""
        from PySide6.QtWidgets import QMenu

        menu = QMenu(self)
        actions = [
            ("play", "▶  Test abspielen"),
            ("stop", "■  Stoppen"),
            (None, None),
            ("change_sound", "Sound ändern…"),
            ("change_icon", "Icon ändern…"),
            ("change_color", "Farbe ändern…"),
            ("rename", "Name ändern…"),
            ("hotkey", "Hotkey zuweisen…"),
            (None, None),
            ("toggle_loop", ("✔  " if self.cfg.loop else "") + "Loop"),
            ("toggle_favorite", ("✔  " if self.cfg.favorite else "") + "Favorit"),
            (None, None),
            ("move_left", "◀  Nach vorne verschieben"),
            ("move_right", "Nach hinten verschieben  ▶"),
            ("add", "➕  Button hinzufügen"),
            ("delete", "🗑  Diesen Button löschen"),
            (None, None),
            ("clear_sound", "Sound löschen"),
            ("reset", "Button zurücksetzen"),
        ]
        for key, text in actions:
            if key is None:
                menu.addSeparator()
            else:
                action = menu.addAction(text)
                action.setData(key)

        chosen = menu.exec(self.mapToGlobal(pos))
        if chosen is not None:
            self.contextAction.emit(self.index, str(chosen.data()))
