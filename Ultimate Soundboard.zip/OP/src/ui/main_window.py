"""
ui/main_window.py
=================

Frameless-Hauptfenster von Ultimate Soundboard Pro.

Integriert: eigene Titelleiste, 2×5-Soundbutton-Raster, Statusleiste,
Tastenkürzel, globale Hotkeys, Drag&Drop, Suchfilter, Undo/Redo,
Systemmonitor (CPU/RAM/FPS), Toast-Benachrichtigungen sowie
Acrylic-Blur/abgerundete Ecken über die native Windows-API.
"""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QEvent, Qt, QTimer
from PySide6.QtGui import (
    QColor,
    QDragEnterEvent,
    QDropEvent,
    QKeySequence,
    QLinearGradient,
    QMouseEvent,
    QPainter,
    QShortcut,
)
from PySide6.QtWidgets import (
    QColorDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMainWindow,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from core.animation_manager import AnimationManager
from core.audio_manager import AudioManager
from config import (
    APP_NAME,
    MAX_BUTTON_COUNT,
    MIN_BUTTON_COUNT,
    SUPPORTED_AUDIO_FORMATS,
    Colors,
    PlaybackState,
    SoundButtonConfig,
    Theme,
    make_default_button,
)
from core.hotkey_manager import HotkeyManager
from core.settings_manager import SettingsManager
from core.theme_manager import ThemeManager
from ui.dialogs.info_dialog import InfoDialog
from ui.dialogs.settings_dialog import SettingsDialog
from ui.dialogs.toast import ToastManager, ToastType
from ui.title_bar import TitleBar
from ui.widgets.button_grid import SelectableGrid
from ui.widgets.sound_button import SoundButton
from ui.widgets.search_overlay import SearchOverlay
from utils.system_monitor import SystemMonitor
from utils.win_effects import (
    enable_acrylic_blur,
    enable_dark_titlebar,
    enable_rounded_corners,
)
from widget_factory import available_icons
from logger import get_logger

log = get_logger(__name__)

#: Randbreite für das Frameless-Resizing in Pixeln.
RESIZE_MARGIN = 7

#: Kleinste Buttongröße beim responsiven Verkleinern (px).
MIN_BUTTON_SIZE = 96


class MainWindow(QMainWindow):
    """Das zentrale Anwendungsfenster."""

    def __init__(
        self,
        settings: SettingsManager,
        audio: AudioManager,
        theme: ThemeManager,
        animations: AnimationManager,
        hotkeys: HotkeyManager,
    ) -> None:
        super().__init__(None, Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(918, 717)
        self.resize(800, 720)
        self.setAcceptDrops(True)

        self._settings = settings
        self._audio = audio
        self._theme = theme
        self._anim = animations
        self._hotkeys = hotkeys

        self._buttons: list[SoundButton] = []
        self._frame_count = 0
        self._grid_signature: tuple[int, int] = (0, 0)   # (Anzahl, Spalten)
        self._settings_dialog: SettingsDialog | None = None

        self._build_ui()
        self.toasts = ToastManager(self)

        self._connect_signals()
        self._setup_shortcuts()
        self._restore_geometry()
        self.apply_config()

        # Systemmonitor-Thread (CPU/RAM).
        self._monitor = SystemMonitor(parent=self)
        self._monitor.statsUpdated.connect(self.title_bar.update_stats)
        self._monitor.start()

        # FPS-Messung: Frames pro Sekunde über paintEvent-Zähler.
        self._fps_timer = QTimer(self)
        self._fps_timer.timeout.connect(self._update_fps)
        self._fps_timer.start(1000)
        self._last_fps_time = time.monotonic()

        # Debounce-Timer für das responsive Layout bei Fenster-Resize.
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.setInterval(40)  # ~2 Frames @ 60 Hz
        self._resize_timer.timeout.connect(self._apply_responsive_layout)

        # Autoplay-Sounds kurz nach dem Start abspielen.
        QTimer.singleShot(600, self._run_autoplay)

    # ------------------------------------------------------------------ #
    # UI-Aufbau
    # ------------------------------------------------------------------ #
    def _build_ui(self) -> None:
        """Erzeugt Titelleiste, Button-Raster und Statusleiste."""
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(4)

        self.title_bar = TitleBar(self)
        root.addWidget(self.title_bar)

        # Such-Overlay (zentriert, animiert)
        self.search_overlay = SearchOverlay(self)
        self.search_overlay.searchChanged.connect(self._apply_search)
        self.search_overlay.closed.connect(self._on_search_closed)

        # Scrollbarer, selektierbarer Button-Bereich.
        self._grid_container = SelectableGrid()
        self.grid = self._grid_container.grid
        self.grid.setContentsMargins(20, 12, 20, 12)
        self._grid_container.deleteRequested.connect(self._delete_selected)
        self._grid_container.selectionChanged.connect(self._on_selection_changed)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self._grid_container)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        scroll.setStyleSheet("QScrollArea{background:transparent;}")
        scroll.viewport().setStyleSheet("background:transparent;")
        self._scroll = scroll
        root.addWidget(scroll, 1)

        # Statusleiste.
        status = QWidget()
        status_layout = QHBoxLayout(status)
        status_layout.setContentsMargins(14, 2, 14, 4)
        self.status_label = QLabel("Bereit")
        self.status_label.setObjectName("muted")
        self.active_label = QLabel("0 aktiv")
        self.active_label.setObjectName("statValue")
        
        # Lautstärkeregler in Statusleiste
        from widget_factory import make_slider, render_svg_pixmap
        vol_icon = QLabel()
        vol_icon.setPixmap(render_svg_pixmap("volume", Colors.TEXT_MUTED_DARK, 18))
        vol_icon.setToolTip("Globale Lautstärke")
        self.volume_slider = make_slider(0, 100, 90, "Globale Lautstärke", 120)
        self.volume_slider.valueChanged.connect(self._on_global_volume)
        
        add_btn = QPushButton("➥  Button hinzufügen")
        add_btn.setObjectName("accentBtn")
        add_btn.setToolTip("Fügt einen neuen Soundbutton hinzu")
        add_btn.clicked.connect(self._add_button)
        stop_all_btn = QPushButton("■  Stopp  (Leertaste)")
        stop_all_btn.setObjectName("dangerBtn")
        stop_all_btn.clicked.connect(self._stop_all)
        status_layout.addWidget(self.status_label, 1)
        status_layout.addWidget(self.active_label)
        status_layout.addWidget(vol_icon)
        status_layout.addWidget(self.volume_slider)
        status_layout.addWidget(add_btn)
        status_layout.addWidget(stop_all_btn)
        root.addWidget(status)

        self.setCentralWidget(central)

    def _connect_signals(self) -> None:
        """Verdrahtet alle Manager- und Widget-Signale."""
        # Titelleiste.
        tb = self.title_bar
        tb.searchRequested.connect(self._open_search)
        tb.settingsRequested.connect(self.open_settings)
        tb.infoRequested.connect(self._open_info)
        tb.themeToggled.connect(self._toggle_theme)
        tb.minimizeRequested.connect(self.showMinimized)
        tb.maximizeRequested.connect(self._toggle_maximize)
        tb.closeRequested.connect(self.close)

        # Soundbuttons werden dynamisch erzeugt und dort verdrahtet
        # (siehe _create_button).

        # Audio-Engine.
        self._audio.channelStateChanged.connect(self._on_channel_state)
        self._audio.channelProgress.connect(self._on_channel_progress)
        self._audio.soundFinished.connect(self._on_sound_finished)

        # Konfiguration & Hotkeys.
        self._settings.configChanged.connect(self.apply_config)
        self._hotkeys.hotkeyPressed.connect(self._on_global_hotkey)

    def _setup_shortcuts(self) -> None:
        """Registriert alle lokalen Tastenkürzel."""
        # Tasten 1–9 und 0 für die ersten zehn Buttons.
        for i in range(10):
            key = str((i + 1) % 10)
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.activated.connect(lambda idx=i: self._trigger_button(idx))

        QShortcut(QKeySequence(Qt.Key.Key_Space), self).activated.connect(
            self._stop_all
        )
        QShortcut(QKeySequence(Qt.Key.Key_F11), self).activated.connect(
            self._toggle_fullscreen
        )
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self).activated.connect(self.close)
        QShortcut(QKeySequence("Ctrl+S"), self).activated.connect(self.open_settings)
        QShortcut(QKeySequence("Ctrl+F"), self).activated.connect(self._open_search)
        QShortcut(QKeySequence("Ctrl+Z"), self).activated.connect(self._undo)
        QShortcut(QKeySequence("Ctrl+Y"), self).activated.connect(self._redo)

        # Normalisierte Liste aller lokalen Kürzel – damit ein identisch
        # belegter globaler Hotkey bei fokussiertem Fenster nicht doppelt
        # auslöst (lokal + global = Play und sofort wieder Pause).
        local = [str(d) for d in range(10)] + [
            "Space", "F11", "Esc", "Ctrl+S", "Ctrl+F", "Ctrl+Z", "Ctrl+Y",
        ]
        self._local_shortcuts = {QKeySequence(k).toString() for k in local}

    # ------------------------------------------------------------------ #
    # Konfiguration anwenden
    # ------------------------------------------------------------------ #
    def apply_config(self) -> None:
        """Wendet die komplette Konfiguration auf die UI an."""
        cfg = self._settings.config
        ui = cfg.ui

        self._theme.apply(ui)
        self._anim.update_config(ui)
        self.setWindowOpacity(ui.window_opacity)

        # Anzahl der Kanäle und Button-Widgets an die Konfiguration angleichen.
        self._audio.ensure_channels(len(cfg.buttons))
        self._sync_buttons()

        # Buttons aktualisieren (Größe/Spalten übernimmt das responsive Layout).
        for i, btn in enumerate(self._buttons):
            btn.apply_config(cfg.buttons[i], ui.glow_intensity)
            if btn.graphicsEffect() is not None:
                btn.graphicsEffect().setEnabled(ui.shadows_enabled)
        self.grid.setHorizontalSpacing(ui.button_spacing)
        self.grid.setVerticalSpacing(ui.button_spacing)
        self._apply_responsive_layout(force=True)

        # Audio-Einstellungen.
        self._audio.set_master_volume(cfg.audio.master_volume)
        self._audio.set_crossfade(cfg.audio.crossfade_ms)
        self._audio.set_output_device_by_name(cfg.audio.output_device)
        self._audio.set_cable_device_by_name(cfg.audio.cable_device)
        self.volume_slider.blockSignals(True)
        self.volume_slider.setValue(round(cfg.audio.master_volume * 100))
        self.volume_slider.blockSignals(False)

        # Globale Hotkeys neu registrieren.
        self._hotkeys.unregister_all()
        for i, btn_cfg in enumerate(cfg.buttons):
            if btn_cfg.hotkey:
                self._hotkeys.register(i, btn_cfg.hotkey)

        # Native Fenstereffekte aktualisieren.
        self._apply_native_effects()
        self.update()

    def _apply_native_effects(self) -> None:
        """Aktiviert Acrylic-Blur, runde Ecken und Dark-Titlebar."""
        hwnd = int(self.winId())
        enable_rounded_corners(hwnd)
        enable_dark_titlebar(hwnd, self._theme.is_dark)
        enable_acrylic_blur(hwnd, intensity=self._settings.config.ui.blur_intensity)

    # ------------------------------------------------------------------ #
    # Dynamische Button-Verwaltung
    # ------------------------------------------------------------------ #
    def _create_button(self, index: int) -> SoundButton:
        """Erzeugt einen Soundbutton und verbindet dessen Signale."""
        btn = SoundButton(index)
        btn.triggered.connect(self._trigger_button)
        btn.stopRequested.connect(self._stop_button)
        btn.soundDropped.connect(self._assign_sound)
        btn.iconDropped.connect(self._assign_icon)
        btn.moveRequested.connect(self._reorder_buttons)
        btn.contextAction.connect(self._handle_context_action)
        return btn

    def _sync_buttons(self) -> None:
        """
        Gleicht die Button-Widgets an die Konfiguration an.

        Erzeugt oder entfernt Widgets nach Bedarf. Die konkrete
        Rasteranordnung übernimmt danach :meth:`_apply_responsive_layout`.
        """
        count = len(self._settings.config.buttons)

        # Fehlende Buttons anlegen.
        while len(self._buttons) < count:
            self._buttons.append(self._create_button(len(self._buttons)))
        # Überzählige Buttons entfernen.
        while len(self._buttons) > count:
            btn = self._buttons.pop()
            self.grid.removeWidget(btn)
            btn.deleteLater()

        # Indizes auffrischen.
        for i, btn in enumerate(self._buttons):
            btn.set_index(i)

    def _apply_responsive_layout(self, force: bool = False) -> None:
        """
        Passt Spaltenzahl und Buttongröße an die Fensterbreite an.

        Es passen so viele Spalten ins Fenster, wie bei bevorzugter Größe
        Platz finden (max. die eingestellte Spaltenzahl). Reicht der Platz
        nicht, werden die Buttons bis zur Mindestgröße verkleinert.
        """
        count = len(self._buttons)
        if count == 0:
            return
        ui = self._settings.config.ui
        spacing = ui.button_spacing
        margins = self.grid.contentsMargins()
        avail = self._scroll.viewport().width() - margins.left() - margins.right()
        if avail <= 0:
            avail = self.width() - 80

        preferred = ui.button_size
        # Wie viele Buttons in bevorzugter Größe passen nebeneinander?
        # So füllen die Buttons die Breite (kein leerer Rand links/rechts),
        # mindestens jedoch die konfigurierte Spaltenzahl.
        fit_cols = max(1, int((avail + spacing) / (preferred + spacing)))
        max_cols = max(1, min(count, max(ui.grid_columns, fit_cols)))

        # Starte mit der maximalen Spaltenzahl und verkleinere, bis die
        # Buttons passen (mindestens MIN_BUTTON_SIZE).
        cols = max_cols
        size = MIN_BUTTON_SIZE
        while cols >= 1:
            # Berechne die benötigte Größe für diese Spaltenzahl.
            per_col = (avail - spacing * (cols - 1)) / cols
            calculated_size = int(per_col)
            
            # Wenn die Größe >= MIN_BUTTON_SIZE ist, verwenden wir diese Spaltenzahl.
            if calculated_size >= MIN_BUTTON_SIZE:
                # Begrenze auf bevorzugte Größe.
                size = min(preferred, calculated_size)
                break
            # Sonst probieren wir eine Spalte weniger.
            cols -= 1
        
        # Sicherheit: mindestens 1 Spalte und MIN_BUTTON_SIZE.
        cols = max(1, cols)
        size = max(MIN_BUTTON_SIZE, size)

        for b in self._buttons:
            if b.width() != size:
                b.setFixedSize(size, size)

        signature = (count, cols)
        if force or signature != self._grid_signature:
            self._relayout_grid(cols)
            self._grid_signature = signature

        for b in self._buttons:
            if b.width() != size:
                b.setFixedSize(size, size)

        signature = (count, cols)
        if force or signature != self._grid_signature:
            self._relayout_grid(cols)
            self._grid_signature = signature

    def _relayout_grid(self, columns: int) -> None:
        """Platziert alle Buttons zeilenweise im Raster (n Spalten)."""
        while self.grid.count():
            self.grid.takeAt(0)
        for i, btn in enumerate(self._buttons):
            self.grid.addWidget(btn, i // columns, i % columns)
    
    def _animate_new_button(self, index: int) -> None:
        """Animiert einen neu hinzugefügten Button (Fade-In)."""
        if index >= len(self._buttons):
            return
        btn = self._buttons[index]

        from PySide6.QtCore import QPropertyAnimation, QEasingCurve

        # Fade-In über die eigene appearProgress-Property des Buttons –
        # KEIN Graphics-Effekt-Tausch (der würde den Shadow löschen und
        # zu Abstürzen in der Hover-Animation führen).
        btn._set_appear(0.0)
        fade_anim = QPropertyAnimation(btn, b"appearProgress", btn)
        fade_anim.setDuration(400)
        fade_anim.setStartValue(0.0)
        fade_anim.setEndValue(1.0)
        fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        fade_anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def _add_button(self) -> None:
        """Fügt am Ende einen neuen Standardbutton hinzu (mit Fade-In-Animation)."""
        cfg = self._settings.config
        if len(cfg.buttons) >= MAX_BUTTON_COUNT:
            self.toasts.show(
                f"Maximum von {MAX_BUTTON_COUNT} Buttons erreicht.", ToastType.WARNING
            )
            return
        self._settings.push_undo_snapshot()
        new_index = len(cfg.buttons)
        cfg.buttons.append(make_default_button(new_index))
        self._settings.notify_changed()
        
        # Animiere den neuen Button (Fade-In nach kurzer Verzögerung)
        QTimer.singleShot(50, lambda: self._animate_new_button(new_index))
        self.toasts.show("Button hinzugefügt.", ToastType.SUCCESS)

    def _delete_button(self, index: int) -> None:
        """Löscht den Button an Position ``index``."""
        cfg = self._settings.config
        if len(cfg.buttons) <= MIN_BUTTON_COUNT:
            self.toasts.show(
                "Der letzte Button kann nicht gelöscht werden.", ToastType.WARNING
            )
            return
        self._audio.stop_all(fade_ms=0)
        self._settings.push_undo_snapshot()
        del cfg.buttons[index]
        self._settings.notify_changed()
        self.toasts.show("Button gelöscht.", ToastType.INFO)

    def _reorder_buttons(self, source: int, target: int) -> None:
        """Verschiebt einen Button per Drag&Drop von ``source`` nach ``target``."""
        cfg = self._settings.config
        if not (0 <= source < len(cfg.buttons) and 0 <= target < len(cfg.buttons)):
            return
        self._audio.stop_all(fade_ms=0)
        self._settings.push_undo_snapshot()
        moved = cfg.buttons.pop(source)
        cfg.buttons.insert(target, moved)
        self._settings.notify_changed()

    def _move_button(self, index: int, delta: int) -> None:
        """Verschiebt einen Button um ``delta`` Positionen (−1 = vor)."""
        cfg = self._settings.config
        target = index + delta
        if not 0 <= target < len(cfg.buttons):
            return
        self._audio.stop_all(fade_ms=0)
        self._settings.push_undo_snapshot()
        cfg.buttons[index], cfg.buttons[target] = (
            cfg.buttons[target],
            cfg.buttons[index],
        )
        self._settings.notify_changed()

    def _delete_selected(self) -> None:
        """Löscht alle per Rubber-Band markierten Buttons gleichzeitig."""
        indices = self._grid_container.selected_indices()
        if not indices:
            return
        cfg = self._settings.config
        if len(cfg.buttons) - len(indices) < MIN_BUTTON_COUNT:
            self.toasts.show(
                "Es muss mindestens ein Button erhalten bleiben.", ToastType.WARNING
            )
            return
        self._audio.stop_all(fade_ms=0)
        self._settings.push_undo_snapshot()
        for i in sorted(indices, reverse=True):
            del cfg.buttons[i]
        self._settings.notify_changed()
        self.toasts.show(f"{len(indices)} Button(s) gelöscht.", ToastType.INFO)

    def _on_selection_changed(self) -> None:
        """Zeigt die Anzahl markierter Buttons in der Statusleiste an."""
        count = len(self._grid_container.selected_indices())
        if count:
            self.status_label.setText(
                f"{count} Button(s) markiert – Entf zum Löschen"
            )
        else:
            self.status_label.setText("Bereit")

    # ------------------------------------------------------------------ #
    # Sound-Aktionen
    # ------------------------------------------------------------------ #
    def _trigger_button(self, index: int) -> None:
        """Spielt Sound ab (immer von vorn, kein Toggle)."""
        cfg = self._settings.config.buttons[index]
        if not cfg.sound_path:
            self.toasts.show(
                f"'{cfg.name}': Kein Sound zugewiesen – Datei per Drag&Drop ablegen.",
                ToastType.WARNING,
            )
            return
        if not Path(cfg.sound_path).exists():
            self.toasts.show(
                f"Datei fehlt: {Path(cfg.sound_path).name}", ToastType.ERROR
            )
            return

        # Immer von vorn abspielen (restart statt toggle)
        channel = self._audio.channels[index]
        was_idle = not channel.is_playing and not channel.is_paused
        self._audio.play(index, cfg)

        if was_idle:
            cfg.play_count += 1
            self._settings.add_recent_sound(cfg.sound_path)
            self._settings.save()
        self.status_label.setText(f"▶  {cfg.name}")

    def _stop_button(self, index: int) -> None:
        """Stoppt einen einzelnen Kanal."""
        self._audio.stop(index)

    def _stop_all(self) -> None:
        """Stoppt alle Kanäle."""
        if self._audio.active_count() > 0:
            self._audio.stop_all()
            self.toasts.show("Alle Sounds gestoppt.", ToastType.INFO)
        self.status_label.setText("Bereit")

    def _run_autoplay(self) -> None:
        """Spielt alle als Autoplay markierten Sounds nach dem Start."""
        for i, cfg in enumerate(self._settings.config.buttons):
            if cfg.autoplay and cfg.sound_path and Path(cfg.sound_path).exists():
                self._audio.play(i, cfg)

    def _on_global_hotkey(self, index: int) -> None:
        """Reaktion auf systemweite Hotkeys (auch ohne Fokus).

        Ist das Fenster fokussiert und der Hotkey identisch mit einem
        lokalen Kürzel, würde die Aktion doppelt ausgelöst – in dem
        Fall übernimmt das lokale Kürzel.
        """
        if not 0 <= index < len(self._settings.config.buttons):
            return
        seq = self._hotkeys.registered_sequence(index)
        if (
            self.isActiveWindow()
            and QKeySequence(seq).toString() in self._local_shortcuts
        ):
            return
        self._trigger_button(index)

    # ------------------------------------------------------------------ #
    # Audio-Engine-Rückmeldungen
    # ------------------------------------------------------------------ #
    def _on_channel_state(self, index: int, state: PlaybackState) -> None:
        """Aktualisiert Buttonstatus und Statusleiste."""
        if 0 <= index < len(self._buttons):
            self._buttons[index].set_state(state)
        self.active_label.setText(f"{self._audio.active_count()} aktiv")
        if state == PlaybackState.ERROR and index < len(self._settings.config.buttons):
            name = self._settings.config.buttons[index].name
            self.toasts.show(f"'{name}': Audio konnte nicht geladen werden.", ToastType.ERROR)

    def _on_channel_progress(self, index: int, progress: float) -> None:
        if 0 <= index < len(self._buttons):
            self._buttons[index].set_progress(progress)

    def _on_sound_finished(self, index: int, seconds: float) -> None:
        """Sammelt Wiedergabestatistiken."""
        if seconds > 0:
            cfg = self._settings.config
            cfg.buttons[index].total_play_seconds += seconds
            cfg.total_playtime_seconds += seconds
            self._settings.save()
        self.active_label.setText(f"{self._audio.active_count()} aktiv")

    def _on_global_volume(self, volume: int) -> None:
        """Globale Lautstärke aus dem Slider (0–100)."""
        volume_float = volume / 100.0
        self._settings.config.audio.master_volume = volume_float
        self._audio.set_master_volume(volume_float)
        self._settings.save()

    # ------------------------------------------------------------------ #
    # Suche / Filter
    # ------------------------------------------------------------------ #
    def _open_search(self) -> None:
        """Öffnet das animierte Such-Overlay."""
        # Overlay auf das zentrale Widget (ohne Titlebar) legen, bevor es faded.
        central = self.centralWidget()
        if central:
            self.search_overlay.setGeometry(central.geometry())
        self.search_overlay.show_animated()

    def _on_search_closed(self) -> None:
        """Setzt Filter zurück, wenn das Such-Overlay geschlossen wird."""
        self._apply_search("")

    def _apply_search(self, text: str) -> None:
        """Dimmt Buttons, die nicht zum Suchtext passen (Favoriten: '*')."""
        query = text.strip().lower()
        for i, btn in enumerate(self._buttons):
            cfg = self._settings.config.buttons[i]
            if not query:
                match = True
            elif query == "*":
                match = cfg.favorite
            else:
                haystack = f"{cfg.name} {Path(cfg.sound_path).stem}".lower()
                match = query in haystack
            btn.set_dimmed(not match)

    # ------------------------------------------------------------------ #
    # Drag & Drop auf das Fenster (Mehrfach-Import)
    # ------------------------------------------------------------------ #
    def dragEnterEvent(self, event: QDragEnterEvent) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:  # noqa: N802
        """Importiert mehrere Audiodateien auf die ersten freien Buttons."""
        files = [
            url.toLocalFile()
            for url in event.mimeData().urls()
            if Path(url.toLocalFile()).suffix.lower() in SUPPORTED_AUDIO_FORMATS
        ]
        if not files:
            return
        self._settings.push_undo_snapshot()
        assigned = 0
        for path in files:
            target = next(
                (
                    i
                    for i, b in enumerate(self._settings.config.buttons)
                    if not b.sound_path
                ),
                None,
            )
            if target is None:
                break
            cfg = self._settings.config.buttons[target]
            cfg.sound_path = path
            cfg.name = Path(path).stem[:24]
            assigned += 1
        self._settings.notify_changed()
        self.toasts.show(f"{assigned} Sound(s) importiert.", ToastType.SUCCESS)

    # ------------------------------------------------------------------ #
    # Button-Zuweisungen (Drag&Drop auf einzelne Buttons)
    # ------------------------------------------------------------------ #
    def _assign_sound(self, index: int, path: str) -> None:
        self._settings.push_undo_snapshot()
        cfg = self._settings.config.buttons[index]
        cfg.sound_path = path
        if cfg.name.startswith("Sound "):
            cfg.name = Path(path).stem[:24]
        self._settings.add_recent_sound(path)
        self._settings.notify_changed()
        self.toasts.show(f"Sound zugewiesen: {Path(path).name}", ToastType.SUCCESS)

    def _assign_icon(self, index: int, path: str) -> None:
        """Kopiert ein SVG in den Icon-Ordner und weist es dem Button zu."""
        import shutil

        from config import ICONS_DIR

        try:
            target = ICONS_DIR / Path(path).name
            if not target.exists():
                shutil.copyfile(path, target)
            self._settings.push_undo_snapshot()
            self._settings.config.buttons[index].icon = target.stem
            self._settings.notify_changed()
            self.toasts.show(f"Icon zugewiesen: {target.stem}", ToastType.SUCCESS)
        except OSError as exc:
            log.error("Icon-Zuweisung fehlgeschlagen: %s", exc)
            self.toasts.show("Icon konnte nicht kopiert werden.", ToastType.ERROR)

    # ------------------------------------------------------------------ #
    # Kontextmenü-Aktionen
    # ------------------------------------------------------------------ #
    def _handle_context_action(self, index: int, action: str) -> None:
        """Führt eine Aktion aus dem Button-Rechtsklickmenü aus."""
        if not 0 <= index < len(self._settings.config.buttons):
            return
        cfg = self._settings.config.buttons[index]

        if action == "play":
            self._trigger_button(index)
        elif action == "stop":
            self._stop_button(index)
        elif action == "add":
            self._add_button()
        elif action == "delete":
            self._delete_button(index)
        elif action == "move_left":
            self._move_button(index, -1)
        elif action == "move_right":
            self._move_button(index, +1)
        elif action == "change_sound":
            path, _ = QFileDialog.getOpenFileName(
                self, "Sound auswählen", "", "Audiodateien (*.mp3 *.wav *.flac *.ogg)"
            )
            if path:
                self._assign_sound(index, path)
        elif action == "change_icon":
            icons = available_icons()
            name, ok = QInputDialog.getItem(
                self, "Icon wählen", "SVG-Icon:", icons,
                max(0, icons.index(cfg.icon) if cfg.icon in icons else 0), False,
            )
            if ok and name:
                self._settings.push_undo_snapshot()
                cfg.icon = name
                self._settings.notify_changed()
        elif action == "change_color":
            color = QColorDialog.getColor(QColor(cfg.color), self, "Buttonfarbe")
            if color.isValid():
                self._settings.push_undo_snapshot()
                cfg.color = color.name()
                self._settings.notify_changed()
        elif action == "rename":
            name, ok = QInputDialog.getText(
                self, "Name ändern", "Neuer Name:", text=cfg.name
            )
            if ok and name.strip():
                self._settings.push_undo_snapshot()
                cfg.name = name.strip()[:24]
                self._settings.notify_changed()
        elif action == "hotkey":
            if self._settings_dialog is None or not self._settings_dialog.isVisible():
                self.open_settings()
            if self._settings_dialog is not None:
                self._settings_dialog.select_sounds_page(index)
        elif action == "toggle_loop":
            cfg.loop = not cfg.loop
            self._settings.notify_changed()
        elif action == "toggle_favorite":
            cfg.favorite = not cfg.favorite
            self._settings.notify_changed()
        elif action == "clear_sound":
            self._settings.push_undo_snapshot()
            cfg.sound_path = ""
            self._settings.notify_changed()
            self.toasts.show("Sound entfernt.", ToastType.INFO)
        elif action == "reset":
            self._settings.push_undo_snapshot()
            self._settings.config.buttons[index] = SoundButtonConfig(
                name=f"Sound {index + 1}"
            )
            self._settings.notify_changed()

    # ------------------------------------------------------------------ #
    # Dialoge
    # ------------------------------------------------------------------ #
    def open_settings(self) -> None:
        """Öffnet das Einstellungsfenster (nicht mehrfach)."""
        if self._settings_dialog is not None and self._settings_dialog.isVisible():
            self._settings_dialog.raise_()
            return
        self._settings_dialog = SettingsDialog(self._settings, self._audio, self._theme, self)
        self._settings_dialog.show()

    def _open_info(self) -> None:
        """Zeigt den Info-/Statistikdialog."""
        InfoDialog(self._settings.config, self).exec()

    def _toggle_theme(self) -> None:
        """Wechselt zwischen Dark- und Light-Theme."""
        ui = self._settings.config.ui
        ui.theme = (
            Theme.LIGHT.value if ui.theme == Theme.DARK.value else Theme.DARK.value
        )
        self._settings.notify_changed()
        self.toasts.show(
            "Light Mode aktiviert." if ui.theme == Theme.LIGHT.value
            else "Dark Mode aktiviert.",
            ToastType.INFO,
        )

    # ------------------------------------------------------------------ #
    # Undo / Redo
    # ------------------------------------------------------------------ #
    def _undo(self) -> None:
        if self._settings.undo():
            self.toasts.show("Rückgängig gemacht.", ToastType.INFO)

    def _redo(self) -> None:
        if self._settings.redo():
            self.toasts.show("Wiederhergestellt.", ToastType.INFO)

    # ------------------------------------------------------------------ #
    # Fensterverwaltung
    # ------------------------------------------------------------------ #
    def _toggle_maximize(self) -> None:
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()
        self.title_bar.set_maximized(self.isMaximized())

    def _toggle_fullscreen(self) -> None:
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def _restore_geometry(self) -> None:
        """Stellt gespeicherte Fenstergeometrie wieder her."""
        win = self._settings.config.window
        if self._settings.config.save_window_geometry:
            self.setGeometry(win.x, win.y, win.width, win.height)
            if win.maximized:
                self.showMaximized()

    def _save_geometry(self) -> None:
        """Persistiert die aktuelle Fenstergeometrie."""
        if not self._settings.config.save_window_geometry:
            return
        win = self._settings.config.window
        win.maximized = self.isMaximized()
        if not self.isMaximized() and not self.isFullScreen():
            geo = self.geometry()
            win.x, win.y = geo.x(), geo.y()
            win.width, win.height = geo.width(), geo.height()

    # ------------------------------------------------------------------ #
    # Frameless-Resizing an den Fensterkanten
    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Startet natives Resizing, wenn am Fensterrand geklickt wird."""
        if event.button() == Qt.MouseButton.LeftButton and not self.isMaximized():
            edges = self._edge_at(event.position().toPoint())
            if edges and self.windowHandle() is not None:
                self.windowHandle().startSystemResize(edges)
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent) -> None:  # noqa: N802
        """Passt den Cursor an den Fensterkanten an."""
        if not self.isMaximized():
            edges = self._edge_at(event.position().toPoint())
            cursors = {
                Qt.Edge.LeftEdge | Qt.Edge.TopEdge: Qt.CursorShape.SizeFDiagCursor,
                Qt.Edge.RightEdge | Qt.Edge.BottomEdge: Qt.CursorShape.SizeFDiagCursor,
                Qt.Edge.RightEdge | Qt.Edge.TopEdge: Qt.CursorShape.SizeBDiagCursor,
                Qt.Edge.LeftEdge | Qt.Edge.BottomEdge: Qt.CursorShape.SizeBDiagCursor,
                Qt.Edge.LeftEdge: Qt.CursorShape.SizeHorCursor,
                Qt.Edge.RightEdge: Qt.CursorShape.SizeHorCursor,
                Qt.Edge.TopEdge: Qt.CursorShape.SizeVerCursor,
                Qt.Edge.BottomEdge: Qt.CursorShape.SizeVerCursor,
            }
            self.setCursor(cursors.get(edges, Qt.CursorShape.ArrowCursor))
        super().mouseMoveEvent(event)

    def _edge_at(self, pos) -> Qt.Edge:
        """Ermittelt, an welcher Fensterkante sich die Position befindet."""
        edges = Qt.Edge(0)
        if pos.x() <= RESIZE_MARGIN:
            edges |= Qt.Edge.LeftEdge
        if pos.x() >= self.width() - RESIZE_MARGIN:
            edges |= Qt.Edge.RightEdge
        if pos.y() <= RESIZE_MARGIN:
            edges |= Qt.Edge.TopEdge
        if pos.y() >= self.height() - RESIZE_MARGIN:
            edges |= Qt.Edge.BottomEdge
        return edges

    # ------------------------------------------------------------------ #
    # Painting & FPS
    # ------------------------------------------------------------------ #
    def paintEvent(self, event) -> None:  # noqa: N802
        """Zeichnet den Glas-Hintergrund mit dezentem Farbverlauf."""
        self._frame_count += 1
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)

        p = self._theme.palette()
        base = QColor(p["bg"])
        # Bei aktivem Blur halbtransparent für den Acrylic-Effekt.
        alpha = 235 if self._settings.config.ui.blur_intensity <= 0.05 else 200
        base.setAlpha(alpha)

        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        grad.setColorAt(0.0, base)
        tint = QColor(self._theme.accent)
        tint.setAlpha(26)
        grad.setColorAt(1.0, tint)

        painter.setBrush(grad)
        painter.setPen(QColor(self._theme.accent))
        painter.drawRoundedRect(rect, 18, 18)

    def _update_fps(self) -> None:
        """Berechnet FPS aus der Anzahl gezeichneter Frames.

        Die UI ist ereignisgesteuert: Ohne laufende Animationen wird
        schlicht nichts neu gezeichnet – das ist optimal, keine Last.
        In diesem Leerlauf zeigen wir daher die Bildwiederholrate des
        Monitors an; nur während aktiver Animationen die echte Rate.
        """
        now = time.monotonic()
        elapsed = max(0.001, now - self._last_fps_time)
        fps = self._frame_count / elapsed
        self._frame_count = 0
        self._last_fps_time = now

        if fps < 30.0:
            screen = self.screen()
            fps = float(screen.refreshRate()) if screen is not None else 60.0
        self.title_bar.update_fps(min(fps, 480.0))

    def changeEvent(self, event) -> None:  # noqa: N802
        """Synchronisiert das Maximieren-Icon mit dem Fensterzustand."""
        if event.type() == QEvent.Type.WindowStateChange:
            self.title_bar.set_maximized(self.isMaximized())
        super().changeEvent(event)

    def resizeEvent(self, event) -> None:  # noqa: N802
        """Positioniert Toasts neu und passt das Button-Raster an die Größe an."""
        super().resizeEvent(event)
        if getattr(self, "_buttons", None) and hasattr(self, "_scroll"):
            # Debounce: Layout wird erst berechnet, wenn das Resize-Event
            # für ~40 ms nicht mehr gefeuert wird (verhindert Layout-Storms).
            self._resize_timer.start()
        if hasattr(self, "toasts"):
            self.toasts._reposition()
        if hasattr(self, "search_overlay"):
            # Suchleiste auf zentrales Widget beziehen (ohne Titlebar)
            central = self.centralWidget()
            if central:
                self.search_overlay.setGeometry(central.geometry())

    # ------------------------------------------------------------------ #
    # Lebenszyklus
    # ------------------------------------------------------------------ #
    def showEvent(self, event) -> None:  # noqa: N802
        """Aktiviert native Effekte, sobald das Fenster ein Handle besitzt."""
        super().showEvent(event)
        self._apply_native_effects()
        # Layout erst NACH dem ersten vollständigen Render neu berechnen,
        # damit das Scroll-Viewport seine tatsächliche Breite kennt.
        QTimer.singleShot(0, lambda: self._apply_responsive_layout(force=True))

    def closeEvent(self, event) -> None:  # noqa: N802
        """Speichert alles und fährt Threads/Audio sauber herunter."""
        log.info("Anwendung wird beendet …")
        self._save_geometry()
        self._settings.save(immediate=True)
        self._hotkeys.shutdown()
        self._audio.shutdown()
        self._monitor.stop()
        super().closeEvent(event)
