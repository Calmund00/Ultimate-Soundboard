"""
ui/dialogs/settings_dialog.py
=============================

Modernes Einstellungsfenster mit linker Navigation und sechs Seiten:

* Allgemein   – Autostart, Theme, Akzentfarbe, Animationen, Sprache …
* Sounds      – vollständige Konfiguration aller 10 Buttons inkl. Hotkeys
* Oberfläche  – Animationen, Glow, Blur, Größen, Schrift, Transparenz
* Audio       – Ausgabegerät, Test, Latenz, Master-Volume, Balance
* Mikrofon    – Eingabegeräte, Live-Pegel, Sampleraten, Mikrofontest
* Daten       – Import/Export, Backup, Reset
"""
from __future__ import annotations

import math
import struct
import subprocess
import wave
from pathlib import Path

from PySide6.QtCore import QIODevice, Qt, QUrl
from PySide6.QtGui import QColor, QPainter
from PySide6.QtMultimedia import (
    QAudioFormat,
    QAudioSource,
    QMediaDevices,
    QMediaPlayer,
    QAudioOutput,
)
from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFontComboBox,
    QFrame,
    QHBoxLayout,
    QKeySequenceEdit,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSlider,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from core.audio_manager import AudioManager
from config import (
    AUDIO_DIR,
    BACKUP_DIR,
    MAX_BUTTON_COUNT,
    MIN_BUTTON_COUNT,
    Colors,
    Language,
    SoundButtonConfig,
    SUPPORTED_AUDIO_FORMATS,
    Theme,
    make_default_button,
)
from core.settings_manager import SettingsManager
from widget_factory import available_icons, available_sound_icons, make_form_row, make_icon_button, svg_icon
from logger import get_logger

log = get_logger(__name__)

_AUDIO_FILTER = "Audiodateien (*.mp3 *.wav *.flac *.ogg)"


def _ensure_test_tone() -> Path:
    """Erzeugt (einmalig) einen 440-Hz-Testton als WAV-Datei."""
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    path = AUDIO_DIR / "test_tone.wav"
    if not path.exists():
        rate, duration, freq = 44100, 1.0, 440.0
        with wave.open(str(path), "w") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(rate)
            frames = bytearray()
            for i in range(int(rate * duration)):
                # Sanftes Ein-/Ausblenden gegen Knacksen.
                env = min(1.0, i / 2000, (rate * duration - i) / 2000)
                value = int(22000 * env * math.sin(2 * math.pi * freq * i / rate))
                frames += struct.pack("<h", value)
            wav.writeframes(bytes(frames))
        log.info("Testton erzeugt: %s", path)
    return path


class _Page(QScrollArea):
    """Basis: scrollbare Einstellungsseite im Glas-Karten-Look."""

    def __init__(self, title: str) -> None:
        super().__init__()
        self.setWidgetResizable(True)
        self.setStyleSheet(
            "QScrollArea{border:none;background:transparent;}"
            "QScrollArea>QWidget>QWidget{background:transparent;}"
        )
        self._container = QWidget()
        self._outer = QVBoxLayout(self._container)
        self._outer.setContentsMargins(26, 20, 26, 20)
        self._outer.setSpacing(12)

        # Überschrift mit Akzent-Unterstrich (Farbe live aus Palette).
        heading = QLabel(title)
        heading.setObjectName("h1")
        self._outer.addWidget(heading)
        self._accent_bar = QFrame()
        self._accent_bar.setFixedSize(56, 3)
        self._accent_bar.setObjectName("accentBar")
        # Wird in showEvent mit aktueller Farbe befüllt.
        self._outer.addWidget(self._accent_bar)
        self._outer.addSpacing(6)

        # Inhalt liegt in einer Glas-Karte.
        card = QFrame()
        card.setObjectName("settingsCard")
        card.setStyleSheet(
            "QFrame#settingsCard{background:rgba(255,255,255,0.04);"
            "border:1px solid rgba(255,255,255,0.08);border-radius:16px;}"
        )
        self.body = QVBoxLayout(card)
        self.body.setContentsMargins(22, 18, 22, 18)
        self.body.setSpacing(11)
        self._outer.addWidget(card)
        self.setWidget(self._container)

    def finish(self) -> None:
        """Fügt den abschließenden Stretch hinzu (Karte umschließt Inhalt)."""
        self._outer.addStretch(1)

    def showEvent(self, event) -> None:  # noqa: N802
        """Aktualisiert den Akzent-Balken mit der aktuellen Palette-Farbe."""
        super().showEvent(event)
        # Hole Akzentfarbe aus dem globalen Stylesheet-Kontext (über parent-Dialog).
        dialog = self.window()
        a = getattr(getattr(dialog, "_theme", None), "accent", Colors.PRIMARY)
        a_c = QColor(a)
        r, g, b = a_c.red(), a_c.green(), a_c.blue()
        self._accent_bar.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
            f" stop:0 {a},"
            f" stop:1 rgba({r},{g},{b},0.3));"
            "border-radius: 1px; border: none;"
        )


# =========================================================================== #
# Seite: Allgemein
# =========================================================================== #
class GeneralPage(_Page):
    """Allgemeine Programmeinstellungen."""

    def __init__(self, settings: SettingsManager) -> None:
        super().__init__("Allgemein")
        self._s = settings
        cfg = settings.config

        self.autostart = QCheckBox("Mit Windows starten (Autostart)")
        self.autostart.setChecked(cfg.autostart)
        self.autostart.toggled.connect(self._on_autostart)

        self.theme_combo = QComboBox()
        self.theme_combo.addItem("Dark Mode", Theme.DARK.value)
        self.theme_combo.addItem("Light Mode", Theme.LIGHT.value)
        self.theme_combo.setCurrentIndex(0 if cfg.ui.theme == Theme.DARK.value else 1)
        self.theme_combo.currentIndexChanged.connect(self._on_theme)

        self.accent_btn = QPushButton("  Akzentfarbe wählen…")
        self.accent_btn.setIcon(svg_icon("palette", cfg.ui.accent_color, 28))
        self.accent_btn.clicked.connect(self._pick_accent)

        self.animations = QCheckBox("Animationen aktivieren")
        self.animations.setChecked(cfg.ui.animations_enabled)
        self.animations.toggled.connect(self._on_animations)

        self.language = QComboBox()
        self.language.addItem("Deutsch", Language.GERMAN.value)
        self.language.addItem("English", Language.ENGLISH.value)
        self.language.setCurrentIndex(
            0 if cfg.ui.language == Language.GERMAN.value else 1
        )
        self.language.currentIndexChanged.connect(self._on_language)

        self.save_geometry = QCheckBox("Fenstergröße und -position speichern")
        self.save_geometry.setChecked(cfg.save_window_geometry)
        self.save_geometry.toggled.connect(self._on_save_geometry)

        self.save_state = QCheckBox("Letzten Zustand speichern")
        self.save_state.setChecked(cfg.save_last_state)
        self.save_state.toggled.connect(self._on_save_state)

        for w in (
            self.autostart,
            make_form_row("Theme", self.theme_combo),
            make_form_row("Akzentfarbe", self.accent_btn),
            self.animations,
            make_form_row("Sprache", self.language),
            self.save_geometry,
            self.save_state,
        ):
            self.body.addWidget(w)
        self.finish()

    # ------------------------------------------------------------------ #
    def _on_autostart(self, checked: bool) -> None:
        if not self._s.set_autostart(checked):
            self.autostart.blockSignals(True)
            self.autostart.setChecked(not checked)
            self.autostart.blockSignals(False)

    def _on_theme(self) -> None:
        self._s.config.ui.theme = self.theme_combo.currentData()
        self._s.notify_changed()

    def _pick_accent(self) -> None:
        color = QColorDialog.getColor(
            QColor(self._s.config.ui.accent_color), self, "Akzentfarbe wählen"
        )
        if color.isValid():
            self._s.config.ui.accent_color = color.name()
            self.accent_btn.setIcon(svg_icon("palette", color.name(), 28))
            self._s.notify_changed()

    def _on_animations(self, checked: bool) -> None:
        self._s.config.ui.animations_enabled = checked
        self._s.notify_changed()

    def _on_language(self) -> None:
        self._s.config.ui.language = self.language.currentData()
        self._s.notify_changed()

    def _on_save_geometry(self, checked: bool) -> None:
        self._s.config.save_window_geometry = checked
        self._s.save()

    def _on_save_state(self, checked: bool) -> None:
        self._s.config.save_last_state = checked
        self._s.save()


# =========================================================================== #
# Seite: Sounds (alle 10 Buttons)
# =========================================================================== #
class SoundsPage(_Page):
    """Vollständige Konfiguration jedes einzelnen Soundbuttons."""

    def __init__(self, settings: SettingsManager, audio: AudioManager) -> None:
        super().__init__("Sounds")
        self._s = settings
        self._audio = audio
        self._index = 0
        self._loading = False

        # Buttonauswahl
        self.selector = QComboBox()
        self._rebuild_selector()
        self.selector.currentIndexChanged.connect(self._on_select)
        self.body.addWidget(make_form_row("Button auswählen", self.selector))

        # Buttons hinzufügen / löschen
        add_btn = QPushButton("➕  Button hinzufügen")
        add_btn.setObjectName("accentBtn")
        add_btn.clicked.connect(self._add_button)
        del_btn = QPushButton("🗑  Ausgewählten Button löschen")
        del_btn.setObjectName("dangerBtn")
        del_btn.clicked.connect(self._delete_button)
        manage_row = QWidget()
        mng_layout = QHBoxLayout(manage_row)
        mng_layout.setContentsMargins(0, 0, 0, 0)
        mng_layout.addWidget(add_btn)
        mng_layout.addWidget(del_btn)
        self.body.addWidget(manage_row)

        # Aktualisiert die Auswahl, wenn Buttons anderswo geändert werden.
        settings.configChanged.connect(self._on_config_changed)

        # Felder
        self.name_edit = QLineEdit()
        self.name_edit.editingFinished.connect(self._on_name)

        self.sound_edit = QLineEdit()
        self.sound_edit.setReadOnly(True)
        browse = QPushButton("Durchsuchen…")
        browse.clicked.connect(self._pick_sound)
        sound_row = QWidget()
        sr_layout = QHBoxLayout(sound_row)
        sr_layout.setContentsMargins(0, 0, 0, 0)
        sr_layout.addWidget(self.sound_edit, 1)
        sr_layout.addWidget(browse)

        self.icon_combo = QComboBox()
        self.icon_combo.setMaxVisibleItems(16)
        for file_name, display_name in available_sound_icons():
            self.icon_combo.addItem(
                svg_icon(file_name, "#FFFFFF", 28), display_name, userData=file_name
            )
        self.icon_combo.currentIndexChanged.connect(self._on_icon)

        self.color_btn = QPushButton("Buttonfarbe…")
        self.color_btn.clicked.connect(lambda: self._pick_color("color"))
        self.gradient_btn = QPushButton("Gradientfarbe…")
        self.gradient_btn.clicked.connect(lambda: self._pick_color("gradient_color"))
        self.text_btn = QPushButton("Textfarbe…")
        self.text_btn.clicked.connect(lambda: self._pick_color("text_color"))
        colors_row = QWidget()
        cr_layout = QHBoxLayout(colors_row)
        cr_layout.setContentsMargins(0, 0, 0, 0)
        for b in (self.color_btn, self.gradient_btn, self.text_btn):
            cr_layout.addWidget(b)

        self.volume = QSlider(Qt.Orientation.Horizontal)
        self.volume.setRange(0, 100)
        self.volume.valueChanged.connect(self._on_volume)

        self.speed = QDoubleSpinBox()
        self.speed.setRange(0.25, 3.0)
        self.speed.setSingleStep(0.05)
        self.speed.setSuffix(" ×")
        self.speed.valueChanged.connect(self._on_speed)

        self.loop = QCheckBox("Loop aktivieren")
        self.loop.toggled.connect(self._on_loop)
        self.loop_count = QSpinBox()
        self.loop_count.setRange(0, 999)
        self.loop_count.setSpecialValueText("∞ endlos")
        self.loop_count.valueChanged.connect(self._on_loop_count)

        self.autoplay = QCheckBox("Autoplay beim Programmstart")
        self.autoplay.toggled.connect(self._on_autoplay)

        self.fade_in = QSpinBox()
        self.fade_in.setRange(0, 10000)
        self.fade_in.setSuffix(" ms")
        self.fade_in.valueChanged.connect(self._on_fade_in)
        self.fade_out = QSpinBox()
        self.fade_out.setRange(0, 10000)
        self.fade_out.setSuffix(" ms")
        self.fade_out.valueChanged.connect(self._on_fade_out)

        # Globaler Hotkey
        self.hotkey_edit = QKeySequenceEdit()
        self.hotkey_edit.setToolTip(
            "Systemweiter Hotkey – funktioniert auch, wenn die GUI im Hintergrund ist."
        )
        self.hotkey_edit.editingFinished.connect(self._on_hotkey)
        clear_hotkey = QPushButton("Löschen")
        clear_hotkey.clicked.connect(self._clear_hotkey)
        # Maus-Seitentasten (können von QKeySequenceEdit nicht erfasst werden)
        mouse_back_btn = QPushButton("🖱 Zurück")
        mouse_back_btn.setToolTip("Maus-Seitentaste 1 (XButton1) als Hotkey setzen")
        mouse_back_btn.clicked.connect(lambda: self._set_mouse_hotkey("XButton1"))
        mouse_fwd_btn = QPushButton("🖱 Vorwärts")
        mouse_fwd_btn.setToolTip("Maus-Seitentaste 2 (XButton2) als Hotkey setzen")
        mouse_fwd_btn.clicked.connect(lambda: self._set_mouse_hotkey("XButton2"))
        self.hotkey_label = QLabel("—")
        self.hotkey_label.setStyleSheet("color: #8ab4f8; font-weight: bold;")
        hk_row = QWidget()
        hk_layout = QHBoxLayout(hk_row)
        hk_layout.setContentsMargins(0, 0, 0, 0)
        hk_layout.addWidget(self.hotkey_edit, 1)
        hk_layout.addWidget(mouse_back_btn)
        hk_layout.addWidget(mouse_fwd_btn)
        hk_layout.addWidget(clear_hotkey)
        hk_row2 = QWidget()
        hk2_layout = QHBoxLayout(hk_row2)
        hk2_layout.setContentsMargins(0, 0, 0, 0)
        hk2_layout.addWidget(QLabel("Aktiv:"))
        hk2_layout.addWidget(self.hotkey_label, 1)

        # Aktionen
        test_btn = QPushButton("▶  Test")
        test_btn.setObjectName("accentBtn")
        test_btn.clicked.connect(self._test)
        delete_btn = QPushButton("Sound löschen")
        delete_btn.setObjectName("dangerBtn")
        delete_btn.clicked.connect(self._delete_sound)
        reset_btn = QPushButton("Reset")
        reset_btn.clicked.connect(self._reset)
        actions = QWidget()
        act_layout = QHBoxLayout(actions)
        act_layout.setContentsMargins(0, 8, 0, 0)
        for b in (test_btn, delete_btn, reset_btn):
            act_layout.addWidget(b)

        for row in (
            make_form_row("Name", self.name_edit),
            make_form_row("Sounddatei", sound_row),
            make_form_row("SVG-Icon", self.icon_combo),
            make_form_row("Farben", colors_row),
            make_form_row("Lautstärke", self.volume),
            make_form_row("Geschwindigkeit", self.speed),
            make_form_row("Loop", self.loop),
            make_form_row("Loop-Anzahl", self.loop_count),
            make_form_row("Autoplay", self.autoplay),
            make_form_row("Fade-In", self.fade_in),
            make_form_row("Fade-Out", self.fade_out),
            make_form_row("Globaler Hotkey", hk_row),
            hk_row2,
            actions,
        ):
            self.body.addWidget(row)
        self.finish()
        self._load_fields()

    # ------------------------------------------------------------------ #
    @property
    def cfg(self) -> SoundButtonConfig:
        """Konfiguration des aktuell ausgewählten Buttons."""
        self._index = max(0, min(self._index, len(self._s.config.buttons) - 1))
        return self._s.config.buttons[self._index]

    def _rebuild_selector(self) -> None:
        """Baut die Auswahlliste anhand der aktuellen Buttons neu auf."""
        self.selector.blockSignals(True)
        self.selector.clear()
        for i, b in enumerate(self._s.config.buttons):
            self.selector.addItem(f"Button {i + 1} – {b.name}")
        self._index = max(0, min(self._index, len(self._s.config.buttons) - 1))
        self.selector.setCurrentIndex(self._index)
        self.selector.blockSignals(False)

    def _on_config_changed(self) -> None:
        """Reagiert auf externe Änderungen (z. B. Add/Delete im Hauptfenster)."""
        if self.selector.count() != len(self._s.config.buttons):
            self._rebuild_selector()
            self._load_fields()

    def _add_button(self) -> None:
        """Fügt einen neuen Button hinzu und wählt ihn aus."""
        cfg = self._s.config
        if len(cfg.buttons) >= MAX_BUTTON_COUNT:
            return
        self._s.push_undo_snapshot()
        cfg.buttons.append(make_default_button(len(cfg.buttons)))
        self._index = len(cfg.buttons) - 1
        self._rebuild_selector()
        self._load_fields()
        self._s.notify_changed()

    def _delete_button(self) -> None:
        """Löscht den aktuell ausgewählten Button."""
        cfg = self._s.config
        if len(cfg.buttons) <= MIN_BUTTON_COUNT:
            return
        self._audio.stop_all(fade_ms=0)
        self._s.push_undo_snapshot()
        del cfg.buttons[self._index]
        self._index = max(0, self._index - 1)
        self._rebuild_selector()
        self._load_fields()
        self._s.notify_changed()

    def _load_fields(self) -> None:
        """Lädt alle Feldwerte des gewählten Buttons (ohne Signale)."""
        self._loading = True
        c = self.cfg
        self.name_edit.setText(c.name)
        self.sound_edit.setText(c.sound_path)
        # Icon-Combo nach Dateinamen (userData) suchen.
        idx = self.icon_combo.findData(c.icon)
        if idx < 0:
            idx = 0
        self.icon_combo.setCurrentIndex(idx)
        self.volume.setValue(round(c.volume * 100))
        self.speed.setValue(c.speed)
        self.loop.setChecked(c.loop)
        self.loop_count.setValue(c.loop_count)
        self.autoplay.setChecked(c.autoplay)
        self.fade_in.setValue(c.fade_in_ms)
        self.fade_out.setValue(c.fade_out_ms)
        # Maus-Tasten kann QKeySequenceEdit nicht darstellen – daher separat.
        if c.hotkey in ("XButton1", "XButton2"):
            self.hotkey_edit.clear()
        else:
            self.hotkey_edit.setKeySequence(c.hotkey)
        self._update_hotkey_label()
        self._loading = False

    def _commit(self) -> None:
        """Speichert und benachrichtigt die UI (außer während des Ladens)."""
        if not self._loading:
            self._s.notify_changed()

    # ------------------------------------------------------------------ #
    def _on_select(self, index: int) -> None:
        self._index = index
        self._load_fields()

    def _on_name(self) -> None:
        if self._loading:
            return
        self.cfg.name = self.name_edit.text().strip() or f"Sound {self._index + 1}"
        self.selector.setItemText(
            self._index, f"Button {self._index + 1} – {self.cfg.name}"
        )
        self._commit()

    def _pick_sound(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Sound auswählen", "", _AUDIO_FILTER
        )
        if path:
            self._s.push_undo_snapshot()
            self.cfg.sound_path = path
            self.sound_edit.setText(path)
            self._s.add_recent_sound(path)
            self._commit()

    def _on_icon(self, _index: int) -> None:
        name = self.icon_combo.currentData()
        if not self._loading and name:
            self.cfg.icon = name
            self._commit()

    def _pick_color(self, attr: str) -> None:
        current = QColor(getattr(self.cfg, attr))
        color = QColorDialog.getColor(current, self, "Farbe wählen")
        if color.isValid():
            self._s.push_undo_snapshot()
            setattr(self.cfg, attr, color.name())
            self._commit()

    def _on_volume(self, value: int) -> None:
        if not self._loading:
            self.cfg.volume = value / 100.0
            self._audio.set_channel_volume(self._index, self.cfg.volume)
            self._commit()

    def _on_speed(self, value: float) -> None:
        if not self._loading:
            self.cfg.speed = value
            self._commit()

    def _on_loop(self, checked: bool) -> None:
        if not self._loading:
            self.cfg.loop = checked
            self._commit()

    def _on_loop_count(self, value: int) -> None:
        if not self._loading:
            self.cfg.loop_count = value
            self._commit()

    def _on_autoplay(self, checked: bool) -> None:
        if not self._loading:
            self.cfg.autoplay = checked
            self._commit()

    def _on_fade_in(self, value: int) -> None:
        if not self._loading:
            self.cfg.fade_in_ms = value
            self._commit()

    def _on_fade_out(self, value: int) -> None:
        if not self._loading:
            self.cfg.fade_out_ms = value
            self._commit()

    def _on_hotkey(self) -> None:
        if not self._loading:
            self.cfg.hotkey = self.hotkey_edit.keySequence().toString()
            self._update_hotkey_label()
            self._commit()

    def _set_mouse_hotkey(self, button: str) -> None:
        """Setzt eine Maus-Seitentaste (XButton1/XButton2) als Hotkey."""
        self.hotkey_edit.clear()
        self.cfg.hotkey = button
        self._update_hotkey_label()
        self._commit()

    def _clear_hotkey(self) -> None:
        self.hotkey_edit.clear()
        self.cfg.hotkey = ""
        self._update_hotkey_label()
        self._commit()

    def _update_hotkey_label(self) -> None:
        """Aktualisiert die Anzeige des aktuell aktiven Hotkeys."""
        labels = {
            "XButton1": "Maus: Zurück (XButton1)",
            "XButton2": "Maus: Vorwärts (XButton2)",
        }
        hk = self.cfg.hotkey
        self.hotkey_label.setText(labels.get(hk, hk) if hk else "—")

    def _test(self) -> None:
        self._audio.play(self._index, self.cfg)

    def _delete_sound(self) -> None:
        self._s.push_undo_snapshot()
        self.cfg.sound_path = ""
        self.sound_edit.clear()
        self._commit()

    def _reset(self) -> None:
        self._s.push_undo_snapshot()
        self._s.config.buttons[self._index] = SoundButtonConfig(
            name=f"Sound {self._index + 1}"
        )
        self._load_fields()
        self._commit()


# =========================================================================== #
# Seite: Oberfläche
# =========================================================================== #
class InterfacePage(_Page):
    """Optik-Feinjustierung: Animationen, Glow, Blur, Größen, Schrift."""

    def __init__(self, settings: SettingsManager) -> None:
        super().__init__("Oberfläche")
        self._s = settings
        ui = settings.config.ui

        self.anim_speed = self._slider(25, 200, round(ui.animation_speed * 100))
        self.glow = self._slider(0, 100, round(ui.glow_intensity * 100))
        self.blur = self._slider(0, 100, round(ui.blur_intensity * 100))
        self.shadows = QCheckBox("Schatten aktivieren")
        self.shadows.setChecked(ui.shadows_enabled)
        self.btn_size = self._slider(120, 260, ui.button_size)
        self.spacing = self._slider(10, 60, ui.button_spacing)
        self.columns = QSpinBox()
        self.columns.setRange(1, 10)
        self.columns.setValue(ui.grid_columns)
        self.columns.setToolTip(
            "Maximale Spaltenzahl – das Raster passt sich der Fensterbreite an "
            "und verkleinert die Buttons bei Bedarf automatisch."
        )
        self.font_combo = QFontComboBox()
        self.font_combo.setCurrentText(ui.font_family)
        self.font_size = QSpinBox()
        self.font_size.setRange(8, 16)
        self.font_size.setValue(ui.font_size)
        self.opacity = self._slider(60, 100, round(ui.window_opacity * 100))

        self.anim_speed.valueChanged.connect(self._apply)
        self.glow.valueChanged.connect(self._apply)
        self.blur.valueChanged.connect(self._apply)
        self.shadows.toggled.connect(self._apply)
        self.btn_size.valueChanged.connect(self._apply)
        self.spacing.valueChanged.connect(self._apply)
        self.columns.valueChanged.connect(self._apply)
        self.font_combo.currentTextChanged.connect(self._apply)
        self.font_size.valueChanged.connect(self._apply)
        self.opacity.valueChanged.connect(self._apply)

        for row in (
            make_form_row("Animationsgeschwindigkeit", self.anim_speed),
            make_form_row("Glow-Intensität", self.glow),
            make_form_row("Blur-Intensität", self.blur),
            self.shadows,
            make_form_row("Buttongröße", self.btn_size),
            make_form_row("Abstände", self.spacing),
            make_form_row("Max. Raster-Spalten", self.columns),
            make_form_row("Schriftart", self.font_combo),
            make_form_row("Schriftgröße", self.font_size),
            make_form_row("Fenstertransparenz", self.opacity),
        ):
            self.body.addWidget(row)
        self.finish()

    @staticmethod
    def _slider(lo: int, hi: int, value: int) -> QSlider:
        s = QSlider(Qt.Orientation.Horizontal)
        s.setRange(lo, hi)
        s.setValue(value)
        return s

    def _apply(self) -> None:
        """Überträgt alle Werte in die Konfiguration und aktualisiert live."""
        ui = self._s.config.ui
        ui.animation_speed = self.anim_speed.value() / 100.0
        ui.glow_intensity = self.glow.value() / 100.0
        ui.blur_intensity = self.blur.value() / 100.0
        ui.shadows_enabled = self.shadows.isChecked()
        ui.button_size = self.btn_size.value()
        ui.button_spacing = self.spacing.value()
        ui.grid_columns = self.columns.value()
        ui.font_family = self.font_combo.currentText()
        ui.font_size = self.font_size.value()
        ui.window_opacity = self.opacity.value() / 100.0
        self._s.notify_changed()


# =========================================================================== #
# Seite: Audio
# =========================================================================== #
class AudioPage(_Page):
    """Ausgabegerät, Gerätetest, Latenz, Master-Volume, Balance, Crossfade."""

    def __init__(self, settings: SettingsManager, audio: AudioManager) -> None:
        super().__init__("Audio")
        self._s = settings
        self._audio = audio

        self.device_combo = QComboBox()
        self.device_combo.addItem("Systemstandard", "")
        for name in AudioManager.output_devices():
            self.device_combo.addItem(name, name)
        idx = self.device_combo.findData(settings.config.audio.output_device)
        self.device_combo.setCurrentIndex(max(0, idx))
        self.device_combo.currentIndexChanged.connect(self._on_device)

        test_btn = QPushButton("Gerät testen (440 Hz)")
        test_btn.setObjectName("accentBtn")
        test_btn.clicked.connect(self._test_device)

        # Mikrofon-Routing: Zweitausgabe auf ein virtuelles Audiokabel.
        self.cable_combo = QComboBox()
        self.cable_combo.addItem("Deaktiviert", "")
        for name in AudioManager.output_devices():
            self.cable_combo.addItem(name, name)
        idx_cable = self.cable_combo.findData(settings.config.audio.cable_device)
        self.cable_combo.setCurrentIndex(max(0, idx_cable))
        self.cable_combo.currentIndexChanged.connect(self._on_cable)

        cable_hint = QLabel(
            "Damit Sounds „durchs Mikrofon“ zu hören sind, braucht Windows ein "
            "Loopback-Gerät. Der Routing-Assistent prüft automatisch, ob deine "
            "Soundkarte eines eingebaut hat („Stereo Mix“ – keine Zusatzsoftware "
            "nötig!) oder ob ein virtuelles Kabel installiert ist, und richtet "
            "alles ein. Das funktioniert dann in JEDEM Programm mit "
            "Mikrofon-Auswahl (Discord, OBS, Teams, Zoom, Spiele, Browser …)."
        )
        cable_hint.setWordWrap(True)
        cable_hint.setObjectName("muted")

        assist_btn = QPushButton("🔍  Routing-Assistent – automatisch einrichten")
        assist_btn.setObjectName("accentBtn")
        assist_btn.clicked.connect(self._routing_assistant)

        self.latency_label = QLabel("–")
        self.latency_label.setObjectName("statValue")
        self._update_latency()

        self.master = QSlider(Qt.Orientation.Horizontal)
        self.master.setRange(0, 100)
        self.master.setValue(round(settings.config.audio.master_volume * 100))
        self.master.valueChanged.connect(self._on_master)

        self.balance = QSlider(Qt.Orientation.Horizontal)
        self.balance.setRange(-100, 100)
        self.balance.setValue(round(settings.config.audio.balance * 100))
        self.balance.setToolTip(
            "Balance wird gespeichert; Anwendung abhängig vom Audio-Backend."
        )
        self.balance.valueChanged.connect(self._on_balance)

        self.crossfade = QSpinBox()
        self.crossfade.setRange(0, 5000)
        self.crossfade.setSuffix(" ms")
        self.crossfade.setSpecialValueText("Aus")
        self.crossfade.setValue(settings.config.audio.crossfade_ms)
        self.crossfade.valueChanged.connect(self._on_crossfade)

        for row in (
            make_form_row("Audio-Ausgabegerät", self.device_combo),
            test_btn,
            make_form_row("Mikrofon-Routing (Kabel)", self.cable_combo),
            cable_hint,
            assist_btn,
            make_form_row("Latenz (nominal)", self.latency_label),
            make_form_row("Master Volume", self.master),
            make_form_row("Balance", self.balance),
            make_form_row("Crossfade", self.crossfade),
        ):
            self.body.addWidget(row)
        self.finish()

        # Dedizierter Player für den Gerätetest.
        self._test_output = QAudioOutput(self)
        self._test_player = QMediaPlayer(self)
        self._test_player.setAudioOutput(self._test_output)

    # ------------------------------------------------------------------ #
    def _on_device(self) -> None:
        name = self.device_combo.currentData()
        self._s.config.audio.output_device = name
        self._audio.set_output_device_by_name(name)
        self._update_latency()
        self._s.save()

    def _on_cable(self) -> None:
        """Aktiviert/deaktiviert das Mikrofon-Routing auf das Kabel."""
        name = self.cable_combo.currentData()
        self._s.config.audio.cable_device = name
        self._audio.set_cable_device_by_name(name)
        self._s.save()

    # ------------------------------------------------------------------ #
    def _routing_assistant(self) -> None:
        """
        Erkennt vorhandene Loopback-Möglichkeiten und richtet sie ein.

        Priorität:
        1. Virtuelles Kabel (falls installiert) → automatisch aktivieren.
        2. Hardware-Loopback der Soundkarte („Stereo Mix“) → Anleitung,
           komplett ohne Zusatzsoftware.
        3. Nichts gefunden → Windows-Aufnahmegeräte öffnen, da „Stereo
           Mix“ dort oft nur deaktiviert ist. Ein virtuelles Mikrofon
           ohne Gerät ist unter Windows nicht möglich (signierter
           Kernel-Treiber erforderlich).
        """
        inputs = [d.description() for d in QMediaDevices.audioInputs()]
        outputs = AudioManager.output_devices()

        cable_in = next(
            (n for n in outputs if "cable input" in n.lower() or "vb-audio" in n.lower()),
            "",
        )
        cable_out = next(
            (n for n in inputs if "cable output" in n.lower() or "vb-audio" in n.lower()),
            "CABLE Output",
        )
        loopback_keys = (
            "stereo mix", "stereomix", "what u hear", "wave out mix",
            "loopback", "summe", "stereomischung",
        )
        stereo_mix = next(
            (n for n in inputs if any(k in n.lower() for k in loopback_keys)), ""
        )

        if cable_in:
            idx = self.cable_combo.findData(cable_in)
            if idx >= 0:
                self.cable_combo.setCurrentIndex(idx)  # aktiviert Routing
            QMessageBox.information(
                self,
                "Routing eingerichtet",
                f"Virtuelles Kabel gefunden und aktiviert:\n\u2022 {cable_in}\n\n"
                f"Letzter Schritt: In jedem Programm, das ein Mikrofon nutzt "
                f"(Discord, OBS, Teams, Zoom, Spiele, Browser …), als "
                f"Mikrofon\n\u2022 {cable_out}\nauswählen. Fertig – gilt überall!",
            )
            return

        if stereo_mix:
            QMessageBox.information(
                self,
                "Loopback ohne Zusatzsoftware gefunden",
                f"Deine Soundkarte hat ein eingebautes Loopback-Gerät:\n"
                f"\u2022 {stereo_mix}\n\n"
                "So nutzt du es (keine Installation nötig):\n"
                f"1. In JEDEM Programm mit Mikrofon-Auswahl (Discord, OBS, "
                f"Teams, Zoom, Spiele, Browser …) „{stereo_mix}“ als Mikrofon "
                "wählen.\n"
                "2. Soundboard-Ausgabe auf dein normales Gerät lassen.\n\n"
                "Hinweis: Stereo Mix überträgt den gesamten PC-Sound "
                "(inkl. Musik/Spiel), nicht nur das Soundboard.",
            )
            return

        answer = QMessageBox.question(
            self,
            "Kein Loopback-Gerät aktiv",
            "Es wurde kein aktives Loopback-Gerät gefunden.\n\n"
            "Bei vielen Soundkarten (z. B. Realtek) ist „Stereo Mix“ nur "
            "deaktiviert. Soll ich die Windows-Aufnahmegeräte öffnen?\n\n"
            "Dort: Rechtsklick → „Deaktivierte Geräte anzeigen“ → "
            "„Stereo Mix“ → „Aktivieren“. Danach den Assistenten erneut "
            "starten.\n\n"
            "Technischer Hintergrund: Ein virtuelles Mikrofon erfordert "
            "unter Windows einen von Microsoft signierten Kernel-Treiber – "
            "das kann keine normale Anwendung selbst bereitstellen.",
        )
        if answer == QMessageBox.StandardButton.Yes:
            try:
                # Öffnet direkt den Reiter „Aufnahme“ der Sound-Systemsteuerung.
                subprocess.Popen(["control", "mmsys.cpl,,1"])
            except OSError as exc:
                log.error("Sound-Systemsteuerung konnte nicht geöffnet werden: %s", exc)

    def _update_latency(self) -> None:
        """Zeigt eine nominale Latenzschätzung des gewählten Geräts."""
        device = QMediaDevices.defaultAudioOutput()
        wanted = self.device_combo.currentData() if hasattr(self, "device_combo") else ""
        for dev in QMediaDevices.audioOutputs():
            if dev.description() == wanted:
                device = dev
                break
        fmt = device.preferredFormat()
        rate = fmt.sampleRate() or 48000
        # Nominale Schätzung: typische Puffergröße von 2048 Frames.
        latency_ms = 2048 / rate * 1000
        self.latency_label.setText(
            f"≈ {latency_ms:.0f} ms  ({rate} Hz, {fmt.channelCount()} Kanäle)"
        )

    def _test_device(self) -> None:
        """Spielt den 440-Hz-Testton auf dem gewählten Gerät ab."""
        try:
            tone = _ensure_test_tone()
            wanted = self.device_combo.currentData()
            device = QMediaDevices.defaultAudioOutput()
            for dev in QMediaDevices.audioOutputs():
                if dev.description() == wanted:
                    device = dev
                    break
            self._test_output.setDevice(device)
            self._test_output.setVolume(self._s.config.audio.master_volume)
            self._test_player.setSource(QUrl.fromLocalFile(str(tone)))
            self._test_player.play()
        except Exception as exc:  # noqa: BLE001
            log.error("Gerätetest fehlgeschlagen: %s", exc)

    def _on_master(self, value: int) -> None:
        self._s.config.audio.master_volume = value / 100.0
        self._audio.set_master_volume(value / 100.0)
        self._s.save()

    def _on_balance(self, value: int) -> None:
        self._s.config.audio.balance = value / 100.0
        self._s.save()

    def _on_crossfade(self, value: int) -> None:
        self._s.config.audio.crossfade_ms = value
        self._audio.set_crossfade(value)
        self._s.save()


# =========================================================================== #
# Seite: Mikrofon
# =========================================================================== #
class MicrophonePage(_Page):
    """Mikrofonauswahl mit Live-Pegelanzeige und Format-Informationen."""

    def __init__(self, settings: SettingsManager) -> None:
        super().__init__("Mikrofon")
        self._s = settings
        self._source: QAudioSource | None = None
        self._io: QIODevice | None = None

        self.device_combo = QComboBox()
        self.device_combo.addItem("Systemstandard", "")
        for dev in QMediaDevices.audioInputs():
            self.device_combo.addItem(dev.description(), dev.description())
        idx = self.device_combo.findData(settings.config.audio.input_device)
        self.device_combo.setCurrentIndex(max(0, idx))
        self.device_combo.currentIndexChanged.connect(self._on_device)

        self.name_label = QLabel("–")
        self.rate_label = QLabel("–")
        self.bits_label = QLabel("–")
        for lbl in (self.name_label, self.rate_label, self.bits_label):
            lbl.setObjectName("statValue")

        self.level_bar = QProgressBar()
        self.level_bar.setRange(0, 100)
        self.level_bar.setValue(0)

        self.level_label = QLabel("Eingangspegel: –")
        self.level_label.setObjectName("muted")

        self.test_btn = QPushButton("Mikrofontest starten")
        self.test_btn.setObjectName("accentBtn")
        self.test_btn.setCheckable(True)
        self.test_btn.toggled.connect(self._toggle_test)

        for row in (
            make_form_row("Mikrofon", self.device_combo),
            make_form_row("Gerätename", self.name_label),
            make_form_row("Samplerate", self.rate_label),
            make_form_row("Bittiefe", self.bits_label),
            make_form_row("Live-Pegel", self.level_bar),
            self.level_label,
            self.test_btn,
        ):
            self.body.addWidget(row)
        self.finish()
        self._update_info()

    # ------------------------------------------------------------------ #
    def _current_device(self):
        """Liefert das gewählte (oder Standard-) Eingabegerät."""
        wanted = self.device_combo.currentData()
        for dev in QMediaDevices.audioInputs():
            if dev.description() == wanted:
                return dev
        return QMediaDevices.defaultAudioInput()

    def _update_info(self) -> None:
        """Aktualisiert die Format-Infos des gewählten Geräts."""
        dev = self._current_device()
        if dev.isNull():
            self.name_label.setText("Kein Mikrofon gefunden")
            return
        fmt = dev.preferredFormat()
        self.name_label.setText(dev.description())
        self.rate_label.setText(f"{fmt.sampleRate()} Hz")
        bits = {"UInt8": 8, "Int16": 16, "Int32": 32, "Float": 32}.get(
            fmt.sampleFormat().name, 16
        )
        bitrate = fmt.sampleRate() * fmt.channelCount() * bits
        self.bits_label.setText(f"{bits} Bit  (≈ {bitrate // 1000} kbit/s)")

    def _on_device(self) -> None:
        self._s.config.audio.input_device = self.device_combo.currentData()
        self._s.save()
        self._update_info()
        if self.test_btn.isChecked():
            self._toggle_test(False)
            self.test_btn.setChecked(False)

    # ------------------------------------------------------------------ #
    def _toggle_test(self, active: bool) -> None:
        """Startet/stoppt den Live-Pegelmesser."""
        if active:
            try:
                dev = self._current_device()
                fmt = QAudioFormat()
                fmt.setSampleRate(44100)
                fmt.setChannelCount(1)
                fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
                if not dev.isFormatSupported(fmt):
                    fmt = dev.preferredFormat()
                self._source = QAudioSource(dev, fmt, self)
                self._io = self._source.start()
                if self._io is not None:
                    self._io.readyRead.connect(self._read_level)
                self.test_btn.setText("Mikrofontest stoppen")
            except Exception as exc:  # noqa: BLE001
                log.error("Mikrofontest fehlgeschlagen: %s", exc)
                self.test_btn.setChecked(False)
        else:
            if self._source is not None:
                self._source.stop()
                self._source = None
                self._io = None
            self.level_bar.setValue(0)
            self.level_label.setText("Eingangspegel: –")
            self.test_btn.setText("Mikrofontest starten")

    def _read_level(self) -> None:
        """Berechnet den RMS-Pegel aus den 16-Bit-Rohsamples."""
        if self._io is None:
            return
        data = bytes(self._io.readAll())
        if len(data) < 2:
            return
        count = len(data) // 2
        samples = struct.unpack(f"<{count}h", data[: count * 2])
        rms = math.sqrt(sum(s * s for s in samples) / count) / 32768.0
        percent = min(100, int(rms * 300))
        self.level_bar.setValue(percent)
        db = 20 * math.log10(rms) if rms > 0 else -96.0
        self.level_label.setText(f"Eingangspegel: {db:.1f} dB")

    def stop_capture(self) -> None:
        """Beendet die Aufnahme beim Schließen des Dialogs."""
        if self.test_btn.isChecked():
            self.test_btn.setChecked(False)


# =========================================================================== #
# Seite: Daten
# =========================================================================== #
class DataPage(_Page):
    """Import, Export, Backup und Zurücksetzen der Konfiguration."""

    def __init__(self, settings: SettingsManager) -> None:
        super().__init__("Daten")
        self._s = settings

        import_btn = QPushButton("Konfiguration importieren…")
        import_btn.clicked.connect(self._import)
        export_btn = QPushButton("Konfiguration exportieren…")
        export_btn.clicked.connect(self._export)
        backup_btn = QPushButton("Backup erstellen")
        backup_btn.setObjectName("accentBtn")
        backup_btn.clicked.connect(self._backup)
        restore_btn = QPushButton("Backup wiederherstellen…")
        restore_btn.clicked.connect(self._restore)
        reset_btn = QPushButton("Konfiguration zurücksetzen")
        reset_btn.setObjectName("dangerBtn")
        reset_btn.clicked.connect(self._reset)

        for b in (import_btn, export_btn, backup_btn, restore_btn, reset_btn):
            self.body.addWidget(b)
        self.finish()

    def _import(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Konfiguration importieren", "", "JSON (*.json)"
        )
        if path and not self._s.import_config(Path(path)):
            QMessageBox.warning(self, "Import", "Die Datei konnte nicht importiert werden.")

    def _export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Konfiguration exportieren", "soundboard_config.json", "JSON (*.json)"
        )
        if path and not self._s.export_config(Path(path)):
            QMessageBox.warning(self, "Export", "Der Export ist fehlgeschlagen.")

    def _backup(self) -> None:
        target = self._s.create_backup()
        if target is not None:
            QMessageBox.information(self, "Backup", f"Backup erstellt:\n{target}")
        else:
            QMessageBox.warning(self, "Backup", "Backup fehlgeschlagen.")

    def _restore(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Backup wiederherstellen", str(BACKUP_DIR), "JSON (*.json)"
        )
        if path and not self._s.restore_backup(Path(path)):
            QMessageBox.warning(self, "Backup", "Wiederherstellung fehlgeschlagen.")

    def _reset(self) -> None:
        answer = QMessageBox.question(
            self,
            "Zurücksetzen",
            "Wirklich alle Einstellungen auf Werkszustand zurücksetzen?",
        )
        if answer == QMessageBox.StandardButton.Yes:
            self._s.reset_config()


# =========================================================================== #
# Seite: Lizenzen
# =========================================================================== #
class LicensePage(_Page):
    """Open-Source-Attributionen und Urheberrechtshinweise."""

    _ENTRIES: list[tuple[str, str, str, str]] = [
        (
            "Ultimate Soundboard ",
            "Proprietäre Software · Alle Rechte vorbehalten",
            "© 2026 UltimateSoft.  Dieses Produkt und sein Quellcode sind "
            "urheberrechtlich geschützt.  Weitervertrieb, Dekompilierung oder "
            "Reverse Engineering ohne ausdrückliche schriftliche Genehmigung "
            "ist untersagt.",
            "#A78BFA",   # Violett
        ),
        (
            "PySide6 / Qt Framework",
            "GNU Lesser General Public License v3 (LGPL v3)",
            "Qt ist ein plattformübergreifendes Anwendungs-Framework.  Dieses "
            "Produkt verwendet PySide6 unter den Bedingungen der LGPL v3.  "
            "Die Qt-Bibliotheken liegen als austauschbare Einzeldateien vor.\n"
            "https://www.qt.io/licensing",
            "#4FC3F7",   # Blau
        ),
        (
            "Material Design Icons",
            "Apache License 2.0",
            "Die verwendeten Icons stammen aus dem Material Design Icons-Set "
            "von Google LLC.  Nutzung gemäß den Bedingungen der Apache 2.0 Lizenz.\n"
            "https://fonts.google.com/icons",
            "#81C784",   # Grün
        ),
        (
            "psutil",
            "BSD 3-Clause License",
            "Plattformübergreifende Bibliothek für Systeminformationen (CPU, RAM).  "
            "Copyright © 2009–2024 Giampaolo Rodolà.\n"
            "https://github.com/giampaolo/psutil",
            "#FFB74D",   # Orange
        ),
    ]

    def __init__(self) -> None:
        super().__init__("Lizenzen")
        for name, lic_type, desc, color in self._ENTRIES:
            self._add_entry(name, lic_type, desc, color)
        self.finish()

    def _add_entry(self, name: str, lic_type: str, desc: str, color: str) -> None:
        """Erstellt eine Lizenzkarte mit farbigem Akzentstreifen."""
        row = QFrame()
        row.setObjectName("licEntry")
        row.setStyleSheet(
            f"QFrame#licEntry{{"
            f"  border-left: 3px solid {color};"
            "  background: rgba(255,255,255,0.04);"
            "  border-radius: 10px;"
            "}"
        )
        layout = QVBoxLayout(row)
        layout.setContentsMargins(14, 10, 10, 10)
        layout.setSpacing(4)

        name_lbl = QLabel(name)
        name_lbl.setStyleSheet(
            "font-weight: 600; font-size: 13px;"
            "background: transparent; border: none;"
        )
        lic_lbl = QLabel(lic_type)
        lic_lbl.setStyleSheet(
            f"color: {color}; font-size: 11px;"
            "background: transparent; border: none;"
        )
        desc_lbl = QLabel(desc)
        desc_lbl.setStyleSheet(
            "color: rgba(220,220,220,0.60); font-size: 11px;"
            "background: transparent; border: none;"
        )
        desc_lbl.setWordWrap(True)

        layout.addWidget(name_lbl)
        layout.addWidget(lic_lbl)
        layout.addWidget(desc_lbl)
        self.body.addWidget(row)


# =========================================================================== #
# Hauptdialog
# =========================================================================== #
class SettingsDialog(QDialog):
    """Frameless Einstellungsfenster mit Navigation links."""

    PAGES = ("Allgemein", "Sounds", "Oberfläche", "Audio", "Mikrofon", "Daten", "Lizenzen")

    def __init__(
        self,
        settings: SettingsManager,
        audio: AudioManager,
        theme,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setModal(True)
        self.resize(920, 660)
        self._theme = theme

        # Akzentfarbe + abgeleitete Varianten dynamisch aus dem Theme.
        self._build_ui(settings, audio)

    def _build_ui(self, settings: SettingsManager, audio: AudioManager) -> None:
        """Erstellt die komplette UI mit dynamischer Akzentfarbe."""
        from core.theme_manager import mix, with_alpha

        a = self._theme.accent          # aktuelle Akzentfarbe
        a_c = QColor(a)
        a_rgba = (a_c.red(), a_c.green(), a_c.blue())

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 18)
        root.setSpacing(12)

        # Kopfzeile: Logo-Icon + Titel + Untertitel + Schließen.
        head = QHBoxLayout()
        head.setSpacing(12)
        logo = QLabel()
        logo.setPixmap(svg_icon("settings", a, 56).pixmap(28, 28))
        logo.setFixedSize(44, 44)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet(
            f"background: rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]}, 0.15);"
            f"border: 1px solid rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]}, 0.40);"
            "border-radius: 12px;"
        )
        self._logo_badge = logo  # Referenz für Refresh
        title_box = QVBoxLayout()
        title_box.setSpacing(0)
        title = QLabel("Einstellungen")
        title.setObjectName("h1")
        subtitle = QLabel("Passe dein Soundboard an deine Wünsche an")
        subtitle.setObjectName("muted")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        close_btn = make_icon_button("close", "Schließen")
        close_btn.clicked.connect(self.accept)
        head.addWidget(logo)
        head.addLayout(title_box)
        head.addStretch(1)
        head.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignTop)
        root.addLayout(head)

        # Trennlinie unter dem Header – in Akzentfarbe.
        divider = QFrame()
        divider.setFixedHeight(1)
        divider.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
            f" stop:0 rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]},0.6),"
            f" stop:0.5 rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]},0.18),"
            f" stop:1 transparent); border: none;"
        )
        self._header_divider = divider  # Referenz für Refresh
        root.addWidget(divider)

        # Navigation + Seiten.
        content = QHBoxLayout()
        content.setSpacing(14)

        # Navigation in eigenem Glas-Panel.
        nav_panel = QFrame()
        nav_panel.setObjectName("navPanel")
        nav_panel.setFixedWidth(200)
        nav_panel.setStyleSheet(
            "QFrame#navPanel{background:rgba(255,255,255,0.03);"
            "border:1px solid rgba(255,255,255,0.07);border-radius:14px;}"
        )
        nav_layout = QVBoxLayout(nav_panel)
        nav_layout.setContentsMargins(6, 10, 6, 10)

        self.nav = QListWidget()
        self._nav_icons = ("settings", "music", "palette", "volume", "mic", "folder", "shield")
        self._apply_nav_style(a, a_rgba)
        for name, icon in zip(self.PAGES, self._nav_icons):
            item_icon = svg_icon(icon, a, 32)
            self.nav.addItem(name)
            self.nav.item(self.nav.count() - 1).setIcon(item_icon)
        nav_layout.addWidget(self.nav)

        self.stack = QStackedWidget()
        self.general_page = GeneralPage(settings)
        self.sounds_page = SoundsPage(settings, audio)
        self.interface_page = InterfacePage(settings)
        self.audio_page = AudioPage(settings, audio)
        self.mic_page = MicrophonePage(settings)
        self.data_page = DataPage(settings)
        self.license_page = LicensePage()
        for page in (
            self.general_page,
            self.sounds_page,
            self.interface_page,
            self.audio_page,
            self.mic_page,
            self.data_page,
            self.license_page,
        ):
            self.stack.addWidget(page)

        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)

        content.addWidget(nav_panel)
        content.addWidget(self.stack, 1)
        root.addLayout(content, 1)

        # Accent sofort aktualisieren wenn sich Einstellungen ändern.
        settings.configChanged.connect(self._refresh_accent)

    def _apply_nav_style(self, a: str, a_rgba: tuple) -> None:
        """Setzt das dynamische Nav-Stylesheet."""
        self.nav.setStyleSheet(f"""
            QListWidget {{
                background: transparent; border: none; outline: none;
            }}
            QListWidget::item {{
                padding: 12px 14px;
                border-radius: 10px;
                margin: 3px 4px;
                color: {Colors.TEXT_MUTED_DARK};
            }}
            QListWidget::item:hover {{
                background: rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]}, 0.15);
                color: {Colors.TEXT_DARK};
            }}
            QListWidget::item:selected {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]},0.40),
                    stop:1 rgba({a_rgba[0]},{a_rgba[1]},{a_rgba[2]},0.12));
                border-left: 3px solid {a};
                color: {Colors.TEXT_DARK};
                font-weight: 600;
            }}
        """)

    # ------------------------------------------------------------------ #
    def select_sounds_page(self, button_index: int) -> None:
        """Öffnet direkt die Sounds-Seite für einen bestimmten Button."""
        self.nav.setCurrentRow(1)
        self.sounds_page.selector.setCurrentIndex(button_index)

    def _refresh_accent(self) -> None:
        """Aktualisiert alle akzentfarbigen Elemente sofort (ohne Neustart)."""
        a = self._theme.accent
        a_c = QColor(a)
        r, g, b = a_c.red(), a_c.green(), a_c.blue()
        a_rgba = (r, g, b)

        # Logo-Badge
        self._logo_badge.setPixmap(svg_icon("settings", a, 56).pixmap(28, 28))
        self._logo_badge.setStyleSheet(
            f"background: rgba({r},{g},{b}, 0.15);"
            f"border: 1px solid rgba({r},{g},{b}, 0.40);"
            "border-radius: 12px;"
        )
        # Trennlinie
        self._header_divider.setStyleSheet(
            f"background: qlineargradient(x1:0, y1:0, x2:1, y2:0,"
            f" stop:0 rgba({r},{g},{b},0.6),"
            f" stop:0.5 rgba({r},{g},{b},0.18),"
            f" stop:1 transparent); border: none;"
        )
        # Nav-Stylesheet + Icons
        self._apply_nav_style(a, a_rgba)
        for i, icon in enumerate(self._nav_icons):
            self.nav.item(i).setIcon(svg_icon(icon, a, 32))
        # Rahmen neu zeichnen
        self.update()

    def showEvent(self, event) -> None:  # noqa: N802
        """Begrenzt den Dialog auf das Hauptfenster und zentriert ihn darin."""
        super().showEvent(event)
        parent = self.parentWidget()
        if parent is not None:
            win = parent.window()
            geo = win.geometry()
            margin = 24
            w = min(self.width(), geo.width() - margin * 2)
            h = min(self.height(), geo.height() - margin * 2)
            self.resize(w, h)
            self.move(
                geo.x() + (geo.width() - w) // 2,
                geo.y() + (geo.height() - h) // 2,
            )

    def paintEvent(self, event) -> None:  # noqa: N802
        """Glas-Hintergrund mit sanftem Verlauf und dynamischem Akzentrand."""
        from PySide6.QtGui import QLinearGradient, QPen

        a = self._theme.accent
        a_c = QColor(a)
        r, g, b = a_c.red(), a_c.green(), a_c.blue()

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(2, 2, -2, -2)

        grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
        grad.setColorAt(0.0, QColor(19, 22, 34, 250))
        grad.setColorAt(0.5, QColor(13, 15, 22, 250))
        grad.setColorAt(1.0, QColor(16, 14, 28, 250))
        painter.setBrush(grad)

        pen = QPen(QColor(r, g, b, 160), 1.4)
        painter.setPen(pen)
        painter.drawRoundedRect(rect, 20, 20)

    def closeEvent(self, event) -> None:  # noqa: N802
        """Stoppt die Mikrofonaufnahme beim Schließen."""
        self.mic_page.stop_capture()
        super().closeEvent(event)

    def accept(self) -> None:  # noqa: D102
        self.mic_page.stop_capture()
        super().accept()
