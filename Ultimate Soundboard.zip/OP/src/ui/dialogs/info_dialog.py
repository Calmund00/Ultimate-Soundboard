"""
ui/dialogs/info_dialog.py
=========================

Info- und Statistik-Dialog: App-Informationen, Nutzungsstatistiken
(Wiedergaben pro Button, Gesamtdauer) sowie zuletzt verwendete Sounds.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from config import APP_NAME, APP_VERSION, AppConfig, Colors
from widget_factory import render_svg_pixmap
from logger import get_logger

log = get_logger(__name__)


def _format_duration(seconds: float) -> str:
    """Formatiert Sekunden als ``h:mm:ss``."""
    total = int(seconds)
    h, rest = divmod(total, 3600)
    m, s = divmod(rest, 60)
    return f"{h}:{m:02d}:{s:02d}"


class InfoDialog(QDialog):
    """Modaler Info-/Statistikdialog im Glas-Design."""

    def __init__(self, config: AppConfig, parent: QWidget | None = None) -> None:
        super().__init__(parent, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setModal(True)
        self.setFixedSize(520, 560)
        self._build_ui(config)

    # ------------------------------------------------------------------ #
    def _build_ui(self, config: AppConfig) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(14)

        # Kopfzeile
        head = QHBoxLayout()
        logo = QLabel()
        logo.setPixmap(render_svg_pixmap("logo", Colors.PRIMARY, 40))
        title_box = QVBoxLayout()
        title = QLabel(APP_NAME)
        title.setObjectName("h1")
        subtitle = QLabel(f"Version {APP_VERSION} · PySide6 / Qt6")
        subtitle.setObjectName("muted")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        head.addWidget(logo)
        head.addSpacing(12)
        head.addLayout(title_box)
        head.addStretch(1)
        layout.addLayout(head)

        # Globale Statistik
        total = QLabel(
            f"Gesamte Wiedergabedauer: "
            f"<span style='color:{Colors.SECONDARY}; font-weight:600;'>"
            f"{_format_duration(config.total_playtime_seconds)}</span>"
        )
        layout.addWidget(total)

        # Button-Statistiken (scrollbar)
        stats_head = QLabel("Statistik pro Button")
        stats_head.setObjectName("h2")
        layout.addWidget(stats_head)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;}")
        inner = QWidget()
        inner_layout = QVBoxLayout(inner)
        inner_layout.setSpacing(4)

        ranked = sorted(
            enumerate(config.buttons), key=lambda x: x[1].play_count, reverse=True
        )
        for idx, btn in ranked:
            fav = "★ " if btn.favorite else ""
            row = QLabel(
                f"{fav}<b>{btn.name}</b> (Button {idx + 1}) — "
                f"{btn.play_count}× gespielt, "
                f"{_format_duration(btn.total_play_seconds)}"
            )
            row.setStyleSheet(
                "background:rgba(255,255,255,0.04); border-radius:8px; padding:7px 10px;"
            )
            inner_layout.addWidget(row)

        # Zuletzt verwendete Sounds
        if config.recent_sounds:
            recent_head = QLabel("Zuletzt verwendet")
            recent_head.setObjectName("h2")
            inner_layout.addSpacing(8)
            inner_layout.addWidget(recent_head)
            for path in config.recent_sounds[:5]:
                lbl = QLabel(Path(path).name)
                lbl.setObjectName("muted")
                inner_layout.addWidget(lbl)

        inner_layout.addStretch(1)
        scroll.setWidget(inner)
        layout.addWidget(scroll, 1)

        close_btn = QPushButton("Schließen")
        close_btn.setObjectName("accentBtn")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    # ------------------------------------------------------------------ #
    def paintEvent(self, event) -> None:  # noqa: N802
        """Glas-Hintergrund mit Akzentrand."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(2, 2, -2, -2)
        painter.setBrush(QColor(16, 18, 28, 246))
        painter.setPen(QColor(Colors.PRIMARY))
        painter.drawRoundedRect(rect, 20, 20)
