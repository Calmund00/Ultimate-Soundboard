"""
ui/dialogs/toast.py
===================

Moderne Toast-Benachrichtigungen: frameless, halbtransparent,
mit Slide-In/Fade-Out-Animation. Mehrere Toasts stapeln sich
am unteren rechten Rand des Hauptfensters.
"""
from __future__ import annotations

from enum import Enum

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, Qt, QTimer
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QHBoxLayout, QLabel, QWidget

from config import Colors
from widget_factory import render_svg_pixmap
from logger import get_logger

log = get_logger(__name__)


class ToastType(Enum):
    """Art der Benachrichtigung – bestimmt Farbe und Icon."""

    INFO = (Colors.SECONDARY, "info")
    SUCCESS = (Colors.SUCCESS, "check")
    WARNING = (Colors.WARNING, "warning")
    ERROR = (Colors.ERROR, "warning")


class Toast(QWidget):
    """Einzelne Toast-Nachricht mit Ein-/Ausblendanimation."""

    HEIGHT = 46
    DURATION_MS = 2800

    def __init__(self, parent: QWidget, message: str, toast_type: ToastType) -> None:
        super().__init__(parent)
        self._color = toast_type.value[0]
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setFixedHeight(self.HEIGHT)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(14, 6, 18, 6)
        layout.setSpacing(10)

        icon = QLabel()
        icon.setPixmap(render_svg_pixmap(toast_type.value[1], self._color, 20))
        text = QLabel(message)
        text.setStyleSheet(f"color:{Colors.TEXT_DARK}; font-size:12px;")
        layout.addWidget(icon)
        layout.addWidget(text)
        self.adjustSize()

    def paintEvent(self, event) -> None:  # noqa: N802
        """Zeichnet den Glas-Hintergrund mit farbigem Akzentrand."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(1, 1, -1, -1)
        painter.setBrush(QColor(21, 24, 35, 242))
        painter.setPen(QColor(self._color))
        painter.drawRoundedRect(rect, 12, 12)


class ToastManager:
    """Verwaltet gestapelte Toasts über dem Hauptfenster."""

    MARGIN = 24
    SPACING = 8

    def __init__(self, host: QWidget) -> None:
        self._host = host
        self._toasts: list[Toast] = []

    def show(self, message: str, toast_type: ToastType = ToastType.INFO) -> None:
        """Zeigt eine neue Toast-Nachricht mit Slide-In-Animation."""
        try:
            toast = Toast(self._host, message, toast_type)
            self._toasts.append(toast)
            self._reposition()
            toast.show()
            toast.raise_()

            # Slide-In von rechts.
            end = toast.pos()
            start = end + QPoint(60, 0)
            toast.move(start)
            anim = QPropertyAnimation(toast, b"pos", toast)
            anim.setDuration(280)
            anim.setStartValue(start)
            anim.setEndValue(end)
            anim.setEasingCurve(QEasingCurve.Type.OutBack)
            anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

            QTimer.singleShot(Toast.DURATION_MS, lambda: self._dismiss(toast))
        except Exception as exc:  # noqa: BLE001 - UI-Extra darf nie crashen
            log.debug("Toast-Fehler: %s", exc)

    def _dismiss(self, toast: Toast) -> None:
        """Blendet einen Toast weich aus und entfernt ihn."""
        if toast not in self._toasts:
            return
        anim = QPropertyAnimation(toast, b"windowOpacity", toast)
        anim.setDuration(250)
        anim.setStartValue(1.0)
        anim.setEndValue(0.0)

        def _cleanup() -> None:
            if toast in self._toasts:
                self._toasts.remove(toast)
            toast.deleteLater()
            self._reposition()

        anim.finished.connect(_cleanup)
        anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def _reposition(self) -> None:
        """Stapelt alle aktiven Toasts unten rechts."""
        x_right = self._host.width() - self.MARGIN
        y = self._host.height() - self.MARGIN
        for toast in reversed(self._toasts):
            y -= toast.height()
            toast.move(x_right - toast.width(), y)
            y -= self.SPACING
