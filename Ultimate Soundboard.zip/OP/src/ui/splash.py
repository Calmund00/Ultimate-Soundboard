"""
ui/splash.py
============

Animierter Startbildschirm: Logo mit Glow, Fade-In und sanftem Zoom,
anschließend weicher Übergang ins Hauptfenster.
"""
from __future__ import annotations

from PySide6.QtCore import (
    QEasingCurve,
    QPropertyAnimation,
    QRect,
    Qt,
    QTimer,
    Signal,
)
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QLabel, QVBoxLayout, QWidget

from config import APP_NAME, APP_VERSION, Colors
from widget_factory import render_svg_pixmap
from logger import get_logger

log = get_logger(__name__)


class SplashScreen(QWidget):
    """
    Frameless, transparenter Splash-Screen mit Startanimation.

    Signals
    -------
    finished
        Wird nach Abschluss der Ausblend-Animation ausgelöst.
    """

    finished = Signal()

    LOGO_SIZE = 128
    DISPLAY_MS = 1800

    def __init__(self) -> None:
        super().__init__(
            None,
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.SplashScreen
            | Qt.WindowType.WindowStaysOnTopHint,
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(460, 340)

        self._build_ui()
        self._center_on_screen()

    # ------------------------------------------------------------------ #
    def _build_ui(self) -> None:
        """Erzeugt Logo, Titel und Glow-Effekte."""
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(18)

        self._logo = QLabel()
        self._logo.setPixmap(
            render_svg_pixmap("logo", Colors.PRIMARY, self.LOGO_SIZE)
        )
        self._logo.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Neon-Glow um das Logo.
        self._glow = QGraphicsDropShadowEffect(self._logo)
        self._glow.setColor(QColor(Colors.ACCENT))
        self._glow.setBlurRadius(0)
        self._glow.setOffset(0, 0)
        self._logo.setGraphicsEffect(self._glow)

        self._title = QLabel(APP_NAME)
        self._title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        font = QFont("Segoe UI", 20)
        font.setBold(True)
        self._title.setFont(font)
        self._title.setStyleSheet(f"color: {Colors.TEXT_DARK};")

        self._subtitle = QLabel(f"Version {APP_VERSION}")
        self._subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._subtitle.setStyleSheet(f"color: {Colors.TEXT_MUTED_DARK};")

        layout.addWidget(self._logo)
        layout.addWidget(self._title)
        layout.addWidget(self._subtitle)

    def _center_on_screen(self) -> None:
        """Zentriert den Splash auf dem primären Bildschirm."""
        screen = self.screen().availableGeometry()
        self.move(screen.center() - self.rect().center())

    # ------------------------------------------------------------------ #
    def paintEvent(self, event) -> None:  # noqa: N802
        """Zeichnet den halbtransparenten Glas-Hintergrund mit Neon-Rand."""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self.rect().adjusted(10, 10, -10, -10)
        painter.setBrush(QColor(13, 15, 22, 235))
        painter.setPen(QColor(Colors.PRIMARY))
        painter.drawRoundedRect(rect, 24, 24)

    # ------------------------------------------------------------------ #
    def start(self) -> None:
        """Startet die komplette Splash-Sequenz."""
        self.setWindowOpacity(0.0)
        self.show()

        # Fade-In des Fensters.
        self._fade_in = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade_in.setDuration(500)
        self._fade_in.setStartValue(0.0)
        self._fade_in.setEndValue(1.0)
        self._fade_in.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_in.start()

        # Glow-Pulse des Logos.
        self._glow_anim = QPropertyAnimation(self._glow, b"blurRadius", self)
        self._glow_anim.setDuration(1100)
        self._glow_anim.setStartValue(0.0)
        self._glow_anim.setEndValue(60.0)
        self._glow_anim.setEasingCurve(QEasingCurve.Type.OutQuad)
        self._glow_anim.start()

        # Leichtes Zoomen über die Fenstergeometrie.
        geo = self.geometry()
        zoomed = QRect(geo.x() - 12, geo.y() - 9, geo.width() + 24, geo.height() + 18)
        self._zoom = QPropertyAnimation(self, b"geometry", self)
        self._zoom.setDuration(self.DISPLAY_MS)
        self._zoom.setStartValue(geo)
        self._zoom.setEndValue(zoomed)
        self._zoom.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._zoom.start()

        QTimer.singleShot(self.DISPLAY_MS, self._fade_out)

    def _fade_out(self) -> None:
        """Sanfter Übergang: Splash ausblenden und `finished` melden."""
        self._out = QPropertyAnimation(self, b"windowOpacity", self)
        self._out.setDuration(400)
        self._out.setStartValue(1.0)
        self._out.setEndValue(0.0)
        self._out.setEasingCurve(QEasingCurve.Type.InCubic)
        self._out.finished.connect(self._on_done)
        self._out.start()

    def _on_done(self) -> None:
        self.close()
        self.finished.emit()
