"""
theme_manager.py
================

Erzeugt und appliziert das komplette Qt-Stylesheet (QSS) der Anwendung.

Unterstützt Dark- und Light-Theme, frei wählbare Akzentfarbe sowie
konfigurierbare Schriftart/-größe. Das Design orientiert sich am
Windows-11-Fluent-Stil mit Glas-Optik und Neon-Akzenten.
"""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QColor, QFont
from PySide6.QtWidgets import QApplication

from config import CONFIG_DIR, Colors, ICONS_DIR, Theme, UIConfig
from logger import get_logger

log = get_logger(__name__)


def mix(color: str, other: str, ratio: float) -> str:
    """Mischt zwei Hex-Farben. ``ratio`` = Anteil von ``other`` (0–1)."""
    c1, c2 = QColor(color), QColor(other)
    r = round(c1.red() + (c2.red() - c1.red()) * ratio)
    g = round(c1.green() + (c2.green() - c1.green()) * ratio)
    b = round(c1.blue() + (c2.blue() - c1.blue()) * ratio)
    return QColor(r, g, b).name()


def with_alpha(color: str, alpha: float) -> str:
    """Hex-Farbe als rgba()-String mit Alpha (0–1)."""
    c = QColor(color)
    return f"rgba({c.red()}, {c.green()}, {c.blue()}, {int(alpha * 255)})"


class ThemeManager(QObject):
    """
    Verwaltet Theme, Akzentfarbe und Stylesheet der Anwendung.

    Signals
    -------
    themeChanged
        Nach jedem Anwenden des Stylesheets.
    """

    themeChanged = Signal()

    def __init__(self, app: QApplication, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._app = app
        self._ui = UIConfig()

    # ------------------------------------------------------------------ #
    @property
    def is_dark(self) -> bool:
        """``True``, wenn aktuell das Dark-Theme aktiv ist."""
        return self._ui.theme == Theme.DARK.value

    @property
    def accent(self) -> str:
        """Aktuelle Akzentfarbe (Hex)."""
        return self._ui.accent_color

    def palette(self) -> dict[str, str]:
        """Liefert alle aktuellen Themenfarben als Dictionary."""
        if self.is_dark:
            return {
                "bg": Colors.BG_DARK,
                "surface": Colors.SURFACE_DARK,
                "surface2": Colors.SURFACE_DARK_2,
                "border": Colors.BORDER_DARK,
                "text": Colors.TEXT_DARK,
                "muted": Colors.TEXT_MUTED_DARK,
            }
        return {
            "bg": Colors.BG_LIGHT,
            "surface": Colors.SURFACE_LIGHT,
            "surface2": Colors.SURFACE_LIGHT_2,
            "border": Colors.BORDER_LIGHT,
            "text": Colors.TEXT_LIGHT,
            "muted": Colors.TEXT_MUTED_LIGHT,
        }

    # ------------------------------------------------------------------ #
    def apply(self, ui: UIConfig) -> None:
        """Wendet Theme + Schrift gemäß UI-Konfiguration global an."""
        self._ui = ui
        font = QFont(ui.font_family, ui.font_size)
        font.setHintingPreference(QFont.HintingPreference.PreferFullHinting)
        self._app.setFont(font)
        self._app.setStyleSheet(self._build_stylesheet())
        self.themeChanged.emit()
        log.debug("Theme angewendet: %s / Akzent %s", ui.theme, ui.accent_color)

    def _checkmark_url(self, color: str) -> str:
        """Erzeugt (gecacht) ein eingefärbtes Häkchen-SVG für QSS ``image:``."""
        cache_dir = CONFIG_DIR / "cache"
        path = cache_dir / f"check_{color.lstrip('#')}.svg"
        if not path.exists():
            try:
                cache_dir.mkdir(parents=True, exist_ok=True)
                svg = (ICONS_DIR / "check.svg").read_text(encoding="utf-8")
                path.write_text(
                    svg.replace("currentColor", color), encoding="utf-8"
                )
            except OSError:
                log.warning("Häkchen-Icon konnte nicht erzeugt werden.")
                return ""
        return path.as_posix()

    # ------------------------------------------------------------------ #
    def _build_stylesheet(self) -> str:
        """Erzeugt das vollständige QSS-Stylesheet."""
        p = self.palette()
        a = self.accent
        a_hover = mix(a, "#FFFFFF", 0.18)
        a_soft = with_alpha(a, 0.28)
        glass = with_alpha(p["surface"], 0.86 if self.is_dark else 0.92)
        check_url = self._checkmark_url(a)

        return f"""
/* ------------------------------- Basis ------------------------------- */
QWidget {{
    color: {p['text']};
    background: transparent;
    font-family: "{self._ui.font_family}";
}}
QMainWindow, QDialog {{
    background: transparent;
}}
QToolTip {{
    background: {p['surface2']};
    color: {p['text']};
    border: 1px solid {a_soft};
    border-radius: 8px;
    padding: 6px 10px;
}}

/* ------------------------------ Buttons ------------------------------ */
QPushButton {{
    background: {p['surface2']};
    border: 1px solid {p['border']};
    border-radius: 10px;
    padding: 7px 16px;
    color: {p['text']};
}}
QPushButton:hover {{
    background: {mix(p['surface2'], a, 0.22)};
    border-color: {a};
}}
QPushButton:pressed {{
    background: {mix(p['surface2'], a, 0.38)};
}}
QPushButton:disabled {{
    color: {p['muted']};
    border-color: {p['border']};
    background: {p['surface']};
}}
QPushButton#accentBtn {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 {a}, stop:1 {mix(a, Colors.SECONDARY, 0.6)});
    border: none;
    color: white;
    font-weight: 600;
}}
QPushButton#accentBtn:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 {a_hover}, stop:1 {Colors.SECONDARY});
}}
QPushButton#dangerBtn {{
    background: {with_alpha(Colors.ERROR, 0.18)};
    border: 1px solid {Colors.ERROR};
    color: {Colors.ERROR};
}}
QPushButton#dangerBtn:hover {{
    background: {with_alpha(Colors.ERROR, 0.35)};
    color: white;
}}

/* ------------------------- Eingabeelemente --------------------------- */
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox, QKeySequenceEdit {{
    background: {p['surface2']};
    border: 1px solid {p['border']};
    border-radius: 9px;
    padding: 6px 10px;
    selection-background-color: {a};
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QComboBox:focus, QKeySequenceEdit:focus {{
    border: 1px solid {a};
}}
QComboBox::drop-down {{ border: none; width: 26px; }}
QComboBox QAbstractItemView {{
    background: {p['surface2']};
    border: 1px solid {a_soft};
    border-radius: 10px;
    selection-background-color: {a_soft};
    outline: none;
}}

/* ------------------------------ Slider ------------------------------- */
QSlider::groove:horizontal {{
    height: 6px;
    background: {p['border']};
    border-radius: 3px;
}}
QSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {a}, stop:1 {Colors.SECONDARY});
    border-radius: 3px;
}}
QSlider::handle:horizontal {{
    background: white;
    width: 16px; height: 16px;
    margin: -5px 0;
    border-radius: 8px;
    border: 2px solid {a};
}}
QSlider::handle:horizontal:hover {{
    background: {a_hover};
}}

/* --------------------------- Checkbox/Radio -------------------------- */
QCheckBox, QRadioButton {{ spacing: 8px; }}
QCheckBox::indicator, QRadioButton::indicator {{
    width: 18px; height: 18px;
    border: 2px solid {p['border']};
    border-radius: 5px;
    background: {p['surface2']};
}}
QRadioButton::indicator {{ border-radius: 10px; }}
QCheckBox::indicator:checked {{
    background: {p['surface2']};
    border-color: {a};
    image: url("{check_url}");
}}
QRadioButton::indicator:checked {{
    background: {p['surface2']};
    border-color: {a};
    image: url("{check_url}");
}}
QCheckBox::indicator:hover, QRadioButton::indicator:hover {{
    border-color: {a};
}}

/* ---------------------------- Scrollbars ----------------------------- */
QScrollBar:vertical {{
    background: transparent; width: 10px; margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {p['border']}; border-radius: 5px; min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{ background: {a}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{
    background: transparent; height: 10px; margin: 2px;
}}
QScrollBar::handle:horizontal {{
    background: {p['border']}; border-radius: 5px; min-width: 30px;
}}

/* ------------------------------ Listen ------------------------------- */
QListWidget {{
    background: transparent;
    border: none;
    outline: none;
}}
QListWidget::item {{
    padding: 11px 14px;
    border-radius: 10px;
    margin: 2px 6px;
    color: {p['muted']};
}}
QListWidget::item:hover {{
    background: {with_alpha(a, 0.12)};
    color: {p['text']};
}}
QListWidget::item:selected {{
    background: {a_soft};
    color: {p['text']};
    font-weight: 600;
}}

/* ------------------------------- Menüs ------------------------------- */
QMenu {{
    background: {glass};
    border: 1px solid {a_soft};
    border-radius: 12px;
    padding: 6px;
}}
QMenu::item {{
    padding: 7px 26px 7px 14px;
    border-radius: 8px;
}}
QMenu::item:selected {{ background: {a_soft}; }}
QMenu::separator {{
    height: 1px; background: {p['border']}; margin: 5px 10px;
}}

/* ---------------------------- ProgressBar ---------------------------- */
QProgressBar {{
    background: {p['border']};
    border: none;
    border-radius: 5px;
    height: 10px;
    text-align: center;
    color: transparent;
}}
QProgressBar::chunk {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {Colors.SUCCESS}, stop:0.7 {Colors.SECONDARY}, stop:1 {a});
    border-radius: 5px;
}}

/* ------------------------------- Labels ------------------------------ */
QLabel#h1 {{ font-size: 20px; font-weight: 700; }}
QLabel#h2 {{ font-size: 15px; font-weight: 600; }}
QLabel#muted {{ color: {p['muted']}; }}
QLabel#statValue {{ color: {Colors.SECONDARY}; font-weight: 600; }}
"""
