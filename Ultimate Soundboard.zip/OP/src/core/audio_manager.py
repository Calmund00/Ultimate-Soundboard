"""
audio_manager.py
================

Asynchrone Audio-Engine auf Basis von Qt Multimedia.

* 10 unabhängige Kanäle (:class:`SoundChannel`) – mehrere Sounds gleichzeitig
* Play / Pause / Resume / Stop / Stop All
* Loop mit konfigurierbarer Anzahl (0 = endlos)
* Fade-In, Fade-Out und Crossfade über :class:`QVariantAnimation`
* Lautstärke und Geschwindigkeit pro Kanal, Master-Volume global
* Auswahl des Audio-Ausgabegeräts
* Wiedergabe-Statistiken (Anzahl, Dauer)

Qt Multimedia arbeitet intern asynchron (eigene Backend-Threads),
sodass der GUI-Thread niemals blockiert wird.
"""
from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QObject, QUrl, QVariantAnimation, Signal
from PySide6.QtMultimedia import QAudioOutput, QMediaDevices, QMediaPlayer

from config import (
    DEFAULT_BUTTON_COUNT,
    MAX_BUTTON_COUNT,
    MIN_BUTTON_COUNT,
    SUPPORTED_AUDIO_FORMATS,
    PlaybackState,
    SoundButtonConfig,
)
from logger import get_logger

log = get_logger(__name__)


class SoundChannel(QObject):
    """
    Ein einzelner Wiedergabekanal (entspricht genau einem Soundbutton).

    Signals
    -------
    stateChanged(int, object)
        ``(index, PlaybackState)`` bei jeder Statusänderung.
    progressChanged(int, float)
        ``(index, fortschritt 0..1)`` während der Wiedergabe.
    playbackFinished(int, float)
        ``(index, abgespielte_sekunden)`` nach Ende/Stop.
    """

    stateChanged = Signal(int, object)
    progressChanged = Signal(int, float)
    playbackFinished = Signal(int, float)

    def __init__(self, index: int, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.index = index
        self.state = PlaybackState.IDLE

        self._output = QAudioOutput(self)
        self._player = QMediaPlayer(self)
        self._player.setAudioOutput(self._output)

        # Optionale Zweitausgabe: spiegelt die Wiedergabe auf ein
        # virtuelles Audiokabel (Mikrofon-Routing für Discord & Co.).
        self._cable_device = None
        self._cable_output: QAudioOutput | None = None
        self._cable_player: QMediaPlayer | None = None

        self._target_volume = 0.8      # Kanal-Lautstärke (ohne Master)
        self._master_volume = 0.9
        self._loops_remaining = 0      # -1 = endlos
        self._fade_out_ms = 300
        self._fade_anim: QVariantAnimation | None = None
        self._play_started: float = 0.0

        self._player.mediaStatusChanged.connect(self._on_media_status)
        self._player.errorOccurred.connect(self._on_error)
        self._player.positionChanged.connect(self._on_position)

    # ------------------------------------------------------------------ #
    # Eigenschaften
    # ------------------------------------------------------------------ #
    @property
    def is_playing(self) -> bool:
        """``True`` bei aktiver Wiedergabe."""
        return self.state == PlaybackState.PLAYING

    @property
    def is_paused(self) -> bool:
        """``True`` bei pausierter Wiedergabe."""
        return self.state == PlaybackState.PAUSED

    def set_output_device(self, device) -> None:
        """Setzt das Audio-Ausgabegerät des Kanals."""
        self._output.setDevice(device)

    def set_cable_device(self, device) -> None:
        """
        Setzt die Zweitausgabe (virtuelles Kabel) oder deaktiviert sie.

        :param device: ``QAudioDevice`` oder ``None`` zum Deaktivieren.
        """
        self._cable_device = device
        if device is None:
            if self._cable_player is not None:
                self._cable_player.stop()
            return
        if self._cable_player is None:
            self._cable_output = QAudioOutput(self)
            self._cable_player = QMediaPlayer(self)
            self._cable_player.setAudioOutput(self._cable_output)
        self._cable_output.setDevice(device)

    def set_master_volume(self, volume: float) -> None:
        """Aktualisiert die globale Master-Lautstärke (0–1)."""
        self._master_volume = max(0.0, min(1.0, volume))
        if self._fade_anim is None:
            self._apply_volume(self._target_volume)

    def set_channel_volume(self, volume: float) -> None:
        """Setzt die Kanal-Lautstärke live (0–1)."""
        self._target_volume = max(0.0, min(1.0, volume))
        if self._fade_anim is None:
            self._apply_volume(self._target_volume)

    def _apply_volume(self, channel_volume: float) -> None:
        """Kombiniert Kanal- und Master-Lautstärke und wendet sie an."""
        value = channel_volume * self._master_volume
        self._output.setVolume(value)
        if self._cable_output is not None:
            self._cable_output.setVolume(value)

    # ------------------------------------------------------------------ #
    # Wiedergabesteuerung
    # ------------------------------------------------------------------ #
    def play(self, cfg: SoundButtonConfig) -> bool:
        """
        Startet die Wiedergabe gemäß Buttonkonfiguration.

        :return: ``False``, wenn die Datei fehlt oder ungültig ist.
        """
        path = Path(cfg.sound_path)
        if not cfg.sound_path or not path.exists():
            log.warning("Kanal %d: Datei fehlt: %s", self.index, cfg.sound_path)
            self._set_state(PlaybackState.ERROR)
            return False
        if path.suffix.lower() not in SUPPORTED_AUDIO_FORMATS:
            log.warning("Kanal %d: Format nicht unterstützt: %s", self.index, path.suffix)
            self._set_state(PlaybackState.ERROR)
            return False

        self.stop(fade_ms=0)
        self._set_state(PlaybackState.LOADING)

        self._target_volume = cfg.volume
        self._fade_out_ms = cfg.fade_out_ms
        self._loops_remaining = (
            (-1 if cfg.loop_count == 0 else cfg.loop_count - 1) if cfg.loop else 0
        )

        self._player.setSource(QUrl.fromLocalFile(str(path)))
        self._player.setPlaybackRate(max(0.25, min(3.0, cfg.speed)))

        if cfg.fade_in_ms > 0:
            self._start_fade(0.0, self._target_volume, cfg.fade_in_ms)
        else:
            self._apply_volume(self._target_volume)

        self._player.play()
        # Zweitausgabe (virtuelles Kabel) synchron starten.
        if self._cable_player is not None and self._cable_device is not None:
            self._cable_player.setSource(QUrl.fromLocalFile(str(path)))
            self._cable_player.setPlaybackRate(max(0.25, min(3.0, cfg.speed)))
            self._cable_player.play()
        self._play_started = time.monotonic()
        self._set_state(PlaybackState.PLAYING)
        return True

    def pause(self) -> None:
        """Pausiert die Wiedergabe."""
        if self.is_playing:
            self._player.pause()
            if self._cable_player is not None:
                self._cable_player.pause()
            self._set_state(PlaybackState.PAUSED)

    def resume(self) -> None:
        """Setzt eine pausierte Wiedergabe fort."""
        if self.is_paused:
            self._player.play()
            if self._cable_player is not None and self._cable_device is not None:
                self._cable_player.play()
            self._set_state(PlaybackState.PLAYING)

    def stop(self, fade_ms: int | None = None) -> None:
        """
        Stoppt die Wiedergabe – optional mit Fade-Out.

        :param fade_ms: ``None`` = konfigurierter Fade-Out des Sounds.
        """
        if self.state not in (PlaybackState.PLAYING, PlaybackState.PAUSED):
            return
        fade = self._fade_out_ms if fade_ms is None else fade_ms
        if fade > 0 and self.is_playing:
            self._start_fade(
                self._output.volume() / max(self._master_volume, 0.001),
                0.0,
                fade,
                on_done=self._finalize_stop,
            )
        else:
            self._finalize_stop()

    def _finalize_stop(self) -> None:
        """Beendet die Wiedergabe endgültig und meldet die Statistik."""
        elapsed = 0.0
        if self._play_started > 0:
            elapsed = time.monotonic() - self._play_started
            self._play_started = 0.0
        self._player.stop()
        if self._cable_player is not None:
            self._cable_player.stop()
        self._cancel_fade()
        self._set_state(PlaybackState.IDLE)
        self.progressChanged.emit(self.index, 0.0)
        self.playbackFinished.emit(self.index, elapsed)

    # ------------------------------------------------------------------ #
    # Fades
    # ------------------------------------------------------------------ #
    def _start_fade(
        self, start: float, end: float, duration_ms: int, on_done=None
    ) -> None:
        """Animiert die Kanal-Lautstärke weich von ``start`` nach ``end``."""
        self._cancel_fade()
        anim = QVariantAnimation(self)
        anim.setStartValue(float(start))
        anim.setEndValue(float(end))
        anim.setDuration(max(1, duration_ms))
        anim.valueChanged.connect(lambda v: self._apply_volume(float(v)))

        def _finished() -> None:
            self._fade_anim = None
            if on_done is not None:
                on_done()

        anim.finished.connect(_finished)
        self._fade_anim = anim
        anim.start()

    def _cancel_fade(self) -> None:
        """Bricht eine laufende Fade-Animation ab."""
        if self._fade_anim is not None:
            self._fade_anim.stop()
            self._fade_anim = None

    # ------------------------------------------------------------------ #
    # Interne Slots
    # ------------------------------------------------------------------ #
    def _set_state(self, state: PlaybackState) -> None:
        if state != self.state:
            self.state = state
            self.stateChanged.emit(self.index, state)

    def _on_media_status(self, status: QMediaPlayer.MediaStatus) -> None:
        """Behandelt Medienstatus – insbesondere Loops am Track-Ende."""
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            if self._loops_remaining != 0 and self.state == PlaybackState.PLAYING:
                if self._loops_remaining > 0:
                    self._loops_remaining -= 1
                self._player.setPosition(0)
                self._player.play()
                if self._cable_player is not None and self._cable_device is not None:
                    self._cable_player.setPosition(0)
                    self._cable_player.play()
            else:
                self._finalize_stop()
        elif status == QMediaPlayer.MediaStatus.InvalidMedia:
            log.error("Kanal %d: Ungültige Mediendatei.", self.index)
            self._set_state(PlaybackState.ERROR)

    def _on_error(self, error: QMediaPlayer.Error, message: str) -> None:
        """Fängt Player-Fehler ab, ohne die Anwendung zu gefährden."""
        if error != QMediaPlayer.Error.NoError:
            log.error("Kanal %d Audiofehler: %s", self.index, message)
            self._set_state(PlaybackState.ERROR)

    def _on_position(self, pos: int) -> None:
        """Meldet den Wiedergabefortschritt (0–1) an die UI."""
        duration = self._player.duration()
        if duration > 0:
            self.progressChanged.emit(self.index, pos / duration)


class AudioManager(QObject):
    """
    Verwaltet alle 10 Sound-Kanäle sowie globale Audioeinstellungen.

    Signals
    -------
    channelStateChanged(int, object)
        Weitergereichte Kanal-Statusänderungen.
    channelProgress(int, float)
        Weitergereichter Wiedergabefortschritt.
    soundFinished(int, float)
        ``(index, sekunden)`` – für Statistikzwecke.
    """

    channelStateChanged = Signal(int, object)
    channelProgress = Signal(int, float)
    soundFinished = Signal(int, float)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._master_volume = 0.9
        self._crossfade_ms = 0
        self._cable_name = ""
        self._output_name = ""
        self.channels: list[SoundChannel] = []
        self.ensure_channels(DEFAULT_BUTTON_COUNT)
        log.info("AudioManager mit %d Kanälen initialisiert.", len(self.channels))

    # ------------------------------------------------------------------ #
    def _make_channel(self, index: int) -> SoundChannel:
        """Erzeugt einen verdrahteten Kanal und verbindet dessen Signale."""
        ch = SoundChannel(index, self)
        ch.stateChanged.connect(self.channelStateChanged)
        ch.progressChanged.connect(self.channelProgress)
        ch.playbackFinished.connect(self.soundFinished)
        return ch

    def ensure_channels(self, count: int) -> None:
        """
        Passt die Anzahl der Wiedergabekanäle an ``count`` an.

        Wächst oder schrumpft die Kanalliste dynamisch, sodass jederzeit
        genau so viele Kanäle existieren wie Buttons vorhanden sind.
        """
        count = max(MIN_BUTTON_COUNT, min(MAX_BUTTON_COUNT, count))
        while len(self.channels) < count:
            ch = self._make_channel(len(self.channels))
            ch.set_master_volume(self._master_volume)
            self.channels.append(ch)
        while len(self.channels) > count:
            ch = self.channels.pop()
            ch.stop(fade_ms=0)
            ch.deleteLater()
        # Geräte-Zuweisung für (evtl. neue) Kanäle auffrischen.
        if self._output_name or self._cable_name:
            self.set_output_device_by_name(self._output_name)
            self.set_cable_device_by_name(self._cable_name)

    # ------------------------------------------------------------------ #
    # Globale Einstellungen
    # ------------------------------------------------------------------ #
    def set_master_volume(self, volume: float) -> None:
        """Setzt die Master-Lautstärke aller Kanäle (0–1)."""
        self._master_volume = max(0.0, min(1.0, volume))
        for ch in self.channels:
            ch.set_master_volume(self._master_volume)

    def set_crossfade(self, ms: int) -> None:
        """Konfiguriert die Crossfade-Dauer beim Start neuer Sounds."""
        self._crossfade_ms = max(0, ms)

    def set_output_device_by_name(self, name: str) -> bool:
        """
        Wählt das Ausgabegerät anhand seines Anzeigenamens.

        :return: ``True`` bei Erfolg, sonst Systemstandard.
        """
        device = QMediaDevices.defaultAudioOutput()
        if name:
            for dev in QMediaDevices.audioOutputs():
                if dev.description() == name:
                    device = dev
                    break
        self._output_name = name
        for ch in self.channels:
            ch.set_output_device(device)
        log.info("Ausgabegerät: %s", device.description())
        return True

    def set_cable_device_by_name(self, name: str) -> None:
        """
        Aktiviert die Zweitausgabe auf ein virtuelles Audiokabel
        (z. B. \"CABLE Input (VB-Audio Virtual Cable)\") oder
        deaktiviert sie bei leerem Namen.

        Damit sind die Sounds im Sprachchat \"durchs Mikrofon\" hörbar,
        wenn dort das zugehörige Kabel-Ausgangsgerät als Mikrofon
        gewählt ist.
        """
        device = None
        if name:
            for dev in QMediaDevices.audioOutputs():
                if dev.description() == name:
                    device = dev
                    break
            if device is None:
                log.warning("Kabel-Gerät nicht gefunden: %s", name)
        self._cable_name = name
        for ch in self.channels:
            ch.set_cable_device(device)
        if device is not None:
            log.info("Mikrofon-Routing aktiv: %s", device.description())

    @staticmethod
    def output_devices() -> list[str]:
        """Listet die Namen aller verfügbaren Ausgabegeräte."""
        return [d.description() for d in QMediaDevices.audioOutputs()]

    # ------------------------------------------------------------------ #
    # Wiedergabe
    # ------------------------------------------------------------------ #
    def play(self, index: int, cfg: SoundButtonConfig) -> bool:
        """
        Startet Kanal ``index``. Bei aktivem Crossfade werden andere
        laufende Kanäle weich ausgeblendet.
        """
        if not 0 <= index < len(self.channels):
            return False
        if self._crossfade_ms > 0:
            for ch in self.channels:
                if ch.index != index and ch.is_playing:
                    ch.stop(fade_ms=self._crossfade_ms)
        return self.channels[index].play(cfg)

    def toggle(self, index: int, cfg: SoundButtonConfig) -> None:
        """Play → Pause → Resume-Umschaltung für einen Kanal."""
        if not 0 <= index < len(self.channels):
            return
        ch = self.channels[index]
        if ch.is_playing:
            ch.pause()
        elif ch.is_paused:
            ch.resume()
        else:
            self.play(index, cfg)

    def stop(self, index: int, fade_ms: int | None = None) -> None:
        """Stoppt einen einzelnen Kanal."""
        if 0 <= index < len(self.channels):
            self.channels[index].stop(fade_ms)

    def stop_all(self, fade_ms: int = 200) -> None:
        """Stoppt alle Kanäle (weiches Ausblenden)."""
        for ch in self.channels:
            ch.stop(fade_ms=fade_ms)
        log.info("Alle Sounds gestoppt.")

    def pause_all(self) -> None:
        """Pausiert alle laufenden Kanäle."""
        for ch in self.channels:
            ch.pause()

    def resume_all(self) -> None:
        """Setzt alle pausierten Kanäle fort."""
        for ch in self.channels:
            ch.resume()

    def set_channel_volume(self, index: int, volume: float) -> None:
        """Live-Lautstärkeänderung eines Kanals."""
        if 0 <= index < len(self.channels):
            self.channels[index].set_channel_volume(volume)

    def active_count(self) -> int:
        """Anzahl aktuell spielender Kanäle."""
        return sum(1 for ch in self.channels if ch.is_playing)

    def shutdown(self) -> None:
        """Stoppt alle Kanäle beim Beenden der Anwendung."""
        for ch in self.channels:
            ch.stop(fade_ms=0)
