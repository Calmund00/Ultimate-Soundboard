"""Kern-Manager (Audio, Einstellungen, Theme, Animation, Hotkeys)."""
