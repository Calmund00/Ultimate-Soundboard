"""
hotkey_manager.py
=================

Globale (systemweite) Hotkeys für Windows – **ohne C++-Treiber**.

Verwendet einen Low-Level-Keyboard-Hook (``WH_KEYBOARD_LL``) über
:mod:`ctypes`. Im Gegensatz zu ``RegisterHotKey`` werden die Tasten
dabei **nicht verschluckt**: Der Hook hört nur mit und reicht jede
Taste unverändert an das System weiter – Tippen, Spielen und andere
Programme funktionieren normal, während die Hotkeys trotzdem global
ausgelöst werden (auch ohne Fenster-Fokus).
"""
from __future__ import annotations

import ctypes
import sys
import threading
from ctypes import wintypes

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QKeySequence

from logger import get_logger

log = get_logger(__name__)

# Win32-Konstanten für den Keyboard-Hook
WH_KEYBOARD_LL = 13
WH_MOUSE_LL = 14  # Low-Level Maus-Hook für Seitentasten
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_SYSKEYDOWN = 0x0104
WM_SYSKEYUP = 0x0105
WM_QUIT = 0x0012
# Maus-Events
WM_XBUTTONDOWN = 0x020B
WM_XBUTTONUP = 0x020C

VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12          # Alt
VK_LWIN, VK_RWIN = 0x5B, 0x5C

# Modifier-Flags (Format wie bei RegisterHotKey, für die Sequenz-Analyse)
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008

#: Zuordnung von Qt-Keys zu Windows Virtual-Key-Codes (häufigste Tasten).
_QT_TO_VK: dict[int, int] = {
    **{Qt.Key.Key_0.value + i: 0x30 + i for i in range(10)},          # 0-9
    **{Qt.Key.Key_A.value + i: 0x41 + i for i in range(26)},          # A-Z
    **{Qt.Key.Key_F1.value + i: 0x70 + i for i in range(24)},         # F1-F24
    Qt.Key.Key_Space.value: 0x20,
    Qt.Key.Key_Tab.value: 0x09,
    Qt.Key.Key_Return.value: 0x0D,
    Qt.Key.Key_Enter.value: 0x0D,
    Qt.Key.Key_Escape.value: 0x1B,
    Qt.Key.Key_Backspace.value: 0x08,
    Qt.Key.Key_Insert.value: 0x2D,
    Qt.Key.Key_Delete.value: 0x2E,
    Qt.Key.Key_Home.value: 0x24,
    Qt.Key.Key_End.value: 0x23,
    Qt.Key.Key_PageUp.value: 0x21,
    Qt.Key.Key_PageDown.value: 0x22,
    Qt.Key.Key_Left.value: 0x25,
    Qt.Key.Key_Up.value: 0x26,
    Qt.Key.Key_Right.value: 0x27,
    Qt.Key.Key_Down.value: 0x28,
    Qt.Key.Key_Plus.value: 0xBB,
    Qt.Key.Key_Minus.value: 0xBD,
    Qt.Key.Key_Comma.value: 0xBC,
    Qt.Key.Key_Period.value: 0xBE,
}

#: Maus-Seitentasten (XButton1/XButton2) - werden als VK-Codes erkannt
# Diese können im Hotkey-Dialog direkt eingegeben werden (z.B. "XButton1")
_MOUSE_BUTTON_VK: dict[str, int] = {
    "XButton1": 0x05,  # Maus-Seitentaste 1 (zurück)
    "XButton2": 0x06,  # Maus-Seitentaste 2 (vorwärts)
}


def _parse_sequence(sequence: str) -> tuple[int, int] | None:
    """
    Übersetzt eine Qt-Tastenkombination (z. B. ``"Ctrl+Alt+1"``) in
    Win32-Modifier-Flags und einen Virtual-Key-Code.
    
    Unterstützt auch Maus-Seitentasten: "XButton1" oder "XButton2"
    können direkt als Sequenz angegeben werden (mit/ohne Modifier).

    :return: ``(modifiers, vk)`` oder ``None`` bei ungültiger Sequenz.
    """
    # Prüfe ob es eine Maus-Taste ist (XButton1/XButton2)
    parts = sequence.split('+')
    mouse_btn = parts[-1].strip()
    if mouse_btn in _MOUSE_BUTTON_VK:
        vk = _MOUSE_BUTTON_VK[mouse_btn]
        # Parse Modifier falls vorhanden (z.B. "Ctrl+XButton1")
        mods = 0
        for part in parts[:-1]:
            part = part.strip().lower()
            if part in ("ctrl", "control"):
                mods |= MOD_CONTROL
            elif part == "alt":
                mods |= MOD_ALT
            elif part == "shift":
                mods |= MOD_SHIFT
            elif part in ("win", "meta"):
                mods |= MOD_WIN
        return mods, vk
    
    # Standard Qt-Tastenkombination
    seq = QKeySequence(sequence)
    if seq.isEmpty():
        return None
    combo = seq[0]
    qt_mods = combo.keyboardModifiers()
    qt_key = combo.key()

    mods = 0
    if qt_mods & Qt.KeyboardModifier.ControlModifier:
        mods |= MOD_CONTROL
    if qt_mods & Qt.KeyboardModifier.AltModifier:
        mods |= MOD_ALT
    if qt_mods & Qt.KeyboardModifier.ShiftModifier:
        mods |= MOD_SHIFT
    if qt_mods & Qt.KeyboardModifier.MetaModifier:
        mods |= MOD_WIN

    vk = _QT_TO_VK.get(qt_key.value)
    if vk is None:
        return None
    return mods, vk


class _KBDLLHOOKSTRUCT(ctypes.Structure):
    """Win32-Struktur der Low-Level-Keyboard-Events."""

    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


class _MSLLHOOKSTRUCT(ctypes.Structure):
    """Win32-Struktur der Low-Level-Maus-Events."""

    _fields_ = [
        ("pt", wintypes.POINT),
        ("mouseData", wintypes.DWORD),   # High-Word: XBUTTON1=1 / XBUTTON2=2
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
    ]


#: Signatur der Hook-Callback-Funktion (LRESULT, int, WPARAM, LPARAM).
_HOOKPROC = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM
)


class HotkeyManager(QObject):
    """
    Registriert globale Hotkeys über einen passiven Keyboard-Hook.

    Der Hook läuft in einem eigenen Daemon-Thread mit Message-Loop und
    blockiert keine Tasten – er meldet Treffer lediglich per Signal an
    den GUI-Thread (Qt stellt die Zustellung threadsicher per Queued
    Connection sicher).

    Signals
    -------
    hotkeyPressed(int)
        Die ID des ausgelösten Hotkeys (entspricht dem Button-Index).
    """

    hotkeyPressed = Signal(int)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        #: hotkey_id -> (modifiers, vk, sequenz)
        self._registered: dict[int, tuple[int, int, str]] = {}
        self._lock = threading.Lock()
        self._down: set[int] = set()          # gedrückte Tasten (Repeat-Filter)
        self._thread: threading.Thread | None = None
        self._thread_id: int = 0
        self._hook_handle: int | None = None
        self._mouse_hook_handle: int | None = None
        self._proc = None                      # C-Callback am Leben halten!
        self._mouse_proc = None                # Maus-Callback am Leben halten!

        self._available = sys.platform == "win32"
        if self._available:
            self._user32 = ctypes.windll.user32
            self._kernel32 = ctypes.windll.kernel32
            # 64-Bit-sichere Signaturen: ohne korrekte restypes/argtypes
            # werden Handles auf 32 Bit abgeschnitten und der Hook
            # schlägt fehl.
            self._kernel32.GetModuleHandleW.restype = ctypes.c_void_p
            self._kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
            self._user32.SetWindowsHookExW.restype = ctypes.c_void_p
            self._user32.SetWindowsHookExW.argtypes = [
                ctypes.c_int, _HOOKPROC, ctypes.c_void_p, wintypes.DWORD,
            ]
            self._user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
            self._user32.CallNextHookEx.restype = ctypes.c_ssize_t
            self._user32.CallNextHookEx.argtypes = [
                ctypes.c_void_p, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM,
            ]
        else:
            log.warning("Globale Hotkeys sind nur unter Windows verfügbar.")

    # ------------------------------------------------------------------ #
    # Öffentliche API
    # ------------------------------------------------------------------ #
    def register(self, hotkey_id: int, sequence: str) -> bool:
        """
        Registriert einen systemweiten Hotkey (nicht-blockierend).

        :param hotkey_id: Eindeutige ID (Button-Index).
        :param sequence: Tastenkombination im Qt-Format, z. B. ``"Ctrl+Alt+1"``.
        :return: ``True`` bei Erfolg.
        """
        if not self._available or not sequence:
            return False

        parsed = _parse_sequence(sequence)
        if parsed is None:
            log.warning("Ungültige Hotkey-Sequenz: %s", sequence)
            return False

        mods, vk = parsed
        with self._lock:
            self._registered[hotkey_id] = (mods, vk, sequence)
        self._ensure_hook_thread()
        log.info("Globaler Hotkey aktiv (Pass-Through): %s (ID %d)", sequence, hotkey_id)
        return True

    def unregister(self, hotkey_id: int) -> None:
        """Entfernt einen registrierten Hotkey."""
        with self._lock:
            self._registered.pop(hotkey_id, None)

    def unregister_all(self) -> None:
        """Entfernt alle registrierten Hotkeys."""
        with self._lock:
            self._registered.clear()

    def registered_sequence(self, hotkey_id: int) -> str:
        """Liefert die aktuell registrierte Sequenz einer ID (oder ``""``)."""
        with self._lock:
            entry = self._registered.get(hotkey_id)
        return entry[2] if entry else ""

    def shutdown(self) -> None:
        """Beendet den Hook-Thread sauber (beim Programmende)."""
        self.unregister_all()
        if self._available and self._thread_id:
            self._user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)

    # ------------------------------------------------------------------ #
    # Hook-Thread
    # ------------------------------------------------------------------ #
    def _ensure_hook_thread(self) -> None:
        """Startet den Hook-Thread genau einmal (lazy)."""
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._hook_loop, name="HotkeyHook", daemon=True
        )
        self._thread.start()

    def _hook_loop(self) -> None:
        """Installiert den Hook und pumpt die Windows-Message-Loop."""
        try:
            self._thread_id = self._kernel32.GetCurrentThreadId()
            module = self._kernel32.GetModuleHandleW(None)

            self._proc = _HOOKPROC(self._hook_callback)
            self._hook_handle = self._user32.SetWindowsHookExW(
                WH_KEYBOARD_LL,
                self._proc,
                module,
                0,
            )
            if not self._hook_handle:
                log.error("Keyboard-Hook konnte nicht installiert werden.")
                return

            # Zweiter Hook für Maus-Seitentasten (XButton1/XButton2).
            self._mouse_proc = _HOOKPROC(self._mouse_callback)
            self._mouse_hook_handle = self._user32.SetWindowsHookExW(
                WH_MOUSE_LL,
                self._mouse_proc,
                module,
                0,
            )
            if not self._mouse_hook_handle:
                log.warning("Maus-Hook konnte nicht installiert werden "
                            "(Seitentasten sind nicht verfügbar).")

            msg = wintypes.MSG()
            while self._user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                self._user32.TranslateMessage(ctypes.byref(msg))
                self._user32.DispatchMessageW(ctypes.byref(msg))
        except Exception:  # noqa: BLE001 - Hook-Thread darf nie crashen
            log.exception("Fehler im Hotkey-Hook-Thread.")
        finally:
            if self._hook_handle:
                self._user32.UnhookWindowsHookEx(ctypes.c_void_p(self._hook_handle))
                self._hook_handle = None
            if self._mouse_hook_handle:
                self._user32.UnhookWindowsHookEx(
                    ctypes.c_void_p(self._mouse_hook_handle)
                )
                self._mouse_hook_handle = None

    def _hook_callback(self, n_code: int, w_param: int, l_param: int) -> int:
        """
        Callback des Low-Level-Hooks.

        Prüft bei jedem Tastendruck, ob eine registrierte Kombination
        getroffen wurde, und reicht die Taste IMMER unverändert weiter
        (``CallNextHookEx``) – dadurch bleibt sie überall benutzbar.
        """
        try:
            if n_code == 0:  # HC_ACTION
                kb = ctypes.cast(l_param, ctypes.POINTER(_KBDLLHOOKSTRUCT)).contents
                vk = int(kb.vkCode)
                if w_param in (WM_KEYDOWN, WM_SYSKEYDOWN):
                    if vk not in self._down:      # Auto-Repeat unterdrücken
                        self._down.add(vk)
                        mods = self._current_mods()
                        with self._lock:
                            hits = [
                                hid
                                for hid, (m, k, _) in self._registered.items()
                                if k == vk and m == mods
                            ]
                        for hid in hits:
                            self.hotkeyPressed.emit(hid)
                elif w_param in (WM_KEYUP, WM_SYSKEYUP):
                    self._down.discard(vk)
        except Exception:  # noqa: BLE001 - Callback muss immer zurückkehren
            log.exception("Fehler im Hook-Callback.")
        return self._user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _mouse_callback(self, n_code: int, w_param: int, l_param: int) -> int:
        """
        Callback des Low-Level-Maus-Hooks.

        Erkennt die Maus-Seitentasten (XButton1/XButton2) und meldet
        registrierte Treffer per Signal – die Tasten werden dabei
        unverändert weitergereicht (Pass-Through).
        """
        try:
            if n_code == 0:  # HC_ACTION
                if w_param == WM_XBUTTONDOWN:
                    ms = ctypes.cast(
                        l_param, ctypes.POINTER(_MSLLHOOKSTRUCT)
                    ).contents
                    # High-Word von mouseData: 1 = XBUTTON1, 2 = XBUTTON2
                    xbutton = (ms.mouseData >> 16) & 0xFFFF
                    vk = 0x05 if xbutton == 1 else 0x06 if xbutton == 2 else 0
                    if vk and vk not in self._down:
                        self._down.add(vk)
                        mods = self._current_mods()
                        with self._lock:
                            hits = [
                                hid
                                for hid, (m, k, _) in self._registered.items()
                                if k == vk and m == mods
                            ]
                        for hid in hits:
                            self.hotkeyPressed.emit(hid)
                elif w_param == WM_XBUTTONUP:
                    ms = ctypes.cast(
                        l_param, ctypes.POINTER(_MSLLHOOKSTRUCT)
                    ).contents
                    xbutton = (ms.mouseData >> 16) & 0xFFFF
                    vk = 0x05 if xbutton == 1 else 0x06 if xbutton == 2 else 0
                    if vk:
                        self._down.discard(vk)
        except Exception:  # noqa: BLE001 - Callback muss immer zurückkehren
            log.exception("Fehler im Maus-Hook-Callback.")
        return self._user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _current_mods(self) -> int:
        """Ermittelt die aktuell gedrückten Modifier als Flag-Maske."""
        get = self._user32.GetAsyncKeyState
        mods = 0
        if get(VK_CONTROL) & 0x8000:
            mods |= MOD_CONTROL
        if get(VK_MENU) & 0x8000:
            mods |= MOD_ALT
        if get(VK_SHIFT) & 0x8000:
            mods |= MOD_SHIFT
        if (get(VK_LWIN) & 0x8000) or (get(VK_RWIN) & 0x8000):
            mods |= MOD_WIN
        return mods
