"""
settings_manager.py
===================

Verwaltet Laden, Speichern, Import/Export, Backups sowie Undo/Redo
der kompletten Anwendungskonfiguration (JSON-basiert).

Der Manager arbeitet mit einem Debounce-Timer, damit häufige Änderungen
(z. B. Slider-Bewegungen) den Datenträger nicht unnötig belasten.
"""
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal

from config import APP_NAME, BACKUP_DIR, CONFIG_DIR, CONFIG_FILE, AppConfig
from logger import get_logger

log = get_logger(__name__)

#: Maximale Anzahl an Undo-Schritten.
MAX_HISTORY = 50


class _SaveRunnable(QRunnable):
    """Schreibt die Konfiguration asynchron auf den Datenträger."""

    def __init__(self, config_dict: dict) -> None:
        super().__init__()
        self._data = config_dict
        self.setAutoDelete(True)

    def run(self) -> None:  # noqa: D102
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(self._data, indent=2, ensure_ascii=False)
            tmp = CONFIG_FILE.with_suffix(".tmp")
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(CONFIG_FILE)
        except OSError as exc:  # noqa: BLE001
            # Fehler im Hintergrund-Thread – nur loggen, nie crashen.
            log.error("Async-Speichern fehlgeschlagen: %s", exc)


class SettingsManager(QObject):
    """
    Zentraler Konfigurations-Manager.

    Signals
    -------
    configChanged
        Wird nach jeder Änderung (auch Undo/Redo/Import) ausgelöst.
        Die UI aktualisiert sich daraufhin vollständig.
    """

    configChanged = Signal()

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.config: AppConfig = self._load()

        self._undo_stack: list[dict] = []
        self._redo_stack: list[dict] = []

        # Debounce-Timer: bündelt schnelle Änderungen zu einem Schreibvorgang.
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(600)
        self._save_timer.timeout.connect(self._write_to_disk)

    # ------------------------------------------------------------------ #
    # Laden / Speichern
    # ------------------------------------------------------------------ #
    def _load(self) -> AppConfig:
        """Lädt die Konfiguration; bei Fehlern werden Defaults verwendet."""
        try:
            if CONFIG_FILE.exists():
                data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
                log.info("Konfiguration geladen: %s", CONFIG_FILE)
                return AppConfig.from_dict(data)
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            log.error("Konfiguration konnte nicht geladen werden: %s", exc)
        log.info("Standardkonfiguration wird verwendet.")
        return AppConfig()

    def save(self, immediate: bool = False) -> None:
        """
        Plant das Speichern der Konfiguration (debounced).

        :param immediate: ``True`` erzwingt sofortiges Schreiben.
        """
        if immediate:
            self._save_timer.stop()
            self._write_to_disk()
        else:
            self._save_timer.start()

    def _write_to_disk(self) -> None:
        """Serialisiert die Konfiguration und speichert sie im Hintergrund."""
        try:
            runnable = _SaveRunnable(self.config.to_dict())
            QThreadPool.globalInstance().start(runnable)
            log.debug("Konfiguration wird asynchron gespeichert.")
        except Exception as exc:  # noqa: BLE001
            log.error("Speichern konnte nicht gestartet werden: %s", exc)

    # ------------------------------------------------------------------ #
    # Undo / Redo
    # ------------------------------------------------------------------ #
    def push_undo_snapshot(self) -> None:
        """Legt den aktuellen Zustand auf den Undo-Stack (vor einer Änderung)."""
        self._undo_stack.append(self.config.to_dict())
        if len(self._undo_stack) > MAX_HISTORY:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def undo(self) -> bool:
        """Macht die letzte Änderung rückgängig. :return: Erfolg."""
        if not self._undo_stack:
            return False
        self._redo_stack.append(self.config.to_dict())
        self.config = AppConfig.from_dict(self._undo_stack.pop())
        self.save()
        self.configChanged.emit()
        log.info("Undo ausgeführt.")
        return True

    def redo(self) -> bool:
        """Stellt eine rückgängig gemachte Änderung wieder her. :return: Erfolg."""
        if not self._redo_stack:
            return False
        self._undo_stack.append(self.config.to_dict())
        self.config = AppConfig.from_dict(self._redo_stack.pop())
        self.save()
        self.configChanged.emit()
        log.info("Redo ausgeführt.")
        return True

    # ------------------------------------------------------------------ #
    # Import / Export / Backup
    # ------------------------------------------------------------------ #
    def export_config(self, target: Path) -> bool:
        """Exportiert die Konfiguration als JSON-Datei."""
        try:
            target.write_text(
                json.dumps(self.config.to_dict(), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            log.info("Konfiguration exportiert nach %s", target)
            return True
        except OSError as exc:
            log.error("Export fehlgeschlagen: %s", exc)
            return False

    def import_config(self, source: Path) -> bool:
        """Importiert eine Konfiguration aus einer JSON-Datei."""
        try:
            data = json.loads(source.read_text(encoding="utf-8"))
            self.push_undo_snapshot()
            self.config = AppConfig.from_dict(data)
            self.save(immediate=True)
            self.configChanged.emit()
            log.info("Konfiguration importiert von %s", source)
            return True
        except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
            log.error("Import fehlgeschlagen: %s", exc)
            return False

    def create_backup(self) -> Path | None:
        """Erstellt ein Zeitstempel-Backup im Backup-Verzeichnis."""
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            target = BACKUP_DIR / f"backup_{stamp}.json"
            self.save(immediate=True)
            shutil.copyfile(CONFIG_FILE, target)
            log.info("Backup erstellt: %s", target)
            return target
        except OSError as exc:
            log.error("Backup fehlgeschlagen: %s", exc)
            return None

    def restore_backup(self, source: Path) -> bool:
        """Stellt ein Backup wieder her (identisch zum Import)."""
        return self.import_config(source)

    def reset_config(self) -> None:
        """Setzt die komplette Konfiguration auf Werkseinstellungen zurück."""
        self.push_undo_snapshot()
        self.config = AppConfig()
        self.save(immediate=True)
        self.configChanged.emit()
        log.info("Konfiguration zurückgesetzt.")

    # ------------------------------------------------------------------ #
    # Autostart (Windows-Registry)
    # ------------------------------------------------------------------ #
    def set_autostart(self, enabled: bool) -> bool:
        """
        Aktiviert/deaktiviert den Autostart über den Windows-Registry-Key
        ``HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run``.
        """
        if sys.platform != "win32":
            return False
        try:
            import winreg

            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0,
                winreg.KEY_SET_VALUE,
            )
            if enabled:
                cmd = f'"{sys.executable}" "{Path(__file__).parent / "main.py"}"'
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, cmd)
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass
            winreg.CloseKey(key)
            self.config.autostart = enabled
            self.save()
            log.info("Autostart %s.", "aktiviert" if enabled else "deaktiviert")
            return True
        except OSError as exc:
            log.error("Autostart-Änderung fehlgeschlagen: %s", exc)
            return False

    # ------------------------------------------------------------------ #
    # Komfortfunktionen
    # ------------------------------------------------------------------ #
    def add_recent_sound(self, path: str) -> None:
        """Fügt einen Sound zur Liste der zuletzt verwendeten hinzu."""
        recents = self.config.recent_sounds
        if path in recents:
            recents.remove(path)
        recents.insert(0, path)
        del recents[10:]
        self.save()

    def notify_changed(self) -> None:
        """Speichert und benachrichtigt die UI über Änderungen."""
        self.save()
        self.configChanged.emit()
