"""
animation_manager.py
====================

Zentrale Animations-Hilfen auf Basis von :class:`QPropertyAnimation`.

Alle Animationen respektieren die globalen UI-Einstellungen
(Animationen an/aus, Geschwindigkeitsmultiplikator) und verwenden
hochwertige Easing-Kurven für ein flüssiges Erscheinungsbild.
"""
from __future__ import annotations

from typing import Callable

from PySide6.QtCore import (
    QAbstractAnimation,
    QEasingCurve,
    QObject,
    QPoint,
    QPropertyAnimation,
    QRect,
)
from PySide6.QtWidgets import QGraphicsOpacityEffect, QWidget

from config import UIConfig
from logger import get_logger

log = get_logger(__name__)


class AnimationManager(QObject):
    """
    Fabrik für konfigurierte Animationen.

    Der Manager hält eine Referenz auf die UI-Konfiguration und skaliert
    Animationsdauern anhand des benutzerdefinierten Geschwindigkeitsfaktors.
    """

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._ui = UIConfig()

    def update_config(self, ui: UIConfig) -> None:
        """Übernimmt die aktuelle UI-Konfiguration."""
        self._ui = ui

    # ------------------------------------------------------------------ #
    def duration(self, base_ms: int) -> int:
        """Skaliert eine Basisdauer mit dem globalen Geschwindigkeitsfaktor."""
        if not self._ui.animations_enabled:
            return 1  # quasi sofort, aber Animation-API bleibt nutzbar
        speed = max(0.25, self._ui.animation_speed)
        return max(1, int(base_ms / speed))

    @property
    def enabled(self) -> bool:
        """``True``, wenn Animationen global aktiviert sind."""
        return self._ui.animations_enabled

    # ------------------------------------------------------------------ #
    def animate(
        self,
        target: QObject,
        prop: bytes,
        start,
        end,
        base_ms: int = 250,
        easing: QEasingCurve.Type = QEasingCurve.Type.OutCubic,
        on_finished: Callable[[], None] | None = None,
    ) -> QPropertyAnimation:
        """
        Erstellt und startet eine generische Property-Animation.

        :param target: Zielobjekt (Widget oder Effekt).
        :param prop: Property-Name als Bytes, z. B. ``b"geometry"``.
        :param start: Startwert.
        :param end: Endwert.
        :param base_ms: Basisdauer in Millisekunden.
        :param easing: Easing-Kurve.
        :param on_finished: Optionaler Abschluss-Callback.
        """
        anim = QPropertyAnimation(target, prop, self)
        anim.setDuration(self.duration(base_ms))
        anim.setStartValue(start)
        anim.setEndValue(end)
        anim.setEasingCurve(easing)
        if on_finished is not None:
            anim.finished.connect(on_finished)
        anim.start(QAbstractAnimation.DeletionPolicy.DeleteWhenStopped)
        return anim

    # ------------------------------------------------------------------ #
    def fade(
        self,
        widget: QWidget,
        start: float,
        end: float,
        base_ms: int = 300,
        on_finished: Callable[[], None] | None = None,
    ) -> QPropertyAnimation:
        """Blendet ein Widget weich ein oder aus (Opacity-Animation)."""
        effect = widget.graphicsEffect()
        if not isinstance(effect, QGraphicsOpacityEffect):
            effect = QGraphicsOpacityEffect(widget)
            widget.setGraphicsEffect(effect)
        effect.setOpacity(start)
        return self.animate(
            effect, b"opacity", start, end, base_ms,
            QEasingCurve.Type.InOutQuad, on_finished,
        )

    def slide(
        self,
        widget: QWidget,
        offset: QPoint,
        base_ms: int = 350,
        easing: QEasingCurve.Type = QEasingCurve.Type.OutBack,
    ) -> QPropertyAnimation:
        """Schiebt ein Widget von ``pos + offset`` an seine aktuelle Position."""
        end = widget.pos()
        start = end + offset
        widget.move(start)
        return self.animate(widget, b"pos", start, end, base_ms, easing)

    def bounce_geometry(
        self, widget: QWidget, target_rect: QRect, base_ms: int = 450
    ) -> QPropertyAnimation:
        """Animiert die Geometrie mit elastischem 'Bounce'-Effekt."""
        return self.animate(
            widget, b"geometry", widget.geometry(), target_rect,
            base_ms, QEasingCurve.Type.OutElastic,
        )
