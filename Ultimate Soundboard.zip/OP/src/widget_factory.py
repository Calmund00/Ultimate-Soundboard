"""
widget_factory.py
=================

Fabrikfunktionen für wiederkehrende, gestylte Widgets sowie
SVG-Icon-Utilities (Laden + farbliches Einfärben von SVG-Icons).
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from PySide6.QtCore import QByteArray, QRectF, QSize, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from config import ICONS_DIR
from logger import get_logger

log = get_logger(__name__)


# --------------------------------------------------------------------------- #
# SVG-Icon-Utilities
# --------------------------------------------------------------------------- #
@lru_cache(maxsize=256)
def _load_svg_data(name: str) -> str:
    """Lädt den SVG-Quelltext eines Icons (gecacht)."""
    path = ICONS_DIR / f"{name}.svg"
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        log.warning("SVG-Icon nicht gefunden: %s", path)
        return (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">'
            '<circle cx="12" cy="12" r="9" fill="currentColor"/></svg>'
        )


@lru_cache(maxsize=512)
def render_svg_pixmap(name: str, color: str, size: int) -> QPixmap:
    """
    Rendert ein SVG-Icon in der gewünschten Farbe als Pixmap.

    Alle Icons verwenden ``currentColor``, das hier ersetzt wird –
    dadurch lassen sich Icons beliebig einfärben (Fluent-Stil).

    Das Ergebnis wird gecacht (LRU): Buttons zeichnen ihre Icons bei
    jeder Animation neu – ohne Cache würde das SVG bei jedem Frame
    erneut geparst und gerastert (massiver FPS-Verlust).
    """
    svg = _load_svg_data(name).replace("currentColor", color)
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    renderer.render(painter, QRectF(0, 0, size, size))
    painter.end()
    return pixmap


def svg_icon(name: str, color: str = "#FFFFFF", size: int = 24) -> QIcon:
    """Erzeugt ein eingefärbtes :class:`QIcon` aus einem SVG-Asset."""
    return QIcon(render_svg_pixmap(name, color, size))


# Deutsche Anzeigenamen für SVG-Icons (Dateiname → Anzeigename).
# Nicht vorhandene Namen werden unverändert angezeigt.
ICON_NAMES_DE: dict[str, str] = {
    "alien":       "Alien",
    "bell":        "Glocke",
    "bolt":        "Blitz",
    "bomb":        "Wasser-Tropfen",
    "calendar":    "Kalender",
    "car":         "Auto",
    "cat":         "Tier",
    "check":       "Häkchen",
    "clock":       "Uhr",
    "close":       "Schließen",
    "cloud":       "Wolke",
    "crown":       "Krone",
    "diamond":     "Diamant",
    "drum":        "Trommel",
    "fire":        "Feuer",
    "folder":      "Ordner",
    "game":        "Spiel",
    "ghost":       "Geist",
    "guitar":      "Kegel",
    "headphones":  "Kopfhörer",
    "heart":       "Herz",
    "horn":        "Lautsprecher",
    "info":        "Info",
    "laugh":       "Sprechblase",
    "logo":        "Logo",
    "maximize":    "Maximieren",
    "mic":         "Mikrofon",
    "minimize":    "Minimieren",
    "money":       "Geld",
    "music":       "Musik",
    "palette":     "Palette",
    "pause":       "Pause",
    "phone":       "Telefon",
    "piano":       "Klavier",
    "pin":         "Stecknadel",
    "play":        "Abspielen",
    "restore":     "Wiederherstellen",
    "robot":       "Roboter",
    "rocket":      "Pin",
    "search":      "Suche",
    "settings":    "Einstellungen",
    "shield":      "Schild",
    "siren":       "Sirene",
    "skull":       "Totenkopf",
    "sparkle":     "Medaille",
    "star":        "Stern",
    "stop":        "Stopp",
    "sun":         "Sonne",
    "sword":       "Kreide",
    "theme":       "Mond",
    "trophy":      "Trophäe",
    "volume":      "Lautstärke",
    "warning":     "Warnung",
    "wave":        "Welle",
}

# Icons, die nicht im Sound-Button-Auswahl-Dialog erscheinen sollen
# (reine UI-Icons ohne sinnvollen Sound-Bezug).
_UI_ONLY_ICONS = {"close", "maximize", "minimize", "restore", "search", "logo"}


def available_icons() -> list[str]:
    """Listet alle verfügbaren SVG-Icon-Namen im Assets-Ordner auf."""
    if not ICONS_DIR.exists():
        return []
    return sorted(p.stem for p in ICONS_DIR.glob("*.svg"))


def available_sound_icons() -> list[tuple[str, str]]:
    """
    Gibt (Dateiname, Deutscher_Anzeigename)-Paare für den Icon-Auswahl-Combo zurück.

    Sortiert nach deutschem Namen, UI-only-Icons ausgeblendet.
    """
    pairs = [
        (name, ICON_NAMES_DE.get(name, name.capitalize()))
        for name in available_icons()
        if name not in _UI_ONLY_ICONS
    ]
    return sorted(pairs, key=lambda p: p[1].lower())


# --------------------------------------------------------------------------- #
# Widget-Fabriken
# --------------------------------------------------------------------------- #
def make_icon_button(
    icon_name: str,
    tooltip: str = "",
    color: str = "#EAECF5",
    icon_size: int = 18,
    flat: bool = True,
) -> QPushButton:
    """Erzeugt einen kompakten Icon-Button für Werkzeugleisten."""
    btn = QPushButton()
    btn.setIcon(svg_icon(icon_name, color, icon_size * 2))
    btn.setIconSize(QSize(icon_size, icon_size))
    btn.setToolTip(tooltip)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    btn.setFixedSize(34, 34)
    if flat:
        btn.setStyleSheet(
            "QPushButton{border:none;border-radius:10px;background:transparent;}"
            "QPushButton:hover{background:rgba(255,255,255,0.10);}"
            "QPushButton:pressed{background:rgba(255,255,255,0.18);}"
        )
    return btn


def make_slider(
    minimum: int, maximum: int, value: int, tooltip: str = "", width: int = 120
) -> QSlider:
    """Erzeugt einen horizontalen, gestylten Slider."""
    slider = QSlider(Qt.Orientation.Horizontal)
    slider.setRange(minimum, maximum)
    slider.setValue(value)
    slider.setToolTip(tooltip)
    slider.setFixedWidth(width)
    slider.setCursor(Qt.CursorShape.PointingHandCursor)
    return slider


def make_card(parent: QWidget | None = None) -> QFrame:
    """Erzeugt einen abgerundeten 'Glas-Karten'-Container."""
    card = QFrame(parent)
    card.setObjectName("card")
    card.setStyleSheet(
        "QFrame#card{background:rgba(255,255,255,0.045);"
        "border:1px solid rgba(255,255,255,0.08);border-radius:16px;}"
    )
    return card


def make_form_row(label_text: str, widget: QWidget) -> QWidget:
    """Erzeugt eine Beschriftung-links / Widget-rechts-Zeile für Formulare."""
    row = QWidget()
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 0, 0, 0)
    label = QLabel(label_text)
    label.setMinimumWidth(180)
    layout.addWidget(label)
    layout.addWidget(widget, 1)
    return row


def make_section(title: str, *widgets: QWidget) -> QWidget:
    """Erzeugt einen Abschnitt mit Überschrift und untergeordneten Zeilen."""
    section = QWidget()
    layout = QVBoxLayout(section)
    layout.setContentsMargins(0, 0, 0, 12)
    layout.setSpacing(8)
    heading = QLabel(title)
    heading.setObjectName("h2")
    layout.addWidget(heading)
    for w in widgets:
        layout.addWidget(w)
    return section
