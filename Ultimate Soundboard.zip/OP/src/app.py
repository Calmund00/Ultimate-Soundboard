"""
app.py
======

Anwendungsklasse von Ultimate Soundboard .

Erzeugt alle Manager (Settings, Audio, Theme, Animation, Hotkeys),
zeigt den animierten Splash-Screen und startet anschließend das
Hauptfenster mit weichem Übergang.
"""
from __future__ import annotations

import sys

from PySide6.QtCore import QEasingCurve, QPropertyAnimation
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from core.animation_manager import AnimationManager
from core.audio_manager import AudioManager
from config import APP_NAME, APP_VERSION, ASSETS_DIR, ORG_NAME
from core.hotkey_manager import HotkeyManager
from core.settings_manager import SettingsManager
from core.theme_manager import ThemeManager
from ui.main_window import MainWindow
from ui.splash import SplashScreen
from logger import get_logger

log = get_logger(__name__)


class SoundboardApp(QApplication):
    """Die zentrale Qt-Anwendung mit allen Managern."""

    def __init__(self, argv: list[str]) -> None:
        super().__init__(argv)
        self.setApplicationName(APP_NAME)
        self.setApplicationVersion(APP_VERSION)
        self.setOrganizationName(ORG_NAME)
        self.setQuitOnLastWindowClosed(True)

        # App-Icon für Taskleiste, Alt+Tab und Titelleiste
        _icon_path = ASSETS_DIR / "icon.ico"
        if _icon_path.exists():
            self.setWindowIcon(QIcon(str(_icon_path)))

        # Manager-Schicht (Logik, strikt von der GUI getrennt).
        self.settings = SettingsManager(self)
        self.audio = AudioManager(self)
        self.theme = ThemeManager(self, self)
        self.animations = AnimationManager(self)
        # Globale Hotkeys laufen über einen passiven Keyboard-Hook
        # in einem eigenen Thread – kein Event-Filter nötig.
        self.hotkeys = HotkeyManager(self)

        # Theme sofort anwenden (auch für den Splash).
        self.theme.apply(self.settings.config.ui)

        self.main_window: MainWindow | None = None
        self._splash: SplashScreen | None = None

    # ------------------------------------------------------------------ #
    def run(self) -> int:
        """Startet Splash → Hauptfenster und betritt die Event-Loop."""
        log.info("%s v%s wird gestartet …", APP_NAME, APP_VERSION)
        self._splash = SplashScreen()
        self._splash.finished.connect(self._show_main_window)
        self._splash.start()
        return self.exec()

    def _show_main_window(self) -> None:
        """Erzeugt das Hauptfenster und blendet es weich ein."""
        try:
            self.main_window = MainWindow(
                self.settings, self.audio, self.theme, self.animations, self.hotkeys
            )
            self.main_window.setWindowOpacity(0.0)
            self.main_window.show()

            target = self.settings.config.ui.window_opacity
            fade = QPropertyAnimation(self.main_window, b"windowOpacity", self)
            fade.setDuration(450)
            fade.setStartValue(450.0)
            fade.setEndValue(target)
            fade.setEasingCurve(QEasingCurve.Type.OutCubic)
            fade.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)
        except Exception:  # noqa: BLE001 - Startfehler sichtbar machen
            log.exception("Hauptfenster konnte nicht erstellt werden.")
            sys.exit(1)
