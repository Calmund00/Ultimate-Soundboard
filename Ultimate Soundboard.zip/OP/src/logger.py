"""
logger.py
=========

Zentrales Logging-Modul für Ultimate Soundboard .

Konfiguriert einen rotierenden Datei-Logger sowie eine Konsolen-Ausgabe.
Alle Module des Projekts beziehen ihren Logger über :func:`get_logger`.
"""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

#: Verzeichnis für Logdateien (im Projekt-Root, eine Ebene über src/).
LOG_DIR: Path = Path(__file__).resolve().parent.parent / "logs"
LOG_FILE: Path = LOG_DIR / "soundboard.log"

_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
_initialized = False


def _init_root_logger() -> None:
    """Initialisiert den Root-Logger genau einmal (Datei + Konsole)."""
    global _initialized
    if _initialized:
        return

    LOG_DIR.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger("soundboard")
    root.setLevel(logging.DEBUG)

    # Rotierende Logdatei: max. 2 MB, 3 Backups.
    file_handler = RotatingFileHandler(
        LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(_FORMAT))

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter(_FORMAT))

    root.addHandler(file_handler)
    root.addHandler(console_handler)
    _initialized = True


def get_logger(name: str) -> logging.Logger:
    """
    Liefert einen benannten Logger unterhalb des Projekt-Root-Loggers.

    :param name: Modulname, z. B. ``__name__``.
    :return: Konfigurierter :class:`logging.Logger`.
    """
    _init_root_logger()
    return logging.getLogger(f"soundboard.{name}")


def install_excepthook() -> None:
    """
    Installiert einen globalen Exception-Hook, der unbehandelte Ausnahmen
    in die Logdatei schreibt, statt die Anwendung abstürzen zu lassen.
    """
    log = get_logger("excepthook")

    def _hook(exc_type, exc_value, exc_tb):  # noqa: ANN001
        log.critical(
            "Unbehandelte Ausnahme", exc_info=(exc_type, exc_value, exc_tb)
        )

    sys.excepthook = _hook
