@echo off
echo ================================================
echo Building Ultimate Soundboard Pro v1.1.0
echo ================================================
echo.

REM Aufräumen
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build

REM Build mit PyInstaller (onedir-Modus, optimize=2)
py -3.12 -m PyInstaller UltimateSoundboard.spec --clean --noconfirm

echo.
echo ================================================
echo Build abgeschlossen!
echo ================================================
echo.
echo Programm-Ordner: dist\UltimateSoundboard\
echo Startdatei:      dist\UltimateSoundboard\UltimateSoundboard.exe
echo.
echo Hinweis: config\ und audio\ werden beim ersten Start automatisch angelegt.
echo Installer bauen: Inno Setup mit installer.iss starten.
echo.
pause
