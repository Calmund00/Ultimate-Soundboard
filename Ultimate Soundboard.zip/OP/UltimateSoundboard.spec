# -*- mode: python ; coding: utf-8 -*-
# PyInstaller 6+ – kein block_cipher mehr (deprecated)

a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('assets', 'assets'),
        ('src', 'src'),
    ],
    hiddenimports=[
        'PySide6.QtCore',
        'PySide6.QtGui',
        'PySide6.QtWidgets',
        'PySide6.QtMultimedia',
        'PySide6.QtSvg',
        'PySide6.QtSvgWidgets',
        'logging.handlers',
        'logging.config',
        'ctypes.wintypes',
        'wave',
        'json',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    # Unbenutzte Stdlib-Module ausschließen → kleinere EXE, schnellerer Start.
    excludes=[
        'tkinter',
        'unittest',
        'email',
        'xmlrpc',
        'pydoc',
        'doctest',
        'difflib',
        'ftplib',
        'imaplib',
        'mailbox',
        'nntplib',
        'poplib',
        'smtplib',
        'telnetlib',
        'turtle',
        'turtledemo',
    ],
    # urllib, html, http sind NICHT excluded – pathlib/zipfile brauchen urllib.parse
    noarchive=False,
    optimize=2,          # Python-Bytecode-Optimierung (entfernt Asserts + Docstrings)
)

pyz = PYZ(a.pure)

# --onedir-Modus: kein Entpacken in %TEMP% beim Start → deutlich schneller.
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='UltimateSoundboard',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    console=False,
    icon='assets/icon.ico',
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='UltimateSoundboard',
)
