"""
main.py
=======

Einstiegspunkt von **Ultimate Soundboard **.

Der eigentliche Quellcode liegt im Paketordner ``src/``. Diese Datei
fügt ``src/`` zum Modulsuchpfad hinzu, initialisiert das Logging,
installiert den globalen Exception-Hook und startet die Anwendung.

Voraussetzungen::

    pip install -r requirements.txt
    python main.py
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# Quellordner zum Importpfad hinzufügen, bevor Projektmodule geladen werden.
SRC_DIR = Path(__file__).resolve().parent / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from logger import get_logger, install_excepthook  # noqa: E402

log = get_logger(__name__)


def _boost_process_priority() -> None:
    """Setzt die Windows-Prozess-Priorität auf ABOVE_NORMAL."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        handle = ctypes.windll.kernel32.GetCurrentProcess()
        # ABOVE_NORMAL_PRIORITY_CLASS = 0x00008000
        ctypes.windll.kernel32.SetPriorityClass(handle, 0x00008000)
        log.debug("Prozess-Priorität auf ABOVE_NORMAL gesetzt.")
    except Exception as exc:  # noqa: BLE001
        log.debug("Priorität konnte nicht gesetzt werden: %s", exc)


def main() -> int:
    """Initialisiert und startet die Anwendung."""
    install_excepthook()
    _boost_process_priority()

    try:
        # Performance-Flags VOR dem Erstellen der QApplication setzen.
        from PySide6.QtCore import Qt, QThreadPool
        from PySide6.QtWidgets import QApplication

        QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

        from app import SoundboardApp

        app = SoundboardApp(sys.argv)

        # Globalen Thread-Pool auf alle verfügbaren CPU-Kerne skalieren.
        cpu_count = os.cpu_count() or 4
        QThreadPool.globalInstance().setMaxThreadCount(max(4, cpu_count))
        log.debug("QThreadPool: %d Threads aktiv.", QThreadPool.globalInstance().maxThreadCount())

        return app.run()
    except Exception:  # noqa: BLE001 - letzter Rettungsanker
        log.exception("Fataler Startfehler.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
